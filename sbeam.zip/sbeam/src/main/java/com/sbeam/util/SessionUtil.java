package com.sbeam.util;

import com.sbeam.model.User;
import javax.servlet.http.HttpSession;

public class SessionUtil {
    private static final String USER_SESSION_KEY = "currentUser";

    public static void setCurrentUser(HttpSession session, User user) {
        session.setAttribute(USER_SESSION_KEY, user);
    }

    public static User getCurrentUser(HttpSession session) {
        return (User) session.getAttribute(USER_SESSION_KEY);
    }

    public static void clearCurrentUser(HttpSession session) {
        session.removeAttribute(USER_SESSION_KEY);
    }

    public static boolean isLoggedIn(HttpSession session) {
        return getCurrentUser(session) != null;
    }

    public static boolean isAdmin(HttpSession session) {
        User currentUser = getCurrentUser(session);
        return currentUser != null && currentUser.isAdmin();
    }
} 