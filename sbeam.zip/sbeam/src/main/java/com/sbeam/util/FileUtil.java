package com.sbeam.util;

import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

public class FileUtil {
    private static final String UPLOAD_DIRECTORY = "uploads";
    private static final String IMAGE_DIRECTORY = UPLOAD_DIRECTORY + "/images";
    private static final String GAME_DIRECTORY = UPLOAD_DIRECTORY + "/games";
    
    // 获取项目根目录路径
    private static String getProjectRootPath() {
        try {
            // 获取当前类的位置，然后向上查找到项目根目录
            String classPath = FileUtil.class.getProtectionDomain().getCodeSource().getLocation().getPath();
            Path currentPath = Paths.get(classPath);
            
            // 从 target/classes 或 WEB-INF/classes 向上查找到项目根目录
            Path projectRoot = currentPath;
            while (projectRoot != null && !Files.exists(projectRoot.resolve("pom.xml"))) {
                projectRoot = projectRoot.getParent();
            }
            
            if (projectRoot != null && Files.exists(projectRoot.resolve("pom.xml"))) {
                return projectRoot.toString();
            }
            
            // 如果找不到pom.xml，使用当前工作目录
            return System.getProperty("user.dir");
        } catch (Exception e) {
            // 如果出错，使用当前工作目录
            return System.getProperty("user.dir");
        }
    }
    
    private static final String BASE_PATH = getProjectRootPath() + File.separator + UPLOAD_DIRECTORY;

    static {
        createDirectories();
    }

    private static void createDirectories() {
        try {
            // Create absolute paths for upload directories
            Path basePath = Paths.get(BASE_PATH);
            Path imagePath = basePath.resolve("images");
            Path gamePath = basePath.resolve("games");
            
            Files.createDirectories(basePath);
            Files.createDirectories(imagePath);
            Files.createDirectories(gamePath);
            
            System.out.println("Upload directories created at: " + BASE_PATH);
        } catch (IOException e) {
            throw new RuntimeException("Could not create upload directories", e);
        }
    }

    public static String saveGameImage(Part filePart) throws IOException {
        String fileName = generateUniqueFileName(filePart);
        Path filePath = Paths.get(BASE_PATH, "images", fileName);
        filePart.write(filePath.toString());
        return "/uploads/images/" + fileName;  // Return web-accessible path
    }

    public static String saveGameFile(Part filePart) throws IOException {
        String fileName = generateUniqueFileName(filePart);
        Path filePath = Paths.get(BASE_PATH, "games", fileName);
        filePart.write(filePath.toString());
        return "/uploads/games/" + fileName;  // Return web-accessible path
    }

    public static Path getGameFilePath(String fileName) {
        // Handle both old relative paths and new web paths
        if (fileName.startsWith("/uploads/games/")) {
            fileName = fileName.substring("/uploads/games/".length());
        }
        return Paths.get(BASE_PATH, "games", fileName);
    }

    public static Path getImageFilePath(String fileName) {
        // Handle both old relative paths and new web paths
        if (fileName.startsWith("/uploads/images/")) {
            fileName = fileName.substring("/uploads/images/".length());
        }
        return Paths.get(BASE_PATH, "images", fileName);
    }

    private static String generateUniqueFileName(Part part) {
        String originalFileName = part.getSubmittedFileName();
        String extension = "";
        if (originalFileName != null && originalFileName.contains(".")) {
            extension = originalFileName.substring(originalFileName.lastIndexOf("."));
        }
        return UUID.randomUUID().toString() + extension;
    }

    public static void deleteFile(String fileName, boolean isImage) {
        try {
            Path filePath = isImage ? getImageFilePath(fileName) : getGameFilePath(fileName);
            Files.deleteIfExists(filePath);
        } catch (IOException e) {
            throw new RuntimeException("Could not delete file: " + fileName, e);
        }
    }

    /**
     * Get absolute path for a file (used for downloads)
     * @param fileName the file name or web path
     * @return absolute Path to the file
     */
    public static Path getAbsolutePath(String fileName) {
        if (fileName == null) {
            return null;
        }
        
        // Determine if it's an image or game file based on the path
        if (fileName.startsWith("/uploads/images/") || fileName.contains("images")) {
            return getImageFilePath(fileName);
        } else {
            return getGameFilePath(fileName);
        }
    }

    /**
     * 获取项目根目录下uploads文件夹的绝对路径
     * @return uploads文件夹的绝对路径
     */
    public static String getUploadsPath() {
        return BASE_PATH;
    }
} 