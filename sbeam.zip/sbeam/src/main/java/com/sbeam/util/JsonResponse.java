package com.sbeam.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class JsonResponse {
    private static final ObjectMapper mapper = new ObjectMapper();

    public static void send(HttpServletResponse response, int status, String message, Object data) throws IOException {
        Map<String, Object> result = new HashMap<>();
        result.put("status", status);
        result.put("message", message);
        if (data != null) {
            result.put("data", data);
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.setStatus(status);

        try (PrintWriter writer = response.getWriter()) {
            writer.write(mapper.writeValueAsString(result));
        }
    }

    public static void success(HttpServletResponse response, String message) throws IOException {
        send(response, HttpServletResponse.SC_OK, message, null);
    }

    public static void success(HttpServletResponse response, String message, Object data) throws IOException {
        send(response, HttpServletResponse.SC_OK, message, data);
    }

    public static void error(HttpServletResponse response, int status, String message) throws IOException {
        send(response, status, message, null);
    }

    public static void error(HttpServletResponse response, String message) throws IOException {
        send(response, HttpServletResponse.SC_BAD_REQUEST, message, null);
    }
} 