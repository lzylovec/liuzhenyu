package com.sbeam.controller.user;

import com.sbeam.controller.BaseServlet;
import com.sbeam.model.User;
import com.sbeam.service.UserService;
import com.sbeam.service.impl.UserServiceImpl;
import com.sbeam.util.JsonResponse;
import com.sbeam.util.SessionUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/api/register")
public class RegisterServlet extends BaseServlet {
    private final UserService userService = new UserServiceImpl();

    @Override
    protected void handleDoPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String username = getRequiredParameter(request, "username");
        String password = getRequiredParameter(request, "password");

        try {
            User user = userService.register(username, password);
            SessionUtil.setCurrentUser(request.getSession(), user);
            JsonResponse.success(response, "注册成功", user);
        } catch (IllegalArgumentException e) {
            JsonResponse.error(response, e.getMessage());
        }
    }
}