package com.sbeam.controller.game;

import com.sbeam.controller.BaseServlet;
import com.sbeam.model.Game;
import com.sbeam.model.Order;
import com.sbeam.model.User;
import com.sbeam.service.GameService;
import com.sbeam.service.OrderService;
import com.sbeam.service.impl.GameServiceImpl;
import com.sbeam.service.impl.OrderServiceImpl;
import com.sbeam.util.JsonResponse;
import com.sbeam.util.FileUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/api/games/download/*")
public class GameDownloadServlet extends BaseServlet {
    private final GameService gameService = new GameServiceImpl();
    private final OrderService orderService = new OrderServiceImpl();

    @Override
    protected void handleDoGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        System.out.println("GameDownloadServlet: Download request received");
        System.out.println("PathInfo: " + request.getPathInfo());
        System.out.println("RequestURI: " + request.getRequestURI());
        
        requireLogin(request, response);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            System.out.println("Invalid path: " + pathInfo);
            JsonResponse.error(response, "Invalid path");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length != 2) {
            System.out.println("Invalid path structure. Expected /gameId, got: " + pathInfo);
            JsonResponse.error(response, "Invalid path");
            return;
        }

        try {
            Integer gameId = Integer.parseInt(splits[1]);
            System.out.println("Requesting download for game ID: " + gameId);
            
            Game game = gameService.getGameById(gameId);
            if (game == null || !game.isStatus()) {
                System.out.println("Game not found or inactive: " + gameId);
                JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Game not found");
                return;
            }
            
            System.out.println("Game found: " + game.getTitle() + ", DownloadURL: " + game.getDownloadUrl());

            User user = getCurrentUser(request);
            if (!user.isAdmin()) {
                // Check if user has purchased the game
                List<Order> orders = orderService.getOrdersByUserId(user.getId());
                boolean hasPurchased = orders.stream()
                        .anyMatch(order -> order.getGameId().equals(gameId) && 
                                 "completed".equals(order.getStatus()));
                if (!hasPurchased) {
                    JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "You must purchase the game first");
                    return;
                }
            }

            // Check if download URL exists
            if (game.getDownloadUrl() == null || game.getDownloadUrl().trim().isEmpty()) {
                JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Game download not available");
                return;
            }

            // Get the game file using FileUtil
            Path gameFile = FileUtil.getAbsolutePath(game.getDownloadUrl());
            if (!Files.exists(gameFile)) {
                JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Game file not found");
                return;
            }

            // Create a meaningful filename for download
            String fileName = gameFile.getFileName().toString();
            String downloadFileName;
            
            // Use game title for a better download experience
            String gameTitle = game.getTitle().replaceAll("[^a-zA-Z0-9\\-_\\.]", "_");
            String extension = "";
            if (fileName.contains(".")) {
                extension = fileName.substring(fileName.lastIndexOf("."));
            }
            
            downloadFileName = gameTitle + "_v1.0" + extension;
            if (downloadFileName.length() > 100) {
                downloadFileName = gameTitle.substring(0, 90) + extension;
            }

            // Set response headers
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + downloadFileName + "\"");
            response.setContentLengthLong(Files.size(gameFile));

            // Copy the file to the response output stream
            try (InputStream in = Files.newInputStream(gameFile);
                 OutputStream out = response.getOutputStream()) {
                byte[] buffer = new byte[8192];
                int length;
                while ((length = in.read(buffer)) > 0) {
                    out.write(buffer, 0, length);
                }
                out.flush();
            }
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "Invalid game ID");
        }
    }
} 