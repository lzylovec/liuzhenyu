package com.sbeam.controller.cart;

import com.sbeam.controller.BaseServlet;
import com.sbeam.model.CartItem;
import com.sbeam.model.User;
import com.sbeam.service.CartService;
import com.sbeam.service.impl.CartServiceImpl;
import com.sbeam.util.JsonResponse;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/api/cart/*")
public class CartServlet extends BaseServlet {
    private final CartService cartService = new CartServiceImpl();

    @Override
    protected void handleDoGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireLogin(request, response);
        User user = getCurrentUser(request);

        // Get cart items for current user
        List<CartItem> cartItems = cartService.getCartItems(user.getId());
        JsonResponse.success(response, "购物车获取成功", cartItems);
    }

    @Override
    protected void handleDoPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireLogin(request, response);
        User user = getCurrentUser(request);

        // Add item to cart
        Integer gameId = getIntParameter(request, "gameId");
        
        try {
            cartService.addToCart(user.getId(), gameId);
            JsonResponse.success(response, "商品已添加到购物车");
        } catch (IllegalArgumentException e) {
            JsonResponse.error(response, e.getMessage());
        }
    }

    @Override
    protected void handleDoPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireLogin(request, response);
        User user = getCurrentUser(request);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length != 2) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        try {
            Integer gameId = Integer.parseInt(splits[1]);
            
            // Check if the game is in the user's cart
            List<CartItem> cartItems = cartService.getCartItems(user.getId());
            boolean gameInCart = cartItems.stream()
                .anyMatch(item -> item.getGameId().equals(gameId));
            
            if (!gameInCart) {
                JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Game not found in cart");
                return;
            }
            
            // Update cart item
            Integer quantity = getIntParameter(request, "quantity", 1);
            if (quantity <= 0) {
                // If quantity is 0 or negative, remove item from cart
                cartService.removeFromCart(user.getId(), gameId);
                JsonResponse.success(response, "Item removed from cart successfully");
            } else {
                // CartService doesn't have updateCartItemQuantity method, so we'll remove and add again
                cartService.removeFromCart(user.getId(), gameId);
                cartService.addToCart(user.getId(), gameId);
                JsonResponse.success(response, "Cart item updated successfully");
            }
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "Invalid game ID");
        }
    }

    @Override
    protected void handleDoDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireLogin(request, response);
        User user = getCurrentUser(request);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            // Clear entire cart
            cartService.clearCart(user.getId());
            JsonResponse.success(response, "Cart cleared successfully");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length != 2) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        try {
            Integer gameId = Integer.parseInt(splits[1]);
            
            // Check if the game is in the user's cart
            List<CartItem> cartItems = cartService.getCartItems(user.getId());
            boolean gameInCart = cartItems.stream()
                .anyMatch(item -> item.getGameId().equals(gameId));
            
            if (!gameInCart) {
                JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Game not found in cart");
                return;
            }
            
            // Remove item from cart
            cartService.removeFromCart(user.getId(), gameId);
            JsonResponse.success(response, "Item removed from cart successfully");
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "Invalid game ID");
        }
    }
} 