package com.sbeam.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbeam.model.User;
import com.sbeam.util.JsonResponse;
import com.sbeam.util.SessionUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public abstract class BaseServlet extends HttpServlet {
    protected static final ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Set character encoding
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        try {
            String method = req.getMethod();
            if (method.equals("GET")) {
                doGet(req, resp);
            } else if (method.equals("POST")) {
                doPost(req, resp);
            } else if (method.equals("PUT")) {
                doPut(req, resp);
            } else if (method.equals("DELETE")) {
                doDelete(req, resp);
            } else {
                super.service(req, resp);
            }
        } catch (IllegalArgumentException e) {
            JsonResponse.error(resp, e.getMessage());
        } catch (Exception e) {
            JsonResponse.error(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "服务器错误: " + e.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            handleDoGet(req, resp);
        } catch (SQLException e) {
            JsonResponse.error(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "数据库错误: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            handleDoPost(req, resp);
        } catch (SQLException e) {
            JsonResponse.error(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "数据库错误: " + e.getMessage());
        }
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            handleDoPut(req, resp);
        } catch (SQLException e) {
            JsonResponse.error(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "数据库错误: " + e.getMessage());
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            handleDoDelete(req, resp);
        } catch (SQLException e) {
            JsonResponse.error(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "数据库错误: " + e.getMessage());
        }
    }

    // 子类可以覆盖这些方法来处理请求
    protected void handleDoGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, SQLException {
        super.doGet(req, resp);
    }

    protected void handleDoPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, SQLException {
        super.doPost(req, resp);
    }

    protected void handleDoPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, SQLException {
        super.doPut(req, resp);
    }

    protected void handleDoDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, SQLException {
        super.doDelete(req, resp);
    }

    protected User getCurrentUser(HttpServletRequest request) {
        return SessionUtil.getCurrentUser(request.getSession());
    }

    protected void requireLogin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (!SessionUtil.isLoggedIn(request.getSession())) {
            JsonResponse.error(response, HttpServletResponse.SC_UNAUTHORIZED, "请先登录");
            throw new IllegalStateException("User not logged in");
        }
    }

    protected void requireAdmin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        requireLogin(request, response);
        if (!SessionUtil.isAdmin(request.getSession())) {
            JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "需要管理员权限");
            throw new IllegalStateException("Admin access required");
        }
    }

    protected Integer getIntParameter(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("参数 " + name + " 是必需的");
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("参数 " + name + " 格式无效");
        }
    }

    protected Integer getIntParameter(HttpServletRequest request, String name, Integer defaultValue) {
        String value = request.getParameter(name);
        if (value == null || value.trim().isEmpty()) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    protected String getRequiredParameter(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("参数 " + name + " 是必需的");
        }
        return value.trim();
    }

    protected String getParameter(HttpServletRequest request, String name, String defaultValue) {
        String value = request.getParameter(name);
        return value == null || value.trim().isEmpty() ? defaultValue : value.trim();
    }

    // 解析PUT请求的表单参数
    protected Map<String, String> parsePutParameters(HttpServletRequest request) throws IOException {
        Map<String, String> parameters = new HashMap<>();
        
        // 首先尝试标准的getParameter方法
        if (request.getParameterMap().size() > 0) {
            for (Map.Entry<String, String[]> entry : request.getParameterMap().entrySet()) {
                String[] values = entry.getValue();
                if (values != null && values.length > 0) {
                    parameters.put(entry.getKey(), values[0]);
                }
            }
            return parameters;
        }
        
        // 如果标准方法没有参数，则手动解析请求体
        StringBuilder buffer = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            buffer.append(line);
        }
        
        String body = buffer.toString();
        System.out.println("PUT request body: '" + body + "' (length: " + body.length() + ")");
        
        if (body.length() > 0) {
            String[] pairs = body.split("&");
            for (String pair : pairs) {
                String[] keyValue = pair.split("=", 2);
                if (keyValue.length == 2) {
                    try {
                        String key = URLDecoder.decode(keyValue[0], "UTF-8");
                        String value = URLDecoder.decode(keyValue[1], "UTF-8");
                        parameters.put(key, value);
                    } catch (UnsupportedEncodingException e) {
                        System.err.println("Error decoding parameter: " + pair);
                    }
                }
            }
        }
        
        return parameters;
    }

    // 从PUT参数中获取值
    protected String getPutParameter(Map<String, String> putParams, String name, String defaultValue) {
        String value = putParams.get(name);
        return value == null || value.trim().isEmpty() ? defaultValue : value.trim();
    }
} 