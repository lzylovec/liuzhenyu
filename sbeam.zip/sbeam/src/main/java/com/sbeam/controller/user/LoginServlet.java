package com.sbeam.controller.user;

import com.sbeam.controller.BaseServlet;
import com.sbeam.model.User;
import com.sbeam.service.UserService;
import com.sbeam.service.impl.UserServiceImpl;
import com.sbeam.util.JsonResponse;
import com.sbeam.util.SessionUtil;
import com.sbeam.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/api/login")
public class LoginServlet extends BaseServlet {
    private final UserService userService = new UserServiceImpl();

    @Override
    protected void handleDoPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String username = getRequiredParameter(request, "username");
        String password = getRequiredParameter(request, "password");

        System.out.println("Login attempt - Username: " + username);
        
        // 检查用户是否存在
        User userFromDb = userService.getUserByUsername(username);
        if (userFromDb == null) {
            System.out.println("Login failed - User not found: " + username);
            JsonResponse.error(response, "用户名或密码错误");
            return;
        }
        
        // 检查密码哈希
        String inputPasswordHash = PasswordUtil.hashPassword(password);
        System.out.println("Password verification - Input hash: " + inputPasswordHash);
        System.out.println("Password verification - DB hash: " + userFromDb.getPassword());
        
        User user = userService.login(username, password);
        if (user != null) {
            System.out.println("Login successful for user: " + username);
            SessionUtil.setCurrentUser(request.getSession(), user);
            JsonResponse.success(response, "登录成功", user);
        } else {
            System.out.println("Login failed - Invalid password for user: " + username);
            JsonResponse.error(response, "用户名或密码错误");
        }
    }

    @Override
    protected void handleDoGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        User currentUser = getCurrentUser(request);
        if (currentUser != null) {
            JsonResponse.success(response, "用户已登录", currentUser);
        } else {
            JsonResponse.error(response, HttpServletResponse.SC_UNAUTHORIZED, "用户未登录");
        }
    }
} 