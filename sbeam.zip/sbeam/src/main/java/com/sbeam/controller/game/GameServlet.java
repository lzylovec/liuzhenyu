package com.sbeam.controller.game;

import com.sbeam.controller.BaseServlet;
import com.sbeam.model.Game;
import com.sbeam.model.User;
import com.sbeam.service.GameService;
import com.sbeam.service.impl.GameServiceImpl;
import com.sbeam.util.JsonResponse;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@WebServlet("/api/games/*")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,      // 1 MB
    maxFileSize = 1024 * 1024 * 10,       // 10 MB
    maxRequestSize = 1024 * 1024 * 100    // 100 MB
)
public class GameServlet extends BaseServlet {
    private final GameService gameService = new GameServiceImpl();

    @Override
    protected void handleDoGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || pathInfo.equals("/")) {
            // List all games
            boolean showAll = false;
            User currentUser = getCurrentUser(request);
            if (currentUser != null && currentUser.isAdmin()) {
                showAll = Boolean.parseBoolean(getParameter(request, "showAll", "false"));
            }

            List<Game> games = showAll ? gameService.getAllGames() : gameService.getAllActiveGames();
            JsonResponse.success(response, "Games retrieved successfully", games);
        } else {
            // Get game by ID
            String[] splits = pathInfo.split("/");
            if (splits.length != 2) {
                JsonResponse.error(response, "Invalid path");
                return;
            }

            try {
                Integer gameId = Integer.parseInt(splits[1]);
                Game game = gameService.getGameById(gameId);
                if (game != null) {
                    // Only show inactive games to admin
                    if (!game.isStatus()) {
                        User currentUser = getCurrentUser(request);
                        if (currentUser == null || !currentUser.isAdmin()) {
                            JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Game not found");
                            return;
                        }
                    }
                    JsonResponse.success(response, "Game retrieved successfully", game);
                } else {
                    JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Game not found");
                }
            } catch (NumberFormatException e) {
                JsonResponse.error(response, "Invalid game ID");
            }
        }
    }

    @Override
    protected void handleDoPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireAdmin(request, response);

        Game game = new Game();
        game.setTitle(getRequiredParameter(request, "name"));
        game.setDescription(getRequiredParameter(request, "description"));
        game.setPrice(new BigDecimal(getRequiredParameter(request, "price")));
        game.setStatus(true);

        Part imageFile = request.getPart("image");
        Part gameFile = request.getPart("game");

        if (gameFile == null || gameFile.getSize() == 0) {
            JsonResponse.error(response, "Game file is required");
            return;
        }

        Game newGame = gameService.createGame(game, imageFile, gameFile);
        JsonResponse.success(response, "Game created successfully", newGame);
    }

    @Override
    protected void handleDoPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireAdmin(request, response);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length != 2) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        try {
            Integer gameId = Integer.parseInt(splits[1]);
            
            // Parse PUT parameters
            Map<String, String> putParams = parsePutParameters(request);
            String action = getPutParameter(putParams, "action", "update");

            System.out.println("GameServlet PUT request - gameId: " + gameId + ", action: " + action);

            if (action.equals("status")) {
                String statusParam = getPutParameter(putParams, "status", null);
                if (statusParam == null) {
                    JsonResponse.error(response, "参数 status 是必需的");
                    return;
                }
                boolean status = Boolean.parseBoolean(statusParam);
                System.out.println("Updating game " + gameId + " status to: " + status + " (from parameter: " + statusParam + ")");
                gameService.updateGameStatus(gameId, status);
                JsonResponse.success(response, "Game status updated successfully");
            } else {
                // Get current game to preserve status
                Game existingGame = gameService.getGameById(gameId);
                if (existingGame == null) {
                    JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Game not found");
                    return;
                }
                
                String name = getPutParameter(putParams, "name", null);
                String description = getPutParameter(putParams, "description", null);
                String priceStr = getPutParameter(putParams, "price", null);
                
                if (name == null || description == null || priceStr == null) {
                    JsonResponse.error(response, "必需参数缺失: name, description, price");
                    return;
                }

                Game game = new Game();
                game.setId(gameId);
                game.setTitle(name);
                game.setDescription(description);
                game.setPrice(new BigDecimal(priceStr));
                // Preserve the existing status
                game.setStatus(existingGame.isStatus());

                System.out.println("Updating game " + gameId + " with status preserved: " + existingGame.isStatus());

                Part imageFile = request.getPart("image");
                Part gameFile = request.getPart("game");

                gameService.updateGame(game, imageFile, gameFile);
                JsonResponse.success(response, "Game updated successfully");
            }
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "Invalid game ID");
        }
    }

    @Override
    protected void handleDoDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireAdmin(request, response);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length != 2) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        try {
            Integer gameId = Integer.parseInt(splits[1]);
            if (gameService.deleteGame(gameId)) {
                JsonResponse.success(response, "Game deleted successfully");
            } else {
                JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Game not found");
            }
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "Invalid game ID");
        }
    }
} 