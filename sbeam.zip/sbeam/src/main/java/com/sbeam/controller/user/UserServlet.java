package com.sbeam.controller.user;

import com.sbeam.controller.BaseServlet;
import com.sbeam.model.User;
import com.sbeam.service.UserService;
import com.sbeam.service.impl.UserServiceImpl;
import com.sbeam.util.JsonResponse;
import com.sbeam.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@WebServlet("/api/users/*")
public class UserServlet extends BaseServlet {
    private final UserService userService = new UserServiceImpl();

    @Override
    protected void handleDoGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || pathInfo.equals("/")) {
            // List all users (admin only)
            requireAdmin(request, response);
            List<User> users = userService.getAllUsers();
            JsonResponse.success(response, "用户列表获取成功", users);
        } else {
            // Get user by ID
            String[] splits = pathInfo.split("/");
            if (splits.length != 2) {
                JsonResponse.error(response, "路径无效");
                return;
            }

            try {
                Integer userId = Integer.parseInt(splits[1]);
                User currentUser = getCurrentUser(request);
                
                // Only admin or the user themselves can view user details
                if (currentUser == null || (!currentUser.isAdmin() && !currentUser.getId().equals(userId))) {
                    JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "访问被拒绝");
                    return;
                }
                
                User user = userService.getUserById(userId);
                if (user != null) {
                    JsonResponse.success(response, "用户信息获取成功", user);
                } else {
                    JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "用户不存在");
                }
            } catch (NumberFormatException e) {
                JsonResponse.error(response, "用户ID无效");
            }
        }
    }

    @Override
    protected void handleDoPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            JsonResponse.error(response, "路径无效");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length < 2) {
            JsonResponse.error(response, "路径无效");
            return;
        }

        try {
            Integer userId = Integer.parseInt(splits[1]);
            User currentUser = getCurrentUser(request);
            
            System.out.println("PUT request for user ID: " + userId);
            System.out.println("Path splits length: " + splits.length);
            System.out.println("Current user: " + (currentUser != null ? currentUser.getUsername() : "null"));
            
            if (splits.length == 3 && splits[2].equals("status")) {
                // Update user status (admin only)
                System.out.println("Updating user status via /status endpoint");
                requireAdmin(request, response);
                
                // 解析PUT请求参数
                Map<String, String> putParams = parsePutParameters(request);
                System.out.println("=== Status Update PUT Parameters ===");
                putParams.forEach((key, value) -> {
                    System.out.println(key + " = " + value);
                });
                System.out.println("====================================");
                
                String statusParam = getPutParameter(putParams, "status", null);
                if (statusParam == null || statusParam.trim().isEmpty()) {
                    JsonResponse.error(response, "参数 status 是必需的");
                    return;
                }
                
                boolean status = Boolean.parseBoolean(statusParam);
                System.out.println("Status parameter: " + statusParam + " -> " + status);
                userService.updateUserStatus(userId, status);
                JsonResponse.success(response, "用户状态更新成功");
            } else if (splits.length == 2) {
                // Update user details
                System.out.println("Updating user details via main endpoint");
                // Only admin or the user themselves can update user details
                if (currentUser == null || (!currentUser.isAdmin() && !currentUser.getId().equals(userId))) {
                    JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "访问被拒绝");
                    return;
                }
                
                User user = userService.getUserById(userId);
                if (user == null) {
                    JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "用户不存在");
                    return;
                }
                
                boolean hasUpdates = false;
                
                // 解析PUT请求参数
                Map<String, String> putParams = parsePutParameters(request);
                
                // Debug: Print all request parameters
                System.out.println("=== Request Parameters ===");
                request.getParameterMap().forEach((key, values) -> {
                    System.out.println(key + " = " + String.join(", ", values));
                });
                System.out.println("=== PUT Parameters ===");
                putParams.forEach((key, value) -> {
                    System.out.println(key + " = " + value);
                });
                System.out.println("========================");
                
                // Update username (admin only)
                String usernameParam = getPutParameter(putParams, "username", null);
                System.out.println("Username parameter: " + usernameParam);
                if (usernameParam != null && !usernameParam.trim().isEmpty()) {
                    if (!currentUser.isAdmin()) {
                        JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "只有管理员可以修改用户名");
                        return;
                    }
                    // 检查用户名是否已被其他用户使用
                    User existingUser = userService.getUserByUsername(usernameParam.trim());
                    if (existingUser != null && !existingUser.getId().equals(user.getId())) {
                        JsonResponse.error(response, "用户名已存在");
                        return;
                    }
                    user.setUsername(usernameParam.trim());
                    hasUpdates = true;
                    System.out.println("Username updated to: " + usernameParam);
                }
                
                // Update password (admin only)
                String passwordParam = getPutParameter(putParams, "password", null);
                System.out.println("Password parameter: " + (passwordParam != null ? "[PROVIDED]" : "null"));
                if (passwordParam != null && !passwordParam.trim().isEmpty()) {
                    if (!currentUser.isAdmin()) {
                        JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "只有管理员可以修改密码");
                        return;
                    }
                    String hashedPassword = PasswordUtil.hashPassword(passwordParam.trim());
                    user.setPassword(hashedPassword);
                    hasUpdates = true;
                    System.out.println("Password updated");
                }
                
                // Update balance (admin only)
                String balanceParam = getPutParameter(putParams, "balance", null);
                System.out.println("Balance parameter: " + balanceParam);
                if (balanceParam != null && !balanceParam.trim().isEmpty()) {
                    if (!currentUser.isAdmin()) {
                        JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "只有管理员可以修改余额");
                        return;
                    }
                    user.setBalance(new BigDecimal(balanceParam));
                    hasUpdates = true;
                    System.out.println("Balance updated to: " + balanceParam);
                }
                
                // Update admin status (admin only)
                String adminParam = getPutParameter(putParams, "admin", null);
                System.out.println("Admin parameter: " + adminParam);
                if (adminParam != null && !adminParam.trim().isEmpty()) {
                    if (!currentUser.isAdmin()) {
                        JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "只有管理员可以修改管理员权限");
                        return;
                    }
                    user.setAdmin(Boolean.parseBoolean(adminParam));
                    hasUpdates = true;
                    System.out.println("Admin status updated to: " + adminParam);
                }
                
                // Update status (admin only)
                String statusParam = getPutParameter(putParams, "status", null);
                System.out.println("Status parameter: " + statusParam);
                if (statusParam != null && !statusParam.trim().isEmpty()) {
                    if (!currentUser.isAdmin()) {
                        JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "只有管理员可以修改用户状态");
                        return;
                    }
                    user.setStatus(Boolean.parseBoolean(statusParam));
                    hasUpdates = true;
                    System.out.println("Status updated to: " + statusParam);
                }
                
                if (hasUpdates) {
                    System.out.println("Calling userService.updateUser()");
                    userService.updateUser(user);
                    JsonResponse.success(response, "用户信息更新成功");
                } else {
                    System.out.println("No updates to apply");
                    JsonResponse.success(response, "没有需要更新的内容");
                }
            } else {
                JsonResponse.error(response, "路径结构无效");
            }
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "用户ID无效");
        } catch (IllegalArgumentException e) {
            JsonResponse.error(response, e.getMessage());
        }
    }

    @Override
    protected void handleDoDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireAdmin(request, response);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            JsonResponse.error(response, "路径无效");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length != 2) {
            JsonResponse.error(response, "路径无效");
            return;
        }

        try {
            Integer userId = Integer.parseInt(splits[1]);
            if (userService.deleteUser(userId)) {
                JsonResponse.success(response, "用户删除成功");
            } else {
                JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "用户不存在");
            }
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "用户ID无效");
        }
    }
} 