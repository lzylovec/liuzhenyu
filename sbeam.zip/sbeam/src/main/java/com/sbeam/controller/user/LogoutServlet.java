package com.sbeam.controller.user;

import com.sbeam.controller.BaseServlet;
import com.sbeam.util.JsonResponse;
import com.sbeam.util.SessionUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/api/logout")
public class LogoutServlet extends BaseServlet {
    @Override
    protected void handleDoPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        SessionUtil.clearCurrentUser(request.getSession());
        JsonResponse.success(response, "退出登录成功");
    }
} 