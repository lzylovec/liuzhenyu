package com.sbeam.controller.order;

import com.sbeam.controller.BaseServlet;
import com.sbeam.model.Order;
import com.sbeam.model.User;
import com.sbeam.service.OrderService;
import com.sbeam.service.impl.OrderServiceImpl;
import com.sbeam.util.JsonResponse;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/api/orders/*")
public class OrderServlet extends BaseServlet {
    private final OrderService orderService = new OrderServiceImpl();

    @Override
    protected void handleDoGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireLogin(request, response);
        User user = getCurrentUser(request);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            // List orders
            List<Order> orders;
            if (user.isAdmin()) {
                orders = orderService.getAllOrders();
            } else {
                orders = orderService.getOrdersByUserId(user.getId());
            }
            JsonResponse.success(response, "订单列表获取成功", orders);
        } else if (pathInfo.equals("/my")) {
            // Get current user's orders for library
            List<Order> orders = orderService.getOrdersByUserId(user.getId());
            JsonResponse.success(response, "我的订单获取成功", orders);
        } else {
            // Get order by ID
            String[] splits = pathInfo.split("/");
            if (splits.length != 2) {
                JsonResponse.error(response, "路径无效");
                return;
            }

            try {
                Integer orderId = Integer.parseInt(splits[1]);
                Order order = orderService.getOrderById(orderId);
                if (order != null) {
                    // Only admin can view other users' orders
                    if (!user.isAdmin() && !order.getUserId().equals(user.getId())) {
                        JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "访问被拒绝");
                        return;
                    }
                    JsonResponse.success(response, "订单获取成功", order);
                } else {
                    JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "订单不存在");
                }
            } catch (NumberFormatException e) {
                JsonResponse.error(response, "订单ID无效");
            }
        }
    }

    @Override
    protected void handleDoPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireLogin(request, response);
        User user = getCurrentUser(request);

        String action = getParameter(request, "action", "single");
        if (action.equals("cart")) {
            // Create orders from cart
            orderService.createOrdersFromCart(user.getId());
            JsonResponse.success(response, "购物车订单创建成功");
        } else {
            // Create single order
            Integer gameId = getIntParameter(request, "gameId");
            orderService.createOrder(user.getId(), gameId);
            JsonResponse.success(response, "订单创建成功");
        }
    }

    @Override
    protected void handleDoDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireAdmin(request, response);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            JsonResponse.error(response, "路径无效");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length != 2) {
            JsonResponse.error(response, "路径无效");
            return;
        }

        try {
            Integer orderId = Integer.parseInt(splits[1]);
            if (orderService.deleteOrder(orderId)) {
                JsonResponse.success(response, "订单删除成功");
            } else {
                JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "订单不存在");
            }
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "订单ID无效");
        }
    }
} 