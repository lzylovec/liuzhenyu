package com.sbeam.controller;

import com.sbeam.util.FileUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

@WebServlet("/uploads/*")
public class FileServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.length() <= 1) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Remove leading slash
        pathInfo = pathInfo.substring(1);
        
        Path filePath = null;
        String contentType = null;
        
        if (pathInfo.startsWith("images/")) {
            String fileName = pathInfo.substring("images/".length());
            filePath = FileUtil.getImageFilePath(fileName);
            contentType = getImageContentType(fileName);
        } else if (pathInfo.startsWith("games/")) {
            String fileName = pathInfo.substring("games/".length());
            filePath = FileUtil.getGameFilePath(fileName);
            contentType = "application/octet-stream";
        }
        
        if (filePath == null || !Files.exists(filePath)) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Set content type
        if (contentType != null) {
            response.setContentType(contentType);
        }
        
        // Set content length
        response.setContentLengthLong(Files.size(filePath));
        
        // Set cache headers for images
        if (pathInfo.startsWith("images/")) {
            response.setHeader("Cache-Control", "public, max-age=3600");
        }
        
        // Stream the file
        try (OutputStream out = response.getOutputStream()) {
            Files.copy(filePath, out);
        }
    }
    
    private String getImageContentType(String fileName) {
        String extension = "";
        int lastDot = fileName.lastIndexOf('.');
        if (lastDot > 0) {
            extension = fileName.substring(lastDot + 1).toLowerCase();
        }
        
        switch (extension) {
            case "jpg":
            case "jpeg":
                return "image/jpeg";
            case "png":
                return "image/png";
            case "gif":
                return "image/gif";
            case "webp":
                return "image/webp";
            default:
                return "image/jpeg";
        }
    }
} 