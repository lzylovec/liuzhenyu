package com.sbeam.controller.comment;

import com.sbeam.controller.BaseServlet;
import com.sbeam.model.Comment;
import com.sbeam.model.User;
import com.sbeam.service.CommentService;
import com.sbeam.service.impl.CommentServiceImpl;
import com.sbeam.util.JsonResponse;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/api/comments/*")
public class CommentServlet extends BaseServlet {
    private final CommentService commentService = new CommentServiceImpl();

    @Override
    protected void handleDoGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || pathInfo.equals("/")) {
            // List all comments (admin only)
            requireAdmin(request, response);
            List<Comment> comments = commentService.getAllComments();
            JsonResponse.success(response, "Comments retrieved successfully", comments);
        } else {
            // Get comments by game ID or user ID
            String[] splits = pathInfo.split("/");
            if (splits.length != 3) {
                JsonResponse.error(response, "Invalid path");
                return;
            }

            try {
                Integer id = Integer.parseInt(splits[2]);
                List<Comment> comments;
                switch (splits[1]) {
                    case "game":
                        comments = commentService.getCommentsByGameId(id);
                        JsonResponse.success(response, "Game comments retrieved successfully", comments);
                        break;
                    case "user":
                        // Only admin or the user themselves can view their comments
                        User currentUser = getCurrentUser(request);
                        if (currentUser == null || (!currentUser.isAdmin() && !currentUser.getId().equals(id))) {
                            JsonResponse.error(response, HttpServletResponse.SC_FORBIDDEN, "Access denied");
                            return;
                        }
                        comments = commentService.getCommentsByUserId(id);
                        JsonResponse.success(response, "User comments retrieved successfully", comments);
                        break;
                    default:
                        JsonResponse.error(response, "Invalid path");
                }
            } catch (NumberFormatException e) {
                JsonResponse.error(response, "Invalid ID");
            }
        }
    }

    @Override
    protected void handleDoPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireLogin(request, response);
        User user = getCurrentUser(request);

        Integer gameId = getIntParameter(request, "gameId");
        String content = getRequiredParameter(request, "content");
        Integer rating = getIntParameter(request, "rating");

        try {
            commentService.createComment(user.getId(), gameId, content, rating);
            JsonResponse.success(response, "Comment created successfully");
        } catch (IllegalArgumentException e) {
            JsonResponse.error(response, e.getMessage());
        }
    }

    @Override
    protected void handleDoPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireAdmin(request, response);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length != 2) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        try {
            Integer commentId = Integer.parseInt(splits[1]);
            boolean status = Boolean.parseBoolean(getRequiredParameter(request, "status"));
            commentService.updateCommentStatus(commentId, status);
            JsonResponse.success(response, "Comment status updated successfully");
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "Invalid comment ID");
        }
    }

    @Override
    protected void handleDoDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        requireAdmin(request, response);

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        String[] splits = pathInfo.split("/");
        if (splits.length != 2) {
            JsonResponse.error(response, "Invalid path");
            return;
        }

        try {
            Integer commentId = Integer.parseInt(splits[1]);
            if (commentService.deleteComment(commentId)) {
                JsonResponse.success(response, "Comment deleted successfully");
            } else {
                JsonResponse.error(response, HttpServletResponse.SC_NOT_FOUND, "Comment not found");
            }
        } catch (NumberFormatException e) {
            JsonResponse.error(response, "Invalid comment ID");
        }
    }
} 