package com.sbeam.filter;

import com.sbeam.util.SessionUtil;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(urlPatterns = {"/user/*", "/admin/*"})
public class AuthenticationFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String requestURI = httpRequest.getRequestURI();
        boolean isLoggedIn = SessionUtil.isLoggedIn(httpRequest.getSession());
        boolean isAdmin = SessionUtil.isAdmin(httpRequest.getSession());

        if (requestURI.startsWith(httpRequest.getContextPath() + "/admin/")) {
            if (!isLoggedIn || !isAdmin) {
                httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp");
                return;
            }
        } else if (requestURI.startsWith(httpRequest.getContextPath() + "/user/")) {
            if (!isLoggedIn) {
                httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp");
                return;
            }
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
    }
} 