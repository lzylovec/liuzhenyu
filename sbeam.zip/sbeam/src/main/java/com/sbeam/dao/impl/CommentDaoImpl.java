package com.sbeam.dao.impl;

import com.sbeam.dao.CommentDao;
import com.sbeam.model.Comment;
import com.sbeam.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CommentDaoImpl implements CommentDao {
    @Override
    public Comment findById(Integer id) throws SQLException {
        String sql = "SELECT * FROM comments WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToComment(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Comment> findByGameId(Integer gameId) throws SQLException {
        String sql = "SELECT c.*, u.username FROM comments c " +
                    "JOIN users u ON c.user_id = u.id " +
                    "WHERE c.game_id = ? AND c.status = TRUE ORDER BY c.id DESC";
        List<Comment> comments = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, gameId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    comments.add(mapResultSetToCommentWithUsername(rs));
                }
            }
        }
        return comments;
    }

    @Override
    public List<Comment> findByUserId(Integer userId) throws SQLException {
        String sql = "SELECT * FROM comments WHERE user_id = ? ORDER BY id DESC";
        List<Comment> comments = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    comments.add(mapResultSetToComment(rs));
                }
            }
        }
        return comments;
    }

    @Override
    public List<Comment> findAll() throws SQLException {
        String sql = "SELECT * FROM comments ORDER BY id DESC";
        List<Comment> comments = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                comments.add(mapResultSetToComment(rs));
            }
        }
        return comments;
    }

    @Override
    public void save(Comment comment) throws SQLException {
        String sql = "INSERT INTO comments (user_id, game_id, content, rating, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, comment.getUserId());
            stmt.setInt(2, comment.getGameId());
            stmt.setString(3, comment.getContent());
            stmt.setInt(4, comment.getRating());
            stmt.setBoolean(5, comment.isStatus());
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    comment.setId(rs.getInt(1));
                }
            }
        }
    }

    @Override
    public void update(Comment comment) throws SQLException {
        String sql = "UPDATE comments SET content = ?, rating = ?, status = ? WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, comment.getContent());
            stmt.setInt(2, comment.getRating());
            stmt.setBoolean(3, comment.isStatus());
            stmt.setInt(4, comment.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void updateStatus(Integer id, boolean status) throws SQLException {
        String sql = "UPDATE comments SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBoolean(1, status);
            stmt.setInt(2, id);
            stmt.executeUpdate();
        }
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        String sql = "DELETE FROM comments WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    @Override
    public double calculateAverageRating(Integer gameId) throws SQLException {
        String sql = "SELECT AVG(rating) as avg_rating FROM comments WHERE game_id = ? AND status = TRUE";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, gameId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("avg_rating");
                }
            }
        }
        return 0.0;
    }

    private Comment mapResultSetToComment(ResultSet rs) throws SQLException {
        Comment comment = new Comment();
        comment.setId(rs.getInt("id"));
        comment.setUserId(rs.getInt("user_id"));
        comment.setGameId(rs.getInt("game_id"));
        comment.setContent(rs.getString("content"));
        comment.setRating(rs.getInt("rating"));
        comment.setStatus(rs.getBoolean("status"));
        
        // Try to get create_time if it exists
        try {
            comment.setCreateTime(rs.getTimestamp("create_time"));
        } catch (SQLException e) {
            comment.setCreateTime(new Timestamp(System.currentTimeMillis()));
        }
        return comment;
    }

    private Comment mapResultSetToCommentWithUsername(ResultSet rs) throws SQLException {
        Comment comment = new Comment();
        comment.setId(rs.getInt("id"));
        comment.setUserId(rs.getInt("user_id"));
        comment.setGameId(rs.getInt("game_id"));
        comment.setContent(rs.getString("content"));
        comment.setRating(rs.getInt("rating"));
        comment.setStatus(rs.getBoolean("status"));
        
        // Try to get create_time if it exists
        try {
            comment.setCreateTime(rs.getTimestamp("create_time"));
        } catch (SQLException e) {
            comment.setCreateTime(new Timestamp(System.currentTimeMillis()));
        }
        comment.setUsername(rs.getString("username"));
        return comment;
    }
} 