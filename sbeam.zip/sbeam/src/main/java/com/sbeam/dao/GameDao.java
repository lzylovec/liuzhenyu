package com.sbeam.dao;

import com.sbeam.model.Game;
import java.sql.SQLException;
import java.util.List;

public interface GameDao {
    Game findById(Integer id) throws SQLException;
    List<Game> findAll() throws SQLException;
    List<Game> findAllActive() throws SQLException;
    void save(Game game) throws SQLException;
    void update(Game game) throws SQLException;
    void updateStatus(Integer gameId, boolean status) throws SQLException;
    boolean delete(Integer id) throws SQLException;
} 