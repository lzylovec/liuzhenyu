package com.sbeam.dao.impl;

import com.sbeam.dao.OrderDao;
import com.sbeam.model.Order;
import com.sbeam.model.Game;
import com.sbeam.model.User;
import com.sbeam.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDaoImpl implements OrderDao {
    @Override
    public Order findById(Integer id) throws SQLException {
        String sql = "SELECT * FROM orders WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToOrder(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Order> findByUserId(Integer userId) throws SQLException {
        String sql = "SELECT o.*, g.title, g.description, g.price as game_price, g.image_url, g.download_url, g.status as game_status " +
                    "FROM orders o " +
                    "LEFT JOIN games g ON o.game_id = g.id " +
                    "WHERE o.user_id = ? " +
                    "ORDER BY o.id DESC";
        List<Order> orders = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    orders.add(mapResultSetToOrderWithGame(rs));
                }
            }
        }
        return orders;
    }

    @Override
    public List<Order> findAll() throws SQLException {
        String sql = "SELECT o.*, g.title, g.description, g.price as game_price, g.image_url, g.download_url, g.status as game_status, " +
                    "u.username " +
                    "FROM orders o " +
                    "LEFT JOIN games g ON o.game_id = g.id " +
                    "LEFT JOIN users u ON o.user_id = u.id " +
                    "ORDER BY o.id DESC";
        List<Order> orders = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                orders.add(mapResultSetToOrderWithGameAndUser(rs));
            }
        }
        return orders;
    }

    @Override
    public void save(Order order) throws SQLException {
        String sql = "INSERT INTO orders (user_id, game_id, price, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, order.getUserId());
            stmt.setInt(2, order.getGameId());
            stmt.setBigDecimal(3, order.getPrice());
            stmt.setString(4, order.getStatus());
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    order.setId(rs.getInt(1));
                }
            }
        }
    }

    @Override
    public void update(Order order) throws SQLException {
        String sql = "UPDATE orders SET user_id = ?, game_id = ?, price = ?, status = ? WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, order.getUserId());
            stmt.setInt(2, order.getGameId());
            stmt.setBigDecimal(3, order.getPrice());
            stmt.setString(4, order.getStatus());
            stmt.setInt(5, order.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        String sql = "DELETE FROM orders WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    private Order mapResultSetToOrder(ResultSet rs) throws SQLException {
        Order order = new Order();
        order.setId(rs.getInt("id"));
        order.setUserId(rs.getInt("user_id"));
        order.setGameId(rs.getInt("game_id"));
        order.setPrice(rs.getBigDecimal("price"));
        order.setStatus(rs.getString("status"));
        
        // Try to get create_time if it exists, otherwise use null
        try {
            order.setCreateTime(rs.getTimestamp("create_time"));
        } catch (SQLException e) {
            // Column doesn't exist, set to null or current time
            order.setCreateTime(new Timestamp(System.currentTimeMillis()));
        }
        return order;
    }

    private Order mapResultSetToOrderWithGame(ResultSet rs) throws SQLException {
        Order order = mapResultSetToOrder(rs);
        
        // Add game information if available
        try {
            String gameTitle = rs.getString("title");
            if (gameTitle != null) {
                Game game = new Game();
                game.setId(order.getGameId());
                game.setTitle(gameTitle);
                game.setDescription(rs.getString("description"));
                game.setPrice(rs.getBigDecimal("game_price"));
                game.setImageUrl(rs.getString("image_url"));
                game.setDownloadUrl(rs.getString("download_url"));
                game.setStatus(rs.getBoolean("game_status"));
                order.setGame(game);
            }
        } catch (SQLException e) {
            // Game information not available
        }
        
        return order;
    }

    private Order mapResultSetToOrderWithGameAndUser(ResultSet rs) throws SQLException {
        Order order = mapResultSetToOrderWithGame(rs);
        
        // Add user information if available
        try {
            String username = rs.getString("username");
            if (username != null) {
                User user = new User();
                user.setId(order.getUserId());
                user.setUsername(username);
                order.setUser(user);
            }
        } catch (SQLException e) {
            // User information not available
        }
        
        return order;
    }
} 