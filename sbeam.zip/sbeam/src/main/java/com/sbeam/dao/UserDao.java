package com.sbeam.dao;

import com.sbeam.model.User;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public interface UserDao {
    User findById(Integer id) throws SQLException;
    User findByUsername(String username) throws SQLException;
    List<User> findAll() throws SQLException;
    void save(User user) throws SQLException;
    void update(User user) throws SQLException;
    void updateStatus(Integer id, boolean status) throws SQLException;
    void updateBalance(Integer id, BigDecimal balance) throws SQLException;
    boolean delete(Integer id) throws SQLException;
}
