package com.sbeam.dao;

import com.sbeam.model.Order;
import java.sql.SQLException;
import java.util.List;

public interface OrderDao {
    Order findById(Integer id) throws SQLException;
    List<Order> findByUserId(Integer userId) throws SQLException;
    List<Order> findAll() throws SQLException;
    void save(Order order) throws SQLException;
    void update(Order order) throws SQLException;
    boolean delete(Integer id) throws SQLException;
} 