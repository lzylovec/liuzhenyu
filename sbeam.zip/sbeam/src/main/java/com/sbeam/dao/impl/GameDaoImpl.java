package com.sbeam.dao.impl;

import com.sbeam.dao.GameDao;
import com.sbeam.model.Game;
import com.sbeam.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GameDaoImpl implements GameDao {
    @Override
    public Game findById(Integer id) throws SQLException {
        String sql = "SELECT * FROM games WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToGame(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Game> findAll() throws SQLException {
        List<Game> games = new ArrayList<>();
        String sql = "SELECT * FROM games";
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                games.add(mapResultSetToGame(rs));
            }
        }
        return games;
    }

    @Override
    public List<Game> findAllActive() throws SQLException {
        List<Game> games = new ArrayList<>();
        String sql = "SELECT * FROM games WHERE status = true";
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                games.add(mapResultSetToGame(rs));
            }
        }
        return games;
    }

    @Override
    public void save(Game game) throws SQLException {
        String sql = "INSERT INTO games (title, description, price, image_url, download_url, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, game.getTitle());
            stmt.setString(2, game.getDescription());
            stmt.setBigDecimal(3, game.getPrice());
            stmt.setString(4, game.getImageUrl());
            stmt.setString(5, game.getDownloadUrl());
            stmt.setBoolean(6, game.isStatus());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    game.setId(generatedKeys.getInt(1));
                }
            }
        }
    }

    @Override
    public void update(Game game) throws SQLException {
        String sql = "UPDATE games SET title = ?, description = ?, price = ?, image_url = ?, download_url = ?, status = ? WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, game.getTitle());
            stmt.setString(2, game.getDescription());
            stmt.setBigDecimal(3, game.getPrice());
            stmt.setString(4, game.getImageUrl());
            stmt.setString(5, game.getDownloadUrl());
            stmt.setBoolean(6, game.isStatus());
            stmt.setInt(7, game.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void updateStatus(Integer gameId, boolean status) throws SQLException {
        String sql = "UPDATE games SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBoolean(1, status);
            stmt.setInt(2, gameId);
            stmt.executeUpdate();
        }
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        String sql = "DELETE FROM games WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    private Game mapResultSetToGame(ResultSet rs) throws SQLException {
        Game game = new Game();
        game.setId(rs.getInt("id"));
        
        // Handle both 'title' and 'name' columns for backward compatibility
        try {
            game.setTitle(rs.getString("title"));
        } catch (SQLException e) {
            game.setTitle(rs.getString("name"));
        }
        
        game.setDescription(rs.getString("description"));
        game.setPrice(rs.getBigDecimal("price"));
        game.setImageUrl(rs.getString("image_url"));
        game.setDownloadUrl(rs.getString("download_url"));
        game.setStatus(rs.getBoolean("status"));
        
        // Try to get created_at if it exists
        try {
            game.setCreatedAt(rs.getTimestamp("created_at"));
        } catch (SQLException e) {
            game.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        }
        return game;
    }
} 