package com.sbeam.dao.impl;

import com.sbeam.dao.CartItemDao;
import com.sbeam.dao.GameDao;
import com.sbeam.model.CartItem;
import com.sbeam.model.Game;
import com.sbeam.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartItemDaoImpl implements CartItemDao {
    private final GameDao gameDao = new GameDaoImpl();

    @Override
    public CartItem findById(Integer id) throws SQLException {
        String sql = "SELECT * FROM cart_items WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToCartItem(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<CartItem> findByUserId(Integer userId) throws SQLException {
        List<CartItem> cartItems = new ArrayList<>();
        String sql = "SELECT * FROM cart_items WHERE user_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    cartItems.add(mapResultSetToCartItem(rs));
                }
            }
        }
        return cartItems;
    }

    @Override
    public void save(CartItem cartItem) throws SQLException {
        String sql = "INSERT INTO cart_items (user_id, game_id) VALUES (?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, cartItem.getUserId());
            stmt.setInt(2, cartItem.getGameId());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    cartItem.setId(generatedKeys.getInt(1));
                }
            }
        }
    }

    @Override
    public void delete(Integer id) throws SQLException {
        String sql = "DELETE FROM cart_items WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteByUserIdAndGameId(Integer userId, Integer gameId) throws SQLException {
        String sql = "DELETE FROM cart_items WHERE user_id = ? AND game_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, gameId);
            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteAllByUserId(Integer userId) throws SQLException {
        String sql = "DELETE FROM cart_items WHERE user_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.executeUpdate();
        }
    }

    private CartItem mapResultSetToCartItem(ResultSet rs) throws SQLException {
        CartItem cartItem = new CartItem();
        cartItem.setId(rs.getInt("id"));
        cartItem.setUserId(rs.getInt("user_id"));
        cartItem.setGameId(rs.getInt("game_id"));
        cartItem.setCreatedAt(rs.getTimestamp("created_at"));

        // Load associated game
        Game game = gameDao.findById(cartItem.getGameId());
        cartItem.setGame(game);

        return cartItem;
    }
} 