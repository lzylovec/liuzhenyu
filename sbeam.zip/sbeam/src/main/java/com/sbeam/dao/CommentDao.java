package com.sbeam.dao;

import com.sbeam.model.Comment;
import java.sql.SQLException;
import java.util.List;

public interface CommentDao {
    Comment findById(Integer id) throws SQLException;
    List<Comment> findByGameId(Integer gameId) throws SQLException;
    List<Comment> findByUserId(Integer userId) throws SQLException;
    List<Comment> findAll() throws SQLException;
    void save(Comment comment) throws SQLException;
    void update(Comment comment) throws SQLException;
    void updateStatus(Integer id, boolean status) throws SQLException;
    boolean delete(Integer id) throws SQLException;
    double calculateAverageRating(Integer gameId) throws SQLException;
} 