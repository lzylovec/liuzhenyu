package com.sbeam.dao;

import com.sbeam.model.CartItem;
import java.sql.SQLException;
import java.util.List;

public interface CartItemDao {
    CartItem findById(Integer id) throws SQLException;
    List<CartItem> findByUserId(Integer userId) throws SQLException;
    void save(CartItem cartItem) throws SQLException;
    void delete(Integer id) throws SQLException;
    void deleteByUserIdAndGameId(Integer userId, Integer gameId) throws SQLException;
    void deleteAllByUserId(Integer userId) throws SQLException;
} 