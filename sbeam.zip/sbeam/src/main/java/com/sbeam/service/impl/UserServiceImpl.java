package com.sbeam.service.impl;

import com.sbeam.dao.UserDao;
import com.sbeam.dao.impl.UserDaoImpl;
import com.sbeam.model.User;
import com.sbeam.service.UserService;
import com.sbeam.util.PasswordUtil;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class UserServiceImpl implements UserService {
    private final UserDao userDao = new UserDaoImpl();

    @Override
    public User login(String username, String password) throws SQLException {
        User user = userDao.findByUsername(username);
        if (user != null && PasswordUtil.verifyPassword(password, user.getPassword())) {
            if (!user.isStatus()) {
                throw new IllegalStateException("Account is disabled");
            }
            return user;
        }
        return null;
    }

    @Override
    public User register(String username, String password) throws SQLException {
        if (userDao.findByUsername(username) != null) {
            throw new IllegalArgumentException("Username already exists");
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(PasswordUtil.hashPassword(password));
        user.setBalance(BigDecimal.ZERO);
        user.setAdmin(false);
        user.setStatus(true);
        userDao.save(user);
        return user;
    }

    @Override
    public User getUserById(Integer id) throws SQLException {
        return userDao.findById(id);
    }

    @Override
    public User getUserByUsername(String username) throws SQLException {
        return userDao.findByUsername(username);
    }

    @Override
    public List<User> getAllUsers() throws SQLException {
        return userDao.findAll();
    }

    @Override
    public void updateUserStatus(Integer userId, boolean status) throws SQLException {
        userDao.updateStatus(userId, status);
    }

    @Override
    public void updateBalance(Integer userId, BigDecimal amount) throws SQLException {
        userDao.updateBalance(userId, amount);
    }

    @Override
    public boolean deleteUser(Integer id) throws SQLException {
        return userDao.delete(id);
    }

    @Override
    public void updateUser(User user) throws SQLException {
        userDao.update(user);
    }
} 