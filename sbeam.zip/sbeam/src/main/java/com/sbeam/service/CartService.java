package com.sbeam.service;

import com.sbeam.model.CartItem;
import java.sql.SQLException;
import java.util.List;

public interface CartService {
    List<CartItem> getCartItems(Integer userId) throws SQLException;
    void addToCart(Integer userId, Integer gameId) throws SQLException;
    void removeFromCart(Integer userId, Integer gameId) throws SQLException;
    void clearCart(Integer userId) throws SQLException;
} 