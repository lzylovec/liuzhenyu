package com.sbeam.service.impl;

import com.sbeam.dao.CartItemDao;
import com.sbeam.dao.GameDao;
import com.sbeam.dao.OrderDao;
import com.sbeam.dao.UserDao;
import com.sbeam.dao.impl.CartItemDaoImpl;
import com.sbeam.dao.impl.GameDaoImpl;
import com.sbeam.dao.impl.OrderDaoImpl;
import com.sbeam.dao.impl.UserDaoImpl;
import com.sbeam.model.CartItem;
import com.sbeam.model.Game;
import com.sbeam.model.Order;
import com.sbeam.model.User;
import com.sbeam.service.OrderService;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class OrderServiceImpl implements OrderService {
    private final OrderDao orderDao = new OrderDaoImpl();
    private final UserDao userDao = new UserDaoImpl();
    private final GameDao gameDao = new GameDaoImpl();
    private final CartItemDao cartItemDao = new CartItemDaoImpl();

    @Override
    public Order getOrderById(Integer id) throws SQLException {
        return orderDao.findById(id);
    }

    @Override
    public List<Order> getOrdersByUserId(Integer userId) throws SQLException {
        return orderDao.findByUserId(userId);
    }

    @Override
    public List<Order> getAllOrders() throws SQLException {
        return orderDao.findAll();
    }

    @Override
    public void createOrder(Integer userId, Integer gameId) throws SQLException {
        User user = userDao.findById(userId);
        Game game = gameDao.findById(gameId);

        if (user == null || game == null) {
            throw new IllegalArgumentException("用户或游戏不存在");
        }

        if (!game.isStatus()) {
            throw new IllegalArgumentException("游戏暂不可购买");
        }

        // Check if user has already purchased this game
        List<Order> existingOrders = orderDao.findByUserId(userId);
        boolean alreadyPurchased = existingOrders.stream()
                .anyMatch(order -> order.getGameId().equals(gameId) && 
                         "completed".equals(order.getStatus()));
        
        if (alreadyPurchased) {
            throw new IllegalArgumentException("您已经购买过这款游戏了");
        }

        // Check if user has enough balance
        if (user.getBalance().compareTo(game.getPrice()) < 0) {
            throw new IllegalArgumentException("余额不足");
        }

        // Create order
        Order order = new Order();
        order.setUserId(userId);
        order.setGameId(gameId);
        order.setPrice(game.getPrice());
        order.setStatus("completed");
        orderDao.save(order);

        // Update user balance
        BigDecimal newBalance = user.getBalance().subtract(game.getPrice());
        userDao.updateBalance(userId, newBalance);
    }

    @Override
    public void createOrdersFromCart(Integer userId) throws SQLException {
        User user = userDao.findById(userId);
        if (user == null) {
            throw new IllegalArgumentException("用户不存在");
        }

        List<CartItem> cartItems = cartItemDao.findByUserId(userId);
        if (cartItems.isEmpty()) {
            throw new IllegalArgumentException("购物车为空");
        }

        // Get user's existing orders to check for duplicates
        List<Order> existingOrders = orderDao.findByUserId(userId);

        // Calculate total price and check for duplicates
        BigDecimal totalPrice = BigDecimal.ZERO;
        for (CartItem item : cartItems) {
            Game game = gameDao.findById(item.getGameId());
            if (game == null || !game.isStatus()) {
                throw new IllegalArgumentException("游戏不存在或暂不可购买: " + item.getGameId());
            }
            
            // Check if user has already purchased this game
            boolean alreadyPurchased = existingOrders.stream()
                    .anyMatch(order -> order.getGameId().equals(item.getGameId()) && 
                             "completed".equals(order.getStatus()));
            
            if (alreadyPurchased) {
                throw new IllegalArgumentException("购物车中包含您已购买的游戏: " + game.getTitle());
            }
            
            totalPrice = totalPrice.add(game.getPrice());
        }

        // Check if user has enough balance
        if (user.getBalance().compareTo(totalPrice) < 0) {
            throw new IllegalArgumentException("余额不足");
        }

        // Create orders for each cart item
        for (CartItem item : cartItems) {
            Game game = gameDao.findById(item.getGameId());
            Order order = new Order();
            order.setUserId(userId);
            order.setGameId(game.getId());
            order.setPrice(game.getPrice());
            order.setStatus("completed");
            orderDao.save(order);
        }

        // Update user balance
        BigDecimal newBalance = user.getBalance().subtract(totalPrice);
        userDao.updateBalance(userId, newBalance);

        // Clear cart
        cartItemDao.deleteAllByUserId(userId);
    }

    @Override
    public boolean deleteOrder(Integer id) throws SQLException {
        return orderDao.delete(id);
    }
} 