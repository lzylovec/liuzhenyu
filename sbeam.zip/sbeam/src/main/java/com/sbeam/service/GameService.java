package com.sbeam.service;

import com.sbeam.model.Game;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.http.Part;
import java.io.IOException;

public interface GameService {
    Game getGameById(Integer id) throws SQLException;
    List<Game> getAllGames() throws SQLException;
    List<Game> getAllActiveGames() throws SQLException;
    Game createGame(Game game, Part imageFile, Part gameFile) throws SQLException, IOException;
    void updateGame(Game game, Part imageFile, Part gameFile) throws SQLException, IOException;
    void updateGameStatus(Integer gameId, boolean status) throws SQLException;
    boolean deleteGame(Integer id) throws SQLException;
} 