package com.sbeam.service.impl;

import com.sbeam.dao.CartItemDao;
import com.sbeam.dao.GameDao;
import com.sbeam.dao.OrderDao;
import com.sbeam.dao.impl.CartItemDaoImpl;
import com.sbeam.dao.impl.GameDaoImpl;
import com.sbeam.dao.impl.OrderDaoImpl;
import com.sbeam.model.CartItem;
import com.sbeam.model.Game;
import com.sbeam.model.Order;
import com.sbeam.service.CartService;

import java.sql.SQLException;
import java.util.List;

public class CartServiceImpl implements CartService {
    private final CartItemDao cartItemDao = new CartItemDaoImpl();
    private final GameDao gameDao = new GameDaoImpl();
    private final OrderDao orderDao = new OrderDaoImpl();

    @Override
    public List<CartItem> getCartItems(Integer userId) throws SQLException {
        return cartItemDao.findByUserId(userId);
    }

    @Override
    public void addToCart(Integer userId, Integer gameId) throws SQLException {
        // Check if game exists and is active
        Game game = gameDao.findById(gameId);
        if (game == null || !game.isStatus()) {
            throw new IllegalArgumentException("游戏不存在或暂不可购买");
        }

        // Check if user has already purchased this game
        List<Order> existingOrders = orderDao.findByUserId(userId);
        boolean alreadyPurchased = existingOrders.stream()
                .anyMatch(order -> order.getGameId().equals(gameId) && 
                         "completed".equals(order.getStatus()));
        
        if (alreadyPurchased) {
            throw new IllegalArgumentException("您已经购买过这款游戏了");
        }

        // Check if game is already in cart
        List<CartItem> cartItems = cartItemDao.findByUserId(userId);
        boolean alreadyInCart = cartItems.stream()
                .anyMatch(item -> item.getGameId().equals(gameId));
        
        if (alreadyInCart) {
            throw new IllegalArgumentException("游戏已在购物车中");
        }

        CartItem cartItem = new CartItem();
        cartItem.setUserId(userId);
        cartItem.setGameId(gameId);
        cartItemDao.save(cartItem);
    }

    @Override
    public void removeFromCart(Integer userId, Integer gameId) throws SQLException {
        cartItemDao.deleteByUserIdAndGameId(userId, gameId);
    }

    @Override
    public void clearCart(Integer userId) throws SQLException {
        cartItemDao.deleteAllByUserId(userId);
    }
} 