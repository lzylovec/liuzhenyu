package com.sbeam.service;

import com.sbeam.model.Comment;
import java.sql.SQLException;
import java.util.List;

public interface CommentService {
    Comment getCommentById(Integer id) throws SQLException;
    List<Comment> getCommentsByGameId(Integer gameId) throws SQLException;
    List<Comment> getCommentsByUserId(Integer userId) throws SQLException;
    List<Comment> getAllComments() throws SQLException;
    void createComment(Integer userId, Integer gameId, String content, Integer rating) throws SQLException;
    void updateCommentStatus(Integer commentId, boolean status) throws SQLException;
    boolean deleteComment(Integer id) throws SQLException;
    double getGameAverageRating(Integer gameId) throws SQLException;
} 