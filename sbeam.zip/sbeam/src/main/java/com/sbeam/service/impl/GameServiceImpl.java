package com.sbeam.service.impl;

import com.sbeam.dao.GameDao;
import com.sbeam.dao.impl.GameDaoImpl;
import com.sbeam.model.Game;
import com.sbeam.service.GameService;
import com.sbeam.util.FileUtil;

import javax.servlet.http.Part;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class GameServiceImpl implements GameService {
    private final GameDao gameDao = new GameDaoImpl();

    @Override
    public Game getGameById(Integer id) throws SQLException {
        return gameDao.findById(id);
    }

    @Override
    public List<Game> getAllGames() throws SQLException {
        return gameDao.findAll();
    }

    @Override
    public List<Game> getAllActiveGames() throws SQLException {
        return gameDao.findAllActive();
    }

    @Override
    public Game createGame(Game game, Part imageFile, Part gameFile) throws SQLException, IOException {
        if (imageFile != null && imageFile.getSize() > 0) {
            String imageFileName = FileUtil.saveGameImage(imageFile);
            game.setImageUrl(imageFileName);
        }

        if (gameFile != null && gameFile.getSize() > 0) {
            String gameFileName = FileUtil.saveGameFile(gameFile);
            game.setDownloadUrl(gameFileName);
        }

        gameDao.save(game);
        return game;
    }

    @Override
    public void updateGame(Game game, Part imageFile, Part gameFile) throws SQLException, IOException {
        Game existingGame = gameDao.findById(game.getId());
        if (existingGame == null) {
            throw new IllegalArgumentException("Game not found");
        }

        if (imageFile != null && imageFile.getSize() > 0) {
            // Delete old image if exists
            if (existingGame.getImageUrl() != null) {
                FileUtil.deleteFile(existingGame.getImageUrl(), true);
            }
            String imageFileName = FileUtil.saveGameImage(imageFile);
            game.setImageUrl(imageFileName);
        } else {
            game.setImageUrl(existingGame.getImageUrl());
        }

        if (gameFile != null && gameFile.getSize() > 0) {
            // Delete old game file if exists
            if (existingGame.getDownloadUrl() != null) {
                FileUtil.deleteFile(existingGame.getDownloadUrl(), false);
            }
            String gameFileName = FileUtil.saveGameFile(gameFile);
            game.setDownloadUrl(gameFileName);
        } else {
            game.setDownloadUrl(existingGame.getDownloadUrl());
        }

        gameDao.update(game);
    }

    @Override
    public void updateGameStatus(Integer gameId, boolean status) throws SQLException {
        gameDao.updateStatus(gameId, status);
    }

    @Override
    public boolean deleteGame(Integer id) throws SQLException {
        Game game = gameDao.findById(id);
        if (game != null) {
            // Delete associated files
            if (game.getImageUrl() != null) {
                FileUtil.deleteFile(game.getImageUrl(), true);
            }
            if (game.getDownloadUrl() != null) {
                FileUtil.deleteFile(game.getDownloadUrl(), false);
            }
            return gameDao.delete(id);
        }
        return false;
    }
} 