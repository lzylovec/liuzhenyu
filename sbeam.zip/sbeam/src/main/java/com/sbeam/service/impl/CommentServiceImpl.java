package com.sbeam.service.impl;

import com.sbeam.dao.CommentDao;
import com.sbeam.dao.GameDao;
import com.sbeam.dao.OrderDao;
import com.sbeam.dao.impl.CommentDaoImpl;
import com.sbeam.dao.impl.GameDaoImpl;
import com.sbeam.dao.impl.OrderDaoImpl;
import com.sbeam.model.Comment;
import com.sbeam.model.Game;
import com.sbeam.model.Order;
import com.sbeam.service.CommentService;

import java.sql.SQLException;
import java.util.List;

public class CommentServiceImpl implements CommentService {
    private final CommentDao commentDao = new CommentDaoImpl();
    private final GameDao gameDao = new GameDaoImpl();
    private final OrderDao orderDao = new OrderDaoImpl();

    @Override
    public Comment getCommentById(Integer id) throws SQLException {
        return commentDao.findById(id);
    }

    @Override
    public List<Comment> getCommentsByGameId(Integer gameId) throws SQLException {
        return commentDao.findByGameId(gameId);
    }

    @Override
    public List<Comment> getCommentsByUserId(Integer userId) throws SQLException {
        return commentDao.findByUserId(userId);
    }

    @Override
    public List<Comment> getAllComments() throws SQLException {
        return commentDao.findAll();
    }

    @Override
    public void createComment(Integer userId, Integer gameId, String content, Integer rating) throws SQLException {
        // Check if game exists
        Game game = gameDao.findById(gameId);
        if (game == null) {
            throw new IllegalArgumentException("Game not found");
        }

        // Check if user has purchased the game
        List<Order> orders = orderDao.findByUserId(userId);
        boolean hasPurchased = orders.stream()
                .anyMatch(order -> order.getGameId().equals(gameId));
        if (!hasPurchased) {
            throw new IllegalArgumentException("You must purchase the game before commenting");
        }

        // Validate rating
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5");
        }

        Comment comment = new Comment();
        comment.setUserId(userId);
        comment.setGameId(gameId);
        comment.setContent(content);
        comment.setRating(rating);
        comment.setStatus(true);
        commentDao.save(comment);
    }

    @Override
    public void updateCommentStatus(Integer commentId, boolean status) throws SQLException {
        commentDao.updateStatus(commentId, status);
    }

    @Override
    public boolean deleteComment(Integer id) throws SQLException {
        return commentDao.delete(id);
    }

    @Override
    public double getGameAverageRating(Integer gameId) throws SQLException {
        return commentDao.calculateAverageRating(gameId);
    }
} 