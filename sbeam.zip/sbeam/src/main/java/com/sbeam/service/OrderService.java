package com.sbeam.service;

import com.sbeam.model.Order;
import java.sql.SQLException;
import java.util.List;

public interface OrderService {
    Order getOrderById(Integer id) throws SQLException;
    List<Order> getOrdersByUserId(Integer userId) throws SQLException;
    List<Order> getAllOrders() throws SQLException;
    void createOrder(Integer userId, Integer gameId) throws SQLException;
    void createOrdersFromCart(Integer userId) throws SQLException;
    boolean deleteOrder(Integer id) throws SQLException;
} 