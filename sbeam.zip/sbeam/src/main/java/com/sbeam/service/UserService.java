package com.sbeam.service;

import com.sbeam.model.User;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public interface UserService {
    User login(String username, String password) throws SQLException;
    User register(String username, String password) throws SQLException;
    User getUserById(Integer id) throws SQLException;
    User getUserByUsername(String username) throws SQLException;
    List<User> getAllUsers() throws SQLException;
    void updateUserStatus(Integer userId, boolean status) throws SQLException;
    void updateBalance(Integer userId, BigDecimal amount) throws SQLException;
    boolean deleteUser(Integer id) throws SQLException;
    void updateUser(User user) throws SQLException;
} 