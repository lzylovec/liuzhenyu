-- Create database
CREATE DATABASE IF NOT EXISTS sbeam DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE sbeam;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(64) NOT NULL,
    balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    is_admin BOOLEAN NOT NULL DEFAULT FALSE,
    status BOOLEAN NOT NULL DEFAULT TRUE
);

-- Create games table
CREATE TABLE IF NOT EXISTS games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image_url VARCHAR(255),
    download_url VARCHAR(255),
    status BOOLEAN NOT NULL DEFAULT TRUE
);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    game_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (game_id) REFERENCES games(id),
    UNIQUE KEY unique_user_game (user_id, game_id)
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    game_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'completed',
    create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (game_id) REFERENCES games(id)
);

-- Create comments table
CREATE TABLE IF NOT EXISTS comments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    game_id INT NOT NULL,
    content TEXT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    status BOOLEAN NOT NULL DEFAULT TRUE,
    create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (game_id) REFERENCES games(id)
);

-- Insert admin user (password: admin123)
INSERT INTO users (username, password, is_admin, status)
VALUES ('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', TRUE, TRUE)
ON DUPLICATE KEY UPDATE id = id;

-- Insert some sample games
INSERT INTO games (name, description, price, status)
VALUES 
    ('Sample Game 1', 'This is a sample game 1', 29.99, TRUE),
    ('Sample Game 2', 'This is a sample game 2', 19.99, TRUE),
    ('Sample Game 3', 'This is a sample game 3', 39.99, TRUE)
ON DUPLICATE KEY UPDATE id = id;

-- Insert some sample comments
INSERT INTO comments (user_id, game_id, content, rating, status) VALUES 
(1, 1, 'Great game! Highly recommended.', 5, TRUE),
(1, 2, 'Good game but could be better.', 4, TRUE),
(1, 3, 'Amazing graphics and gameplay!', 5, TRUE); 