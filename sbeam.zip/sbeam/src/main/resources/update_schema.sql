-- Database schema updates for SBeam
-- This script adds missing columns to existing tables

USE sbeam;

-- Add create_time column to orders table if it doesn't exist
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE table_name = 'orders' 
     AND table_schema = 'sbeam' 
     AND column_name = 'create_time') > 0,
    'SELECT 1',
    'ALTER TABLE orders ADD COLUMN create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add create_time column to comments table if it doesn't exist
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE table_name = 'comments' 
     AND table_schema = 'sbeam' 
     AND column_name = 'create_time') > 0,
    'SELECT 1',
    'ALTER TABLE comments ADD COLUMN create_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add created_at column to games table if it doesn't exist
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE table_name = 'games' 
     AND table_schema = 'sbeam' 
     AND column_name = 'created_at') > 0,
    'SELECT 1',
    'ALTER TABLE games ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Update games table name column to title if it exists
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE table_name = 'games' 
     AND table_schema = 'sbeam' 
     AND column_name = 'name') > 0,
    'ALTER TABLE games CHANGE COLUMN name title VARCHAR(100) NOT NULL',
    'SELECT 1'
));
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verify table structures
SELECT 'orders table structure:' as info;
DESCRIBE orders;

SELECT 'comments table structure:' as info;
DESCRIBE comments;

SELECT 'games table structure:' as info;
DESCRIBE games; 