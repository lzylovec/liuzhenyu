// 全局API路径
// 使用页面中已定义的contextPath变量，如果不存在则计算
const contextPath = window.contextPath || window.location.pathname.substring(0, window.location.pathname.indexOf('/', 1)) || '';
const API_BASE_URL = contextPath + '/api';

// 转换API响应格式的辅助函数
const convertApiResponse = (jsonData, status) => {
    // 防止jsonData为null或undefined
    if (!jsonData) {
        return { 
            success: false, 
            message: status === 404 ? '请求的资源不存在' : '服务器返回空数据', 
            data: null,
            status: status
        };
    }
    
    // 检查status字段是否存在
    const isSuccess = jsonData.status === 200 || jsonData.status === 'OK' || jsonData.success === true;
    
    return {
        success: isSuccess,
        message: jsonData.message || (isSuccess ? '操作成功' : '操作失败'),
        data: jsonData.data || null,
        status: status
    };
};

// 处理API请求的通用函数
const fetchApi = async (url, options = {}) => {
    try {
        // 记录请求URL，避免重复请求
        console.log(`发起API请求: ${url}`);
        
        // 检查URL是否已经请求过且返回404
        if (fetchApi.notFoundUrls && fetchApi.notFoundUrls.includes(url)) {
            console.log(`URL已知404，跳过请求: ${url}`);
            return convertApiResponse(null, 404);
        }
        
        // 发起请求
        const response = await fetch(url, options);
        const status = response.status;
        
        // 如果是404错误，记录该URL
        if (status === 404) {
            console.error(`API请求失败: ${url} - 404 Not Found`);
            if (!fetchApi.notFoundUrls) {
                fetchApi.notFoundUrls = [];
            }
            if (!fetchApi.notFoundUrls.includes(url)) {
                fetchApi.notFoundUrls.push(url);
            }
            return convertApiResponse(null, 404);
        }
        
        // 尝试解析JSON
        try {
            const jsonData = await response.json();
            return convertApiResponse(jsonData, status);
        } catch (parseError) {
            console.error(`解析JSON失败: ${url}`, parseError);
            return convertApiResponse(null, status);
        }
    } catch (error) {
        console.error(`网络请求失败: ${url}`, error);
        return { success: false, message: '网络连接错误', data: null, status: 0 };
    }
};

// 用户相关API
const userApi = {
    login: async (username, password) => {
        return fetchApi(API_BASE_URL + '/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'username=' + encodeURIComponent(username) + '&password=' + encodeURIComponent(password),
        });
    },
    
    register: async (username, password) => {
        return fetchApi(`${API_BASE_URL}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`,
        });
    },
    
    logout: async () => {
        return fetchApi(API_BASE_URL + '/logout', {
            method: 'POST',
        });
    },
    
    getCurrentUser: async () => {
        return fetchApi(API_BASE_URL + '/login');
    },
    
    getAllUsers: async () => {
        return fetchApi(API_BASE_URL + '/users/');
    },
    
    getUserById: async (id) => {
        return fetchApi(API_BASE_URL + '/users/' + id);
    },
    
    updateUser: async (id, userData) => {
        const params = new URLSearchParams();
        if (userData.username !== undefined) params.append('username', userData.username);
        if (userData.password !== undefined) params.append('password', userData.password);
        if (userData.balance !== undefined) params.append('balance', userData.balance);
        if (userData.admin !== undefined) params.append('admin', userData.admin);
        if (userData.status !== undefined) params.append('status', userData.status);
        
        return fetchApi(API_BASE_URL + '/users/' + id, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: params.toString(),
        });
    },
    
    updateUserStatus: async (id, status) => {
        console.log('updateUserStatus called with:', { id, status });
        const body = 'status=' + status;
        console.log('Request body:', body);
        
        return fetchApi(API_BASE_URL + '/users/' + id + '/status', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: body,
        });
    }
};

// 游戏相关API
const gameApi = {
    getAllGames: async (showAll = false) => {
        console.log('调用getAllGames API...');
        const url = showAll ? `${API_BASE_URL}/games/?showAll=true` : `${API_BASE_URL}/games/`;
        return fetchApi(url);
    },
    
    getGameById: async (id) => {
        return fetchApi(`${API_BASE_URL}/games/${id}`);
    },
    
    createGame: async (formData) => {
        return fetchApi(`${API_BASE_URL}/games/`, {
            method: 'POST',
            body: formData,
        });
    },
    
    updateGame: async (gameId, formData) => {
        return fetchApi(`${API_BASE_URL}/games/${gameId}`, {
            method: 'PUT',
            body: formData,
        });
    },
    
    updateGameStatus: async (gameId, status) => {
        return fetchApi(`${API_BASE_URL}/games/${gameId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=status&status=${status}`,
        });
    },
    
    deleteGame: async (gameId) => {
        return fetchApi(`${API_BASE_URL}/games/${gameId}`, {
            method: 'DELETE',
        });
    }
};

// 购物车相关API
const cartApi = {
    getCartItems: async () => {
        return fetchApi(`${API_BASE_URL}/cart/`);
    },
    
    addToCart: async (gameId) => {
        return fetchApi(`${API_BASE_URL}/cart/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `gameId=${gameId}`,
        });
    },
    
    removeFromCart: async (gameId) => {
        return fetchApi(`${API_BASE_URL}/cart/${gameId}`, {
            method: 'DELETE',
        });
    },
    
    clearCart: async () => {
        return fetchApi(`${API_BASE_URL}/cart/`, {
            method: 'DELETE',
        });
    }
};

// 订单相关API
const orderApi = {
    createOrder: async (gameId) => {
        return fetchApi(`${API_BASE_URL}/orders/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `gameId=${gameId}`,
        });
    },
    
    createOrdersFromCart: async () => {
        return fetchApi(`${API_BASE_URL}/orders/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=cart',
        });
    },
    
    getUserOrders: async () => {
        return fetchApi(`${API_BASE_URL}/orders/`);
    }
};

// 评论相关API
const commentApi = {
    getGameComments: async (gameId) => {
        return fetchApi(`${API_BASE_URL}/comments/game/${gameId}`);
    },
    
    addComment: async (gameId, content, rating) => {
        return fetchApi(`${API_BASE_URL}/comments/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `gameId=${gameId}&content=${encodeURIComponent(content)}&rating=${rating}`,
        });
    }
};

// 工具函数
const utils = {
    formatPrice: (price) => {
        return '¥' + parseFloat(price).toFixed(2);
    },
    
    showMessage: (message, isError = false) => {
        console.log(`显示消息: ${message}, 是否错误: ${isError}`);
        
        let messageElement = document.getElementById('message');
        
        // 如果消息元素不存在，创建一个
        if (!messageElement) {
            messageElement = document.createElement('div');
            messageElement.id = 'message';
            messageElement.style.position = 'fixed';
            messageElement.style.top = '20px';
            messageElement.style.left = '50%';
            messageElement.style.transform = 'translateX(-50%)';
            messageElement.style.padding = '10px 20px';
            messageElement.style.borderRadius = '5px';
            messageElement.style.zIndex = '1000';
            messageElement.style.display = 'none';
            document.body.appendChild(messageElement);
        }
        
        messageElement.textContent = message;
        messageElement.className = isError ? 'error' : 'success';
        messageElement.style.backgroundColor = isError ? '#f8d7da' : '#d4edda';
        messageElement.style.color = isError ? '#721c24' : '#155724';
        messageElement.style.border = isError ? '1px solid #f5c6cb' : '1px solid #c3e6cb';
        messageElement.style.display = 'block';
        
        setTimeout(() => {
            messageElement.style.display = 'none';
        }, 3000);
    }
};

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', async () => {
    console.log('页面加载完成，开始检查用户登录状态');
    
    try {
        // 检查用户登录状态
        const userResponse = await userApi.getCurrentUser();
        console.log('获取当前用户响应:', userResponse);
        
        const navElement = document.getElementById('nav-links');
        const userInfoElement = document.getElementById('user-info');
        if (!navElement) {
            console.error('导航元素不存在');
            return;
        }
        
        if (userResponse.success && userResponse.data) {
            // 用户已登录
            const user = userResponse.data;
            console.log('用户已登录:', user.username);
            
            // 显示用户信息
            if (userInfoElement) {
                const balance = utils ? utils.formatPrice(user.balance || 0) : ('¥' + (user.balance || 0).toFixed(2));
                userInfoElement.innerHTML = 
                    '<div class="user-details">' +
                        '<span class="username">' + user.username + '</span>' +
                        '<span class="balance">余额: ' + balance + '</span>' +
                    '</div>';
                userInfoElement.style.display = 'block';
            }
            
            if (user.admin) {
                // 管理员导航
                navElement.innerHTML = 
                    '<li><a href="' + contextPath + '/index.jsp">首页</a></li>' +
                    '<li><a href="' + contextPath + '/library.jsp">游戏库</a></li>' +
                    '<li><a href="' + contextPath + '/cart.jsp">购物车</a></li>' +
                    '<li><a href="' + contextPath + '/admin-users.jsp">用户管理</a></li>' +
                    '<li><a href="' + contextPath + '/admin-games.jsp">游戏管理</a></li>' +
                    '<li><a href="' + contextPath + '/orders.jsp">订单管理</a></li>' +
                    '<li><a href="#" id="logout-link">退出</a></li>';
            } else {
                // 普通用户导航
                navElement.innerHTML = 
                    '<li><a href="' + contextPath + '/index.jsp">首页</a></li>' +
                    '<li><a href="' + contextPath + '/library.jsp">游戏库</a></li>' +
                    '<li><a href="' + contextPath + '/cart.jsp">购物车</a></li>' +
                    '<li><a href="' + contextPath + '/orders.jsp">我的订单</a></li>' +
                    '<li><a href="' + contextPath + '/profile.jsp">个人信息</a></li>' +
                    '<li><a href="#" id="logout-link">退出</a></li>';
            }
            
            // 添加退出登录事件
            const logoutLink = document.getElementById('logout-link');
            if (logoutLink) {
                logoutLink.addEventListener('click', async (e) => {
                    e.preventDefault();
                    console.log('尝试退出登录');
                    const logoutResponse = await userApi.logout();
                    console.log('退出登录响应:', logoutResponse);
                    if (logoutResponse.success) {
                        utils.showMessage('退出成功，正在跳转...');
                        setTimeout(() => {
                            window.location.href = contextPath + '/index.jsp';
                        }, 1000);
                    } else {
                        utils.showMessage('退出失败: ' + (logoutResponse.message || '未知错误'), true);
                    }
                });
            } else {
                console.error('退出链接元素不存在');
            }
        } else {
            // 用户未登录
            console.log('用户未登录');
            navElement.innerHTML = 
                '<li><a href="' + contextPath + '/index.jsp">首页</a></li>' +
                '<li><a href="' + contextPath + '/login.jsp">登录</a></li>' +
                '<li><a href="' + contextPath + '/register.jsp">注册</a></li>';
                
            if (userInfoElement) {
                userInfoElement.style.display = 'none';
            }
        }
    } catch (error) {
        console.error('检查用户登录状态时出错:', error);
    }
}); 