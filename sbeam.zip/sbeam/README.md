# SBeam 游戏商城

一个简单的游戏商城系统，基于Java JSP实现。

## 功能特性

### 管理员功能
- 游戏管理（上架、编辑、下架）
- 用户管理（查看、禁用/启用账户）
- 评论管理（删除不当评论）

### 用户功能
- 账户系统（注册、登录）
- 游戏浏览和搜索
- 购物车管理
- 游戏购买（使用系统余额）
- 游戏下载
- 游戏评论（发表评论、评分）

## 技术栈
- Java
- JSP/Servlet
- MySQL
- HTML/CSS/JavaScript
- JDBC

## 数据库设计

### users 表
```sql
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    balance DECIMAL(10,2) DEFAULT 0.00,
    is_admin BOOLEAN DEFAULT FALSE,
    status BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### games 表
```sql
CREATE TABLE games (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image_url VARCHAR(255),
    download_url VARCHAR(255),
    status BOOLEAN DEFAULT TRUE,
    avg_rating DECIMAL(3,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### cart_items 表
```sql
CREATE TABLE cart_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    game_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (game_id) REFERENCES games(id)
);
```

### orders 表
```sql
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    game_id INT,
    price DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (game_id) REFERENCES games(id)
);
```

### comments 表
```sql
CREATE TABLE comments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    game_id INT,
    content TEXT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    status BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (game_id) REFERENCES games(id)
);
```

## 项目结构
```
src/
├── main/
│   ├── java/
│   │   └── com/
│   │       └── sbeam/
│   │           ├── controller/    # Servlet控制器
│   │           ├── dao/          # 数据访问层
│   │           ├── model/        # 实体类
│   │           ├── service/      # 业务逻辑层
│   │           └── util/         # 工具类
│   ├── resources/
│   │   └── database.properties   # 数据库配置
│   └── webapp/
│       ├── WEB-INF/
│       │   └── web.xml          # Web应用配置
│       ├── admin/               # 管理员页面
│       ├── assets/              # 静态资源
│       │   ├── css/
│       │   ├── js/
│       │   └── images/
│       └── user/                # 用户页面
```

## 开发环境要求
- JDK 8+
- MySQL 5.7+
- Tomcat 8+
- Maven 3.6+ 