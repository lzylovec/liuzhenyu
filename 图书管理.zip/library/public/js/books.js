// 全局变量，用于存储当前编辑的图书ID
let currentEditBookId = null;

// 加载图书列表
async function loadBooks() {
    try {
        const response = await fetch('/api/books');
        const data = await response.json();

        if (data.success) {
            const tableBody = document.getElementById('books-table').querySelector('tbody');
            tableBody.innerHTML = '';

            if (data.books.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="10" class="text-center">暂无图书数据</td></tr>';
                return;
            }

            data.books.forEach(book => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${book.id}</td>
                    <td>${book.title}</td>
                    <td>${book.author}</td>
                    <td>${book.isbn}</td>
                    <td>${book.category || '-'}</td>
                    <td>${book.quantity}</td>
                    <td>${book.available}</td>
                    <td>${book.publisher || '-'}</td>
                    <td>${book.publish_date ? new Date(book.publish_date).toLocaleDateString() : '-'}</td>
                    <td>
                        <button class="action-btn edit-btn" onclick="editBook(${book.id})">编辑</button>
                        <button class="action-btn delete-btn" onclick="deleteBook(${book.id})">删除</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        }
    } catch (error) {
        console.error('Error loading books:', error);
        document.getElementById('books-table').querySelector('tbody').innerHTML = '<tr><td colspan="10" class="text-center">加载失败，请重试</td></tr>';
    }
}

// 添加或更新图书
async function saveBook(event) {
    event.preventDefault();

    const bookData = {
        title: document.getElementById('title').value,
        author: document.getElementById('author').value,
        isbn: document.getElementById('isbn').value,
        category: document.getElementById('category').value,
        quantity: parseInt(document.getElementById('quantity').value),
        publisher: document.getElementById('publisher').value,
        publish_date: document.getElementById('publish_date').value
    };

    try {
        let response;
        if (currentEditBookId) {
            // 更新现有图书
            response = await fetch(`/api/books/${currentEditBookId}`, {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(bookData)
            });
        } else {
            // 添加新图书
            response = await fetch('/api/books', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(bookData)
            });
        }

        const data = await response.json();
        if (data.success) {
            // 重置表单
            document.getElementById('book-form').reset();
            currentEditBookId = null;
            document.getElementById('cancel-btn').style.display = 'none';
            // 重新加载图书列表
            loadBooks();
            alert(currentEditBookId ? '图书更新成功' : '图书添加成功');
        } else {
            alert(data.message || '操作失败，请重试');
        }
    } catch (error) {
        console.error('Error saving book:', error);
        alert('保存失败，请重试');
    }
}

// 编辑图书
async function editBook(id) {
    try {
        const response = await fetch(`/api/books/${id}`);
        const data = await response.json();

        if (data.success) {
            const book = data.book;
            currentEditBookId = id;

            // 填充表单
            document.getElementById('title').value = book.title;
            document.getElementById('author').value = book.author;
            document.getElementById('isbn').value = book.isbn;
            document.getElementById('category').value = book.category || '';
            document.getElementById('quantity').value = book.quantity;
            document.getElementById('publisher').value = book.publisher || '';
            document.getElementById('publish_date').value = book.publish_date ? book.publish_date.split('T')[0] : '';

            // 显示取消按钮
            document.getElementById('cancel-btn').style.display = 'inline-block';

            // 滚动到表单
            document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
        } else {
            alert(data.message || '获取图书信息失败');
        }
    } catch (error) {
        console.error('Error loading book for edit:', error);
        alert('加载图书信息失败，请重试');
    }
}

// 删除图书
async function deleteBook(id) {
    if (!confirm('确定要删除这本图书吗？此操作不可撤销。')) {
        return;
    }

    try {
        const response = await fetch(`/api/books/${id}`, {
            method: 'DELETE'
        });

        const data = await response.json();
        if (data.success) {
            loadBooks();
            alert('图书删除成功');
        } else {
            alert(data.message || '删除失败，请重试');
        }
    } catch (error) {
        console.error('Error deleting book:', error);
        alert('删除失败，请重试');
    }
}

// 取消编辑
function cancelEdit() {
    document.getElementById('book-form').reset();
    currentEditBookId = null;
    document.getElementById('cancel-btn').style.display = 'none';
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 加载图书列表
    loadBooks();

    // 绑定表单提交事件
    document.getElementById('book-form').addEventListener('submit', saveBook);

    // 绑定取消按钮事件
    document.getElementById('cancel-btn').addEventListener('click', cancelEdit);
});