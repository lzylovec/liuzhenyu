// 加载挂失报告列表
async function loadLossReports() {
    try {
        const response = await fetch('/api/loss-reports');
        const data = await response.json();

        if (data.success) {
            const tableBody = document.getElementById('loss-table').querySelector('tbody');
            tableBody.innerHTML = '';

            if (data.reports.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="7" class="text-center">暂无挂失报告</td></tr>';
                return;
            }

            data.reports.forEach(report => {
                const row = document.createElement('tr');
                // 设置状态样式
                let statusClass = '';
                if (report.status === 'pending') statusClass = 'style="color: orange;"';
                else if (report.status === 'approved') statusClass = 'style="color: green;"';
                else statusClass = 'style="color: red;"';

                row.innerHTML = `
                    <td>${report.id}</td>
                    <td>${report.user_id}</td>
                    <td>${report.book_id}</td>
                    <td>${new Date(report.report_date).toLocaleString()}</td>
                    <td ${statusClass}>
                        ${report.status === 'pending' ? '待处理' : report.status === 'approved' ? '已批准' : '已拒绝'}
                    </td>
                    <td>${report.description || '-'}</td>
                    <td>
                        ${report.status === 'pending' ? `
                            <button class="action-btn edit-btn" onclick="approveReport(${report.id})">批准</button>
                            <button class="action-btn delete-btn" onclick="rejectReport(${report.id})">拒绝</button>
                        ` : '-'}
                    </td>
                `;
                tableBody.appendChild(row);
            });
        }
    } catch (error) {
        console.error('Error loading loss reports:', error);
        document.getElementById('loss-table').querySelector('tbody').innerHTML = '<tr><td colspan="7" class="text-center">加载失败，请重试</td></tr>';
    }
}

// 提交挂失报告
async function submitLossReport(event) {
    event.preventDefault();

    const reportData = {
        user_id: parseInt(document.getElementById('user-id-loss').value),
        book_id: parseInt(document.getElementById('book-id-loss').value),
        description: document.getElementById('loss-description').value
    };

    try {
        const response = await fetch('/api/loss-reports', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(reportData)
        });

        const data = await response.json();
        if (data.success) {
            // 重置表单
            document.getElementById('loss-form').reset();
            // 重新加载挂失报告列表
            loadLossReports();
            alert('挂失报告提交成功');
        } else {
            alert(data.message || '提交失败，请重试');
        }
    } catch (error) {
        console.error('Error submitting loss report:', error);
        alert('提交失败，请重试');
    }
}

// 批准挂失报告
async function approveReport(id) {
    try {
        const response = await fetch(`/api/loss-reports/${id}/approve`, {
            method: 'PUT'
        });

        const data = await response.json();
        if (data.success) {
            loadLossReports();
            alert('挂失报告已批准');
        } else {
            alert(data.message || '操作失败，请重试');
        }
    } catch (error) {
        console.error('Error approving loss report:', error);
        alert('操作失败，请重试');
    }
}

// 拒绝挂失报告
async function rejectReport(id) {
    try {
        const response = await fetch(`/api/loss-reports/${id}/reject`, {
            method: 'PUT'
        });

        const data = await response.json();
        if (data.success) {
            loadLossReports();
            alert('挂失报告已拒绝');
        } else {
            alert(data.message || '操作失败，请重试');
        }
    } catch (error) {
        console.error('Error rejecting loss report:', error);
        alert('操作失败，请重试');
    }
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 加载挂失报告列表
    loadLossReports();

    // 绑定挂失报告提交事件
    document.getElementById('loss-form').addEventListener('submit', submitLossReport);
});