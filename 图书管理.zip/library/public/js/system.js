// 加载系统配置
async function loadSystemConfig() {
    try {
        const response = await fetch('/api/system/config');
        const data = await response.json();

        if (data.success) {
            document.getElementById('max-borrow-days').value = data.config.max_borrow_days || 30;
            document.getElementById('max-books-per-user').value = data.config.max_books_per_user || 5;
            document.getElementById('overdue-fee').value = data.config.overdue_fee || 0.5;
        }
    } catch (error) {
        console.error('Error loading system config:', error);
        alert('加载系统配置失败，请重试');
    }
}

// 保存系统配置
async function saveSystemConfig(event) {
    event.preventDefault();

    const configData = {
        max_borrow_days: parseInt(document.getElementById('max-borrow-days').value),
        max_books_per_user: parseInt(document.getElementById('max-books-per-user').value),
        overdue_fee: parseFloat(document.getElementById('overdue-fee').value)
    };

    try {
        const response = await fetch('/api/system/config', {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(configData)
        });

        const data = await response.json();
        if (data.success) {
            alert('系统配置保存成功');
        } else {
            alert(data.message || '保存配置失败，请重试');
        }
    } catch (error) {
        console.error('Error saving system config:', error);
        alert('保存配置失败，请重试');
    }
}

// 加载系统日志
async function loadSystemLogs() {
    try {
        const response = await fetch('/api/system/logs');
        const data = await response.json();

        if (data.success) {
            const tableBody = document.getElementById('system-logs-table').querySelector('tbody');
            tableBody.innerHTML = '';

            if (data.logs.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="5" class="text-center">暂无系统日志</td></tr>';
                return;
            }

            data.logs.forEach(log => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${log.id}</td>
                    <td>${log.operator || '系统'}</td>
                    <td>${log.operation_type}</td>
                    <td>${new Date(log.operation_time).toLocaleString()}</td>
                    <td>${log.details}</td>
                `;
                tableBody.appendChild(row);
            });
        }
    } catch (error) {
        console.error('Error loading system logs:', error);
        document.getElementById('system-logs-table').querySelector('tbody').innerHTML = '<tr><td colspan="5" class="text-center">加载失败，请重试</td></tr>';
    }
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 加载系统配置
    loadSystemConfig();
    // 加载系统日志
    loadSystemLogs();

    // 绑定配置保存事件
    document.getElementById('system-config-form').addEventListener('submit', saveSystemConfig);
});