// 加载借阅记录
async function loadBorrowRecords() {
    try {
        const response = await fetch('/api/borrows');
        const data = await response.json();

        if (data.success) {
            const tableBody = document.getElementById('borrow-table').querySelector('tbody');
            tableBody.innerHTML = '';

            if (data.borrows.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="9" class="text-center">暂无借阅记录</td></tr>';
                return;
            }

            data.borrows.forEach(record => {
                const row = document.createElement('tr');
                // 设置状态样式
                let statusClass = '';
                if (record.status === 'overdue') statusClass = 'style="color: red; font-weight: bold;"';
                else if (record.status === 'borrowed') statusClass = 'style="color: orange;"';
                else statusClass = 'style="color: green;"';

                row.innerHTML = `
                    <td>${record.id}</td>
                    <td>${record.user_id}</td>
                    <td>${record.book_id}</td>
                    <td>${record.book_title || '-'}</td>
                    <td>${new Date(record.borrow_date).toLocaleString()}</td>
                    <td>${new Date(record.due_date).toLocaleString()}</td>
                    <td>${record.return_date ? new Date(record.return_date).toLocaleString() : '-'}</td>
                    <td ${statusClass}>
                        ${record.status === 'borrowed' ? '已借出' : record.status === 'returned' ? '已归还' : '逾期未还'}
                    </td>
                    <td>
                        ${record.status === 'borrowed' ? `<button class="action-btn edit-btn" onclick="returnBook(${record.id})">归还</button>` : '-'}
                    </td>
                `;
                tableBody.appendChild(row);
            });
        }
    } catch (error) {
        console.error('Error loading borrow records:', error);
        document.getElementById('borrow-table').querySelector('tbody').innerHTML = '<tr><td colspan="9" class="text-center">加载失败，请重试</td></tr>';
    }
}

// 处理图书借阅
async function handleBorrowSubmit(event) {
    event.preventDefault();

    const borrowData = {
        user_id: parseInt(document.getElementById('user-id-borrow').value),
        book_id: parseInt(document.getElementById('book-id-borrow').value),
        due_date: document.getElementById('due-date').value
    };

    try {
        const response = await fetch('/api/borrows', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(borrowData)
        });

        const data = await response.json();
        if (data.success) {
            // 重置表单
            document.getElementById('borrow-form').reset();
            // 重新加载借阅记录
            loadBorrowRecords();
            alert('图书借阅成功');
        } else {
            alert(data.message || '借阅失败，请重试');
        }
    } catch (error) {
        console.error('Error borrowing book:', error);
        alert('借阅失败，请重试');
    }
}

// 处理图书归还
async function returnBook(borrowId) {
    if (!confirm('确定要归还此图书吗？')) {
        return;
    }

    try {
        const response = await fetch(`/api/borrows/${borrowId}/return`, {
            method: 'PUT'
        });

        const data = await response.json();
        if (data.success) {
            loadBorrowRecords();
            alert('图书归还成功');
        } else {
            alert(data.message || '归还失败，请重试');
        }
    } catch (error) {
        console.error('Error returning book:', error);
        alert('归还失败，请重试');
    }
}

// 处理归还表单提交（通过借阅记录ID）
async function handleReturnSubmit(event) {
    event.preventDefault();
    const borrowId = parseInt(document.getElementById('borrow-id-return').value);
    returnBook(borrowId);
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 加载借阅记录
    loadBorrowRecords();

    // 绑定借阅表单提交事件
    document.getElementById('borrow-form').addEventListener('submit', handleBorrowSubmit);

    // 绑定归还表单提交事件
    document.getElementById('return-form').addEventListener('submit', handleReturnSubmit);
});