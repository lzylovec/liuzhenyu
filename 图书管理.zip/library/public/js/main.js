// 获取统计数据并更新仪表盘
async function loadDashboardStats() {
    try {
        const response = await fetch('/api/stats');
        const data = await response.json();

        if (data.success) {
            document.getElementById('total-books').textContent = data.stats.totalBooks;
            document.getElementById('available-books').textContent = data.stats.availableBooks;
            document.getElementById('total-users').textContent = data.stats.totalUsers;
            document.getElementById('active-borrows').textContent = data.stats.activeBorrows;
        }
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
    }
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 加载仪表盘数据
    loadDashboardStats();

    // 设置导航栏激活状态
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('nav a');

    navLinks.forEach(link => {
        const linkPath = link.getAttribute('href');
        if (linkPath === currentPath) {
            link.classList.add('active');
        }
    });
});