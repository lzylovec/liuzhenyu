// 全局变量，用于存储当前编辑的用户ID
let currentEditUserId = null;

// 加载用户列表
async function loadUsers() {
    try {
        const response = await fetch('/api/users');
        const data = await response.json();

        if (data.success) {
            const tableBody = document.getElementById('users-table').querySelector('tbody');
            tableBody.innerHTML = '';

            if (data.users.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="9" class="text-center">暂无用户数据</td></tr>';
                return;
            }

            data.users.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${user.id}</td>
                    <td>${user.username}</td>
                    <td>${user.name}</td>
                    <td>${user.email}</td>
                    <td>${user.role === 'admin' ? '系统管理员' : user.role === 'librarian' ? '图书管理员' : '普通用户'}</td>
                    <td>${user.phone || '-'}</td>
                    <td>${user.address || '-'}</td>
                    <td>${new Date(user.created_at).toLocaleString()}</td>
                    <td>
                        <button class="action-btn edit-btn" onclick="editUser(${user.id})">编辑</button>
                        <button class="action-btn delete-btn" onclick="deleteUser(${user.id})">删除</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        }
    } catch (error) {
        console.error('Error loading users:', error);
        document.getElementById('users-table').querySelector('tbody').innerHTML = '<tr><td colspan="9" class="text-center">加载失败，请重试</td></tr>';
    }
}

// 添加或更新用户
async function saveUser(event) {
    event.preventDefault();

    const userData = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        role: document.getElementById('role').value,
        phone: document.getElementById('phone').value,
        address: document.getElementById('address').value
    };

    // 如果是编辑模式且未修改密码，则不发送密码字段
    if (currentEditUserId && !userData.password) {
        delete userData.password;
    }

    try {
        let response;
        if (currentEditUserId) {
            // 更新现有用户
            response = await fetch(`/api/users/${currentEditUserId}`, {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(userData)
            });
        } else {
            // 添加新用户
            response = await fetch('/api/users', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(userData)
            });
        }

        const data = await response.json();
        if (data.success) {
            // 重置表单
            document.getElementById('user-form').reset();
            currentEditUserId = null;
            document.getElementById('cancel-btn').style.display = 'none';
            // 重新加载用户列表
            loadUsers();
            alert(currentEditUserId ? '用户更新成功' : '用户添加成功');
        } else {
            alert(data.message || '操作失败，请重试');
        }
    } catch (error) {
        console.error('Error saving user:', error);
        alert('保存失败，请重试');
    }
}

// 编辑用户
async function editUser(id) {
    try {
        const response = await fetch(`/api/users/${id}`);
        const data = await response.json();

        if (data.success) {
            const user = data.user;
            currentEditUserId = id;

            // 填充表单
            document.getElementById('username').value = user.username;
            document.getElementById('password').value = ''; // 不显示现有密码
            document.getElementById('name').value = user.name;
            document.getElementById('email').value = user.email;
            document.getElementById('role').value = user.role;
            document.getElementById('phone').value = user.phone || '';
            document.getElementById('address').value = user.address || '';

            // 显示取消按钮
            document.getElementById('cancel-btn').style.display = 'inline-block';

            // 滚动到表单
            document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
        } else {
            alert(data.message || '获取用户信息失败');
        }
    } catch (error) {
        console.error('Error loading user for edit:', error);
        alert('加载用户信息失败，请重试');
    }
}

// 删除用户
async function deleteUser(id) {
    if (!confirm('确定要删除这个用户吗？此操作不可撤销。')) {
        return;
    }

    try {
        const response = await fetch(`/api/users/${id}`, {
            method: 'DELETE'
        });

        const data = await response.json();
        if (data.success) {
            loadUsers();
            alert('用户删除成功');
        } else {
            alert(data.message || '删除失败，请重试');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        alert('删除失败，请重试');
    }
}

// 取消编辑
function cancelEdit() {
    document.getElementById('user-form').reset();
    currentEditUserId = null;
    document.getElementById('cancel-btn').style.display = 'none';
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 加载用户列表
    loadUsers();

    // 绑定表单提交事件
    document.getElementById('user-form').addEventListener('submit', saveUser);

    // 绑定取消按钮事件
    document.getElementById('cancel-btn').addEventListener('click', cancelEdit);
});