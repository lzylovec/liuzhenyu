const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// MySQL Connection
const db = mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'library_db'
});

// Connect to MySQL
 db.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err.stack);
    return;
  }
  console.log('Connected to MySQL database as ID', db.threadId);
});

// Basic route
app.get('/', (req, res) => {
  res.send('Library Management System API is running');
});

// API Routes
// 获取仪表盘统计数据
app.get('/api/stats', (req, res) => {
  const statsQueries = [
    'SELECT COUNT(*) AS totalBooks FROM books',
    'SELECT SUM(available) AS availableBooks FROM books',
    'SELECT COUNT(*) AS totalUsers FROM users',
    'SELECT COUNT(*) AS activeBorrows FROM borrow_records WHERE status = "borrowed"'
  ];

  let stats = {};
  let completedQueries = 0;

  statsQueries.forEach((query, index) => {
    db.query(query, (err, results) => {
      if (err) throw err;

      switch(index) {
        case 0:
          stats.totalBooks = results[0].totalBooks;
          break;
        case 1:
          stats.availableBooks = results[0].availableBooks;
          break;
        case 2:
          stats.totalUsers = results[0].totalUsers;
          break;
        case 3:
          stats.activeBorrows = results[0].activeBorrows;
          break;
      }

      completedQueries++;
      if (completedQueries === statsQueries.length) {
        res.json({ success: true, stats });
      }
    });
  });
});

// 图书相关API
app.get('/api/books', (req, res) => {
  db.query('SELECT * FROM books', (err, results) => {
    if (err) {
      res.json({ success: false, message: '获取图书列表失败' });
      return;
    }
    res.json({ success: true, books: results });
  });
});

app.get('/api/books/:id', (req, res) => {
  const id = req.params.id;
  db.query('SELECT * FROM books WHERE id = ?', [id], (err, results) => {
    if (err) {
      res.json({ success: false, message: '获取图书信息失败' });
      return;
    }
    if (results.length === 0) {
      res.json({ success: false, message: '图书不存在' });
      return;
    }
    res.json({ success: true, book: results[0] });
  });
});

app.post('/api/books', (req, res) => {
  const book = req.body;
  const sql = 'INSERT INTO books SET ?';
  db.query(sql, book, (err, result) => {
    if (err) {
      res.json({ success: false, message: '添加图书失败' });
      return;
    }
    res.json({ success: true, message: '图书添加成功', bookId: result.insertId });
  });
});

app.put('/api/books/:id', (req, res) => {
  const id = req.params.id;
  const book = req.body;
  const sql = 'UPDATE books SET ? WHERE id = ?';
  db.query(sql, [book, id], (err, result) => {
    if (err) {
      res.json({ success: false, message: '更新图书失败' });
      return;
    }
    res.json({ success: true, message: '图书更新成功' });
  });
});

app.delete('/api/books/:id', (req, res) => {
  const id = req.params.id;
  const sql = 'DELETE FROM books WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      res.json({ success: false, message: '删除图书失败' });
      return;
    }
    res.json({ success: true, message: '图书删除成功' });
  });
});

// 用户相关API
app.get('/api/users', (req, res) => {
  db.query('SELECT * FROM users', (err, results) => {
    if (err) {
      res.json({ success: false, message: '获取用户列表失败' });
      return;
    }
    res.json({ success: true, users: results });
  });
});

app.get('/api/users/:id', (req, res) => {
  const id = req.params.id;
  db.query('SELECT * FROM users WHERE id = ?', [id], (err, results) => {
    if (err) {
      res.json({ success: false, message: '获取用户信息失败' });
      return;
    }
    if (results.length === 0) {
      res.json({ success: false, message: '用户不存在' });
      return;
    }
    res.json({ success: true, user: results[0] });
  });
});

app.post('/api/users', (req, res) => {
  const user = req.body;
  const sql = 'INSERT INTO users SET ?';
  db.query(sql, user, (err, result) => {
    if (err) {
      res.json({ success: false, message: '添加用户失败' });
      return;
    }
    res.json({ success: true, message: '用户添加成功', userId: result.insertId });
  });
});

app.put('/api/users/:id', (req, res) => {
  const id = req.params.id;
  const user = req.body;
  const sql = 'UPDATE users SET ? WHERE id = ?';
  db.query(sql, [user, id], (err, result) => {
    if (err) {
      res.json({ success: false, message: '更新用户失败' });
      return;
    }
    res.json({ success: true, message: '用户更新成功' });
  });
});

app.delete('/api/users/:id', (req, res) => {
  const id = req.params.id;
  const sql = 'DELETE FROM users WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      res.json({ success: false, message: '删除用户失败' });
      return;
    }
    res.json({ success: true, message: '用户删除成功' });
  });
});

// 借阅相关API
app.get('/api/borrows', (req, res) => {
  const sql = `
    SELECT br.*, b.title AS book_title 
    FROM borrow_records br
    LEFT JOIN books b ON br.book_id = b.id
    ORDER BY br.borrow_date DESC
  `;
  db.query(sql, (err, results) => {
    if (err) {
      res.json({ success: false, message: '获取借阅记录失败' });
      return;
    }
    res.json({ success: true, borrows: results });
  });
});

app.post('/api/borrows', (req, res) => {
  const borrow = req.body;
  const sql = 'INSERT INTO borrow_records SET ?';
  db.query(sql, borrow, (err, result) => {
    if (err) {
      res.json({ success: false, message: '创建借阅记录失败' });
      return;
    }
    // 更新图书可用数量
    db.query('CALL UpdateBookAvailability(?)', [borrow.book_id], (err) => {
      if (err) console.error('Error updating book availability:', err);
    });
    res.json({ success: true, message: '借阅成功', borrowId: result.insertId });
  });
});

app.put('/api/borrows/:id/return', (req, res) => {
  const id = req.params.id;
  const sql = `
    UPDATE borrow_records 
    SET return_date = NOW(), status = "returned" 
    WHERE id = ?
  `;
  db.query(sql, [id], (err, result) => {
    if (err) {
      res.json({ success: false, message: '归还图书失败' });
      return;
    }
    // 获取图书ID并更新可用数量
    db.query('SELECT book_id FROM borrow_records WHERE id = ?', [id], (err, results) => {
      if (err) {
        console.error('Error getting book_id for return:', err);
        return;
      }
      if (results.length > 0) {
        db.query('CALL UpdateBookAvailability(?)', [results[0].book_id], (err) => {
          if (err) console.error('Error updating book availability:', err);
        });
      }
    });
    res.json({ success: true, message: '归还成功' });
  });
});

// 挂失相关API
app.get('/api/loss-reports', (req, res) => {
  db.query('SELECT * FROM loss_reports ORDER BY report_date DESC', (err, results) => {
    if (err) {
      res.json({ success: false, message: '获取挂失报告失败' });
      return;
    }
    res.json({ success: true, reports: results });
  });
});

app.post('/api/loss-reports', (req, res) => {
  const report = req.body;
  const sql = 'INSERT INTO loss_reports SET ?';
  db.query(sql, report, (err, result) => {
    if (err) {
      res.json({ success: false, message: '提交挂失报告失败' });
      return;
    }
    res.json({ success: true, message: '挂失报告提交成功', reportId: result.insertId });
  });
});

app.put('/api/loss-reports/:id/approve', (req, res) => {
  const id = req.params.id;
  const sql = 'UPDATE loss_reports SET status = "approved" WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      res.json({ success: false, message: '批准挂失报告失败' });
      return;
    }
    res.json({ success: true, message: '挂失报告已批准' });
  });
});

app.put('/api/loss-reports/:id/reject', (req, res) => {
  const id = req.params.id;
  const sql = 'UPDATE loss_reports SET status = "rejected" WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      res.json({ success: false, message: '拒绝挂失报告失败' });
      return;
    }
    res.json({ success: true, message: '挂失报告已拒绝' });
  });
});

// 系统相关API
app.get('/api/system/config', (req, res) => {
  // 在实际应用中，系统配置应该从数据库中获取
  // 这里使用默认值作为示例
  const config = {
    max_borrow_days: 30,
    max_books_per_user: 5,
    overdue_fee: 0.5
  };
  res.json({ success: true, config });
});

app.put('/api/system/config', (req, res) => {
  const config = req.body;
  // 在实际应用中，这里应该将配置保存到数据库
  res.json({ success: true, message: '系统配置保存成功' });
});

app.get('/api/system/logs', (req, res) => {
  // 在实际应用中，系统日志应该从数据库中获取
  // 这里返回空数组作为示例
  res.json({ success: true, logs: [] });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});