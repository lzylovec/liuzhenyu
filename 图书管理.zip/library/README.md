# 图书管理系统

一个功能完善的图书管理系统，包含图书管理、用户管理、系统管理、借还书和挂失功能。

## 功能模块

- **图书管理**：添加、编辑、删除图书信息，查看图书列表
- **用户管理**：添加、编辑、删除用户信息，查看用户列表
- **借还书**：处理图书借阅和归还操作，查看借阅记录
- **挂失功能**：提交图书挂失报告，处理挂失申请
- **系统管理**：配置系统参数，查看系统日志

## 技术栈

- **前端**：HTML, CSS, JavaScript
- **后端**：Node.js, Express
- **数据库**：MySQL

## 安装指南

### 前提条件
- Node.js (v14+) 和 npm
- MySQL (v5.7+)

### 步骤

1. **克隆仓库**
   ```
   git clone <repository-url>
   cd library-management-system
   ```

2. **安装依赖**
   ```
   npm install
   ```

3. **配置数据库**
   - 创建MySQL数据库：`library_db`
   - 导入数据库 schema：
     ```
     mysql -u root -p library_db < db/schema.sql
     ```
   - （可选）导入测试数据：
     ```
     mysql -u root -p library_db < db/test_data.sql
     ```

4. **环境配置**
   创建`.env`文件，添加以下配置：
   ```
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=your_mysql_password
   DB_NAME=library_db
   PORT=3000
   ```

5. **启动服务器**
   ```
   npm start
   ```
   或开发模式（自动重启）：
   ```
   npm run dev
   ```

6. **访问系统**
   打开浏览器访问：`http://localhost:3000`

## 默认管理员账户
- 用户名：admin
- 密码：admin123

## 项目结构

```
/library-management-system
├── db/                 # 数据库相关文件
│   ├── schema.sql      # 数据库表结构
│   └── test_data.sql   # 测试数据
├── public/             # 前端静态文件
│   ├── css/            # 样式表
│   ├── js/             # JavaScript文件
│   └── *.html          # HTML页面
├── .env                # 环境变量配置
├── .gitignore          # Git忽略文件
├── package.json        # 项目依赖
├── README.md           # 项目说明
└── server.js           # 服务器入口文件
```

## 功能使用说明

### 图书管理
- 点击导航栏的"图书管理"进入模块
- 填写表单添加新图书
- 点击图书列表中的"编辑"或"删除"按钮进行相应操作

### 用户管理
- 点击导航栏的"用户管理"进入模块
- 填写表单添加新用户
- 选择用户角色（普通用户/图书管理员/系统管理员）
- 点击用户列表中的"编辑"或"删除"按钮进行相应操作

### 借还书
- 借阅图书：填写用户ID、图书ID和归还日期，点击"确认借阅"
- 归还图书：填写借阅记录ID，点击"确认归还"
- 查看所有借阅记录和状态

### 挂失功能
- 提交挂失：填写用户ID、图书ID和挂失说明，点击"提交挂失报告"
- 处理挂失：管理员可以批准或拒绝挂失申请

### 系统管理
- 配置系统参数：设置最大借阅天数、最大借阅数量和逾期罚款金额
- 查看系统日志：查看系统操作记录

## 注意事项
- 确保MySQL服务已启动
- 首次使用请修改管理员密码
- 生产环境中请使用更安全的密码存储方式
- 定期备份数据库防止数据丢失

## 许可证

[MIT](LICENSE)