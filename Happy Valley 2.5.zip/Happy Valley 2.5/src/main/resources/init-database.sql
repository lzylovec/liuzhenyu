-- 欢乐谷管理系统数据库初始化脚本

-- 创建数据库
CREATE DATABASE IF NOT EXISTS happy_valley DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE happy_valley;

-- 用户表
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(255) NOT NULL COMMENT '密码',
    email VARCHAR(100) NOT NULL COMMENT '邮箱',
    phone VARCHAR(20) COMMENT '手机号',
    real_name VARCHAR(100) COMMENT '真实姓名',
    role ENUM('ADMIN', 'EMPLOYEE', 'VISITOR') NOT NULL COMMENT '用户角色',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    is_active BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否激活'
) COMMENT '用户表';

-- 票务表
CREATE TABLE tickets (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    ticket_number VARCHAR(50) NOT NULL UNIQUE COMMENT '票号',
    ticket_type ENUM('ADULT', 'CHILD', 'STUDENT', 'SENIOR', 'VIP') NOT NULL COMMENT '票种类型',
    price DECIMAL(10,2) NOT NULL COMMENT '价格',
    valid_date DATE NOT NULL COMMENT '有效日期',
    visitor_id BIGINT COMMENT '游客ID',
    visitor_name VARCHAR(100) NOT NULL COMMENT '游客姓名',
    visitor_phone VARCHAR(20) COMMENT '游客手机号',
    status ENUM('PENDING', 'PAID', 'USED', 'EXPIRED', 'CANCELLED', 'REFUNDED') NOT NULL DEFAULT 'PENDING' COMMENT '状态',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    remarks TEXT COMMENT '备注',
    FOREIGN KEY (visitor_id) REFERENCES users(id) ON DELETE SET NULL
) COMMENT '票务表';

-- 园区活动表
CREATE TABLE activities (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL COMMENT '活动名称',
    description TEXT COMMENT '活动描述',
    type ENUM('ROLLER_COASTER', 'FERRIS_WHEEL', 'BUMPER_CAR', 'CAROUSEL', 'WATER_RIDE', 'HAUNTED_HOUSE', 'PERFORMANCE', 'EXHIBITION', 'GAME') NOT NULL COMMENT '活动类型',
    location VARCHAR(100) COMMENT '活动地点',
    start_time DATETIME COMMENT '开始时间',
    end_time DATETIME COMMENT '结束时间',
    capacity INT NOT NULL DEFAULT 0 COMMENT '容量',
    current_participants INT NOT NULL DEFAULT 0 COMMENT '当前参与人数',
    status ENUM('ACTIVE', 'MAINTENANCE', 'CLOSED', 'FULL', 'CANCELLED') NOT NULL DEFAULT 'ACTIVE' COMMENT '状态',
    requirements TEXT COMMENT '参与要求',
    image_url VARCHAR(255) COMMENT '图片URL',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) COMMENT '园区活动表';

-- 动物信息表
CREATE TABLE animals (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL COMMENT '动物名称',
    species VARCHAR(100) NOT NULL COMMENT '物种',
    category ENUM('MAMMAL', 'BIRD', 'REPTILE', 'AMPHIBIAN', 'FISH', 'INSECT', 'MARINE') NOT NULL COMMENT '动物类别',
    habitat VARCHAR(100) COMMENT '栖息地',
    description TEXT COMMENT '描述',
    diet TEXT COMMENT '饮食习惯',
    behavior TEXT COMMENT '行为特征',
    image_url VARCHAR(255) COMMENT '图片URL',
    status ENUM('HEALTHY', 'SICK', 'RECOVERING', 'QUARANTINE', 'DECEASED', 'TRANSFERRED') NOT NULL DEFAULT 'HEALTHY' COMMENT '健康状态',
    age INT COMMENT '年龄',
    gender ENUM('MALE', 'FEMALE', 'UNKNOWN') COMMENT '性别',
    caretaker VARCHAR(100) COMMENT '饲养员',
    feeding_time TIME COMMENT '喂食时间',
    health_status TEXT COMMENT '健康状况详情',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) COMMENT '动物信息表';

-- 反馈建议表
CREATE TABLE feedback (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    visitor_id BIGINT COMMENT '游客ID',
    visitor_name VARCHAR(100) NOT NULL COMMENT '游客姓名',
    type ENUM('SUGGESTION', 'COMPLAINT', 'PRAISE', 'INQUIRY', 'OTHER') NOT NULL COMMENT '反馈类型',
    title VARCHAR(200) NOT NULL COMMENT '标题',
    content TEXT NOT NULL COMMENT '内容',
    rating INT COMMENT '评分(1-5)',
    status ENUM('PENDING', 'PROCESSING', 'REPLIED', 'RESOLVED', 'CLOSED') NOT NULL DEFAULT 'PENDING' COMMENT '处理状态',
    reply TEXT COMMENT '回复内容',
    reply_by_user_id BIGINT COMMENT '回复人ID',
    reply_by_user_name VARCHAR(100) COMMENT '回复人姓名',
    reply_time DATETIME COMMENT '回复时间',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    contact VARCHAR(100) COMMENT '联系方式',
    category VARCHAR(50) COMMENT '反馈分类',
    FOREIGN KEY (visitor_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (reply_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) COMMENT '反馈建议表';

-- 创建索引
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_tickets_visitor_id ON tickets(visitor_id);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_valid_date ON tickets(valid_date);
CREATE INDEX idx_activities_type ON activities(type);
CREATE INDEX idx_activities_status ON activities(status);
CREATE INDEX idx_animals_category ON animals(category);
CREATE INDEX idx_animals_status ON animals(status);
CREATE INDEX idx_feedback_visitor_id ON feedback(visitor_id);
CREATE INDEX idx_feedback_status ON feedback(status);
CREATE INDEX idx_feedback_type ON feedback(type);

-- 插入初始数据

-- 插入管理员用户
INSERT INTO users (username, password, email, real_name, role) VALUES 
('admin', 'admin123', 'admin@happyvalley.com', '系统管理员', 'ADMIN');

-- 插入员工用户
INSERT INTO users (username, password, email, phone, real_name, role) VALUES 
('employee1', 'emp123', 'emp1@happyvalley.com', '13800001001', '张三', 'EMPLOYEE'),
('employee2', 'emp123', 'emp2@happyvalley.com', '13800001002', '李四', 'EMPLOYEE');

-- 插入游客用户
INSERT INTO users (username, password, email, phone, real_name, role) VALUES 
('user', 'user123', 'visitor1@example.com', '13900001001', '王五', 'VISITOR'),
('visitor2', 'vis123', 'visitor2@example.com', '13900001002', '赵六', 'VISITOR');

-- 插入园区活动
INSERT INTO activities (name, description, type, location, start_time, end_time, capacity, requirements) VALUES 
('疯狂过山车', '刺激的高速过山车，体验极速与失重的快感', 'ROLLER_COASTER', 'A区', '2024-01-01 09:00:00', '2024-12-31 18:00:00', 20, '身高不低于1.4米，心脏病患者禁止乘坐'),
('浪漫摩天轮', '高空观景摩天轮，俯瞰整个欢乐谷美景', 'FERRIS_WHEEL', 'B区', '2024-01-01 09:00:00', '2024-12-31 21:00:00', 48, '适合全年龄段游客'),
('激情碰碰车', '有趣的碰碰车游戏，适合亲子互动', 'BUMPER_CAR', 'C区', '2024-01-01 09:00:00', '2024-12-31 18:00:00', 16, '儿童需成人陪同'),
('梦幻旋转木马', '经典的旋转木马，适合儿童和家庭', 'CAROUSEL', 'D区', '2024-01-01 09:00:00', '2024-12-31 18:00:00', 24, '适合全年龄段游客'),
('激流勇进', '刺激的水上漂流项目', 'WATER_RIDE', 'E区', '2024-04-01 10:00:00', '2024-10-31 17:00:00', 12, '身高不低于1.2米，请准备防水用品');

-- 插入动物信息
INSERT INTO animals (name, species, category, habitat, description, diet, age, gender, caretaker) VALUES 
('大熊猫-圆圆', '大熊猫', 'MAMMAL', '竹林园', '可爱的大熊猫，喜欢吃竹子和玩耍', '主要以竹子为食，偶尔吃竹笋和野菜', 5, 'FEMALE', '熊猫饲养员小王'),
('东北虎-威威', '东北虎', 'MAMMAL', '虎山', '威武的东北虎，森林之王', '肉食性动物，主要捕食大型哺乳动物', 8, 'MALE', '猛兽饲养员老李'),
('金丝猴-跳跳', '金丝猴', 'MAMMAL', '猴山', '活泼好动的金丝猴，擅长攀爬', '杂食性，主要吃果实、嫩叶和昆虫', 3, 'MALE', '灵长类饲养员小张'),
('丹顶鹤-优雅', '丹顶鹤', 'BIRD', '湿地园', '优雅的丹顶鹤，象征长寿和吉祥', '杂食性，主要吃鱼类、青蛙和植物根茎', 6, 'FEMALE', '鸟类饲养员小刘'),
('海豚-欢欢', '宽吻海豚', 'MARINE', '海洋馆', '聪明可爱的海豚，会表演各种技巧', '主要以鱼类为食', 4, 'MALE', '海洋动物训练师小陈');

-- 插入反馈建议
INSERT INTO feedback (visitor_id, visitor_name, type, title, content, rating, contact) VALUES 
(4, '王五', 'PRAISE', '服务很棒', '今天带孩子来玩，服务人员态度很好，设施也很完善，孩子玩得很开心！', 5, '13900001001'),
(5, '赵六', 'SUGGESTION', '希望增加更多儿童项目', '建议园区增加一些适合3-6岁儿童的游乐设施，现在的项目对小孩子来说有些刺激。', 4, '13900001002'),
(4, '王五', 'COMPLAINT', '排队时间太长', '过山车的排队时间超过2小时，希望能够优化排队系统或增加设备。', 2, '13900001001');

COMMIT; 