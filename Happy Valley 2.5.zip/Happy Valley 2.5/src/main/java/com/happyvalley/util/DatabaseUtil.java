package com.happyvalley.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;

/**
 * 数据库连接工具类
 */
public class DatabaseUtil {
    private static String url;
    private static String username;
    private static String password;
    private static String driverClass;

    static {
        loadDatabaseConfig();
    }

    private static void loadDatabaseConfig() {
        Properties properties = new Properties();
        try (InputStream inputStream = DatabaseUtil.class.getClassLoader().getResourceAsStream("database.properties")) {
            if (inputStream != null) {
                properties.load(inputStream);
                url = properties.getProperty("database.url");
                username = properties.getProperty("database.username");
                password = properties.getProperty("database.password");
                driverClass = properties.getProperty("database.driver");
            } else {
                // 默认配置
                url = "jdbc:mysql://47.121.24.210:3306/happy_valley?useSSL=false&serverTimezone=UTC&characterEncoding=utf8";
                username = "happy_valley";
                password = "P4AJDyhL3A8k5w7R";
                driverClass = "com.mysql.cj.jdbc.Driver";
            }

            // 加载数据库驱动
            Class.forName(driverClass);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("数据库配置加载失败", e);
        }
    }

    /**
     * 获取数据库连接
     * @return Connection对象
     * @throws SQLException 数据库连接异常
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }

    /**
     * 关闭数据库连接
     * @param connection 数据库连接
     */
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 测试数据库连接
     * @return 连接是否成功
     */
    public static boolean testConnection() {
        try (Connection connection = getConnection()) {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 获取数据库连接信息（用于调试）
     */
    public static void printConnectionInfo() {
        System.out.println("数据库URL: " + url);
        System.out.println("数据库用户名: " + username);
        System.out.println("数据库驱动: " + driverClass);
        System.out.println("连接测试: " + (testConnection() ? "成功" : "失败"));
    }
} 