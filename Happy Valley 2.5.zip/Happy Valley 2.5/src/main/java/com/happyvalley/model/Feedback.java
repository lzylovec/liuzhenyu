package com.happyvalley.model;

import java.util.Date;

/**
 * 游客建议与留言实体类
 */
public class Feedback {
    private Long id;
    private Long visitorId;
    private String visitorName;
    private FeedbackType type;
    private String title;
    private String content;
    private Integer rating;
    private FeedbackStatus status;
    private String reply;
    private Long replyByUserId;
    private String replyByUserName;
    private Date replyTime;
    private Date createTime;
    private Date updateTime;
    private String contact;
    private String category;

    public enum FeedbackType {
        SUGGESTION("建议"),
        COMPLAINT("投诉"),
        PRAISE("表扬"),
        INQUIRY("咨询"),
        OTHER("其他");

        private String description;

        FeedbackType(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    public enum FeedbackStatus {
        PENDING("待处理"),
        PROCESSING("处理中"),
        REPLIED("已回复"),
        RESOLVED("已解决"),
        CLOSED("已关闭");

        private String description;

        FeedbackStatus(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    // 构造函数
    public Feedback() {}

    public Feedback(Long visitorId, String visitorName, FeedbackType type, String title, String content) {
        this.visitorId = visitorId;
        this.visitorName = visitorName;
        this.type = type;
        this.title = title;
        this.content = content;
        this.status = FeedbackStatus.PENDING;
        this.createTime = new Date();
        this.updateTime = new Date();
    }

    // Getter 和 Setter 方法
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVisitorId() {
        return visitorId;
    }

    public void setVisitorId(Long visitorId) {
        this.visitorId = visitorId;
    }

    public String getVisitorName() {
        return visitorName;
    }

    public void setVisitorName(String visitorName) {
        this.visitorName = visitorName;
    }

    public FeedbackType getType() {
        return type;
    }

    public void setType(FeedbackType type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public FeedbackStatus getStatus() {
        return status;
    }

    public void setStatus(FeedbackStatus status) {
        this.status = status;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public Long getReplyByUserId() {
        return replyByUserId;
    }

    public void setReplyByUserId(Long replyByUserId) {
        this.replyByUserId = replyByUserId;
    }

    public String getReplyByUserName() {
        return replyByUserName;
    }

    public void setReplyByUserName(String replyByUserName) {
        this.replyByUserName = replyByUserName;
    }

    public Date getReplyTime() {
        return replyTime;
    }

    public void setReplyTime(Date replyTime) {
        this.replyTime = replyTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    // 业务方法：添加回复
    public void addReply(String replyContent, Long replyUserId, String replyUserName) {
        this.reply = replyContent;
        this.replyByUserId = replyUserId;
        this.replyByUserName = replyUserName;
        this.replyTime = new Date();
        this.status = FeedbackStatus.REPLIED;
        this.updateTime = new Date();
    }

    // 检查是否已回复
    public boolean isReplied() {
        return reply != null && !reply.trim().isEmpty();
    }
    
    // 为了兼容前端，提供username字段的getter方法
    public String getUsername() {
        return this.visitorName;
    }

    @Override
    public String toString() {
        return "Feedback{" +
                "id=" + id +
                ", visitorName='" + visitorName + '\'' +
                ", type=" + type +
                ", title='" + title + '\'' +
                ", status=" + status +
                ", rating=" + rating +
                ", createTime=" + createTime +
                ", isReplied=" + isReplied() +
                '}';
    }
}