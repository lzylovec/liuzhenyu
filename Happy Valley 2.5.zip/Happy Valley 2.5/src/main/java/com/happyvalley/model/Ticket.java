package com.happyvalley.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 票务实体类
 */
public class Ticket {
    private Long id;
    private String ticketNumber;
    private TicketType ticketType;
    private BigDecimal price;
    private Date validDate;
    private Long visitorId;
    private String visitorName;
    private String visitorPhone;
    private TicketStatus status;
    private Date createTime;
    private Date updateTime;
    private String remarks;

    public enum TicketType {
        ADULT("成人票", new BigDecimal("120.00")),
        CHILD("儿童票", new BigDecimal("80.00")),
        STUDENT("学生票", new BigDecimal("90.00")),
        SENIOR("老人票", new BigDecimal("60.00")),
        VIP("VIP票", new BigDecimal("200.00"));

        private String description;
        private BigDecimal defaultPrice;

        TicketType(String description, BigDecimal defaultPrice) {
            this.description = description;
            this.defaultPrice = defaultPrice;
        }

        public String getDescription() {
            return description;
        }

        public BigDecimal getDefaultPrice() {
            return defaultPrice;
        }
    }

    public enum TicketStatus {
        PENDING("待支付"),
        PAID("已支付"),
        USED("已使用"),
        EXPIRED("已过期"),
        CANCELLED("已取消"),
        REFUNDED("已退款");

        private String description;

        TicketStatus(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    // 构造函数
    public Ticket() {}

    public Ticket(TicketType ticketType, Date validDate, Long visitorId, String visitorName, String visitorPhone) {
        this.ticketNumber = generateTicketNumber();
        this.ticketType = ticketType;
        this.price = ticketType.getDefaultPrice();
        this.validDate = validDate;
        this.visitorId = visitorId;
        this.visitorName = visitorName;
        this.visitorPhone = visitorPhone;
        this.status = TicketStatus.PENDING;
        this.createTime = new Date();
        this.updateTime = new Date();
    }

    private String generateTicketNumber() {
        return "HV" + System.currentTimeMillis() + (int)(Math.random() * 1000);
    }

    // Getter 和 Setter 方法
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTicketNumber() {
        return ticketNumber;
    }

    public void setTicketNumber(String ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public TicketType getTicketType() {
        return ticketType;
    }

    public void setTicketType(TicketType ticketType) {
        this.ticketType = ticketType;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Date getValidDate() {
        return validDate;
    }

    public void setValidDate(Date validDate) {
        this.validDate = validDate;
    }

    public Long getVisitorId() {
        return visitorId;
    }

    public void setVisitorId(Long visitorId) {
        this.visitorId = visitorId;
    }

    public String getVisitorName() {
        return visitorName;
    }

    public void setVisitorName(String visitorName) {
        this.visitorName = visitorName;
    }

    public String getVisitorPhone() {
        return visitorPhone;
    }

    public void setVisitorPhone(String visitorPhone) {
        this.visitorPhone = visitorPhone;
    }

    public TicketStatus getStatus() {
        return status;
    }

    public void setStatus(TicketStatus status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "id=" + id +
                ", ticketNumber='" + ticketNumber + '\'' +
                ", ticketType=" + ticketType +
                ", price=" + price +
                ", validDate=" + validDate +
                ", visitorName='" + visitorName + '\'' +
                ", status=" + status +
                ", createTime=" + createTime +
                '}';
    }
} 