package com.happyvalley.model;

import java.util.Date;

/**
 * 园区游乐活动实体类
 */
public class Activity {
    private Long id;
    private String name;
    private String description;
    private ActivityType type;
    private String location;
    private Date startTime;
    private Date endTime;
    private Integer capacity;
    private Integer currentParticipants;
    private ActivityStatus status;
    private String requirements;
    private String imageUrl;
    private Date createTime;
    private Date updateTime;

    public enum ActivityType {
        ROLLER_COASTER("过山车"),
        FERRIS_WHEEL("摩天轮"),
        BUMPER_CAR("碰碰车"),
        CAROUSEL("旋转木马"),
        WATER_RIDE("水上项目"),
        HAUNTED_HOUSE("鬼屋"),
        PERFORMANCE("表演"),
        EXHIBITION("展览"),
        GAME("游戏");

        private String description;

        ActivityType(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    public enum ActivityStatus {
        ACTIVE("开放中"),
        MAINTENANCE("维护中"),
        CLOSED("暂停开放"),
        FULL("已满员"),
        CANCELLED("已取消");

        private String description;

        ActivityStatus(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    // 构造函数
    public Activity() {}

    public Activity(String name, String description, ActivityType type, String location, 
                   Date startTime, Date endTime, Integer capacity) {
        this.name = name;
        this.description = description;
        this.type = type;
        this.location = location;
        this.startTime = startTime;
        this.endTime = endTime;
        this.capacity = capacity;
        this.currentParticipants = 0;
        this.status = ActivityStatus.ACTIVE;
        this.createTime = new Date();
        this.updateTime = new Date();
    }

    // Getter 和 Setter 方法
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ActivityType getType() {
        return type;
    }

    public void setType(ActivityType type) {
        this.type = type;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Integer getCurrentParticipants() {
        return currentParticipants;
    }

    public void setCurrentParticipants(Integer currentParticipants) {
        this.currentParticipants = currentParticipants;
    }

    public ActivityStatus getStatus() {
        return status;
    }

    public void setStatus(ActivityStatus status) {
        this.status = status;
    }

    public String getRequirements() {
        return requirements;
    }

    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    // 检查是否还有空位
    public boolean hasAvailableSpots() {
        return currentParticipants < capacity && status == ActivityStatus.ACTIVE;
    }

    // 增加参与者
    public boolean addParticipant() {
        if (hasAvailableSpots()) {
            currentParticipants++;
            if (currentParticipants.equals(capacity)) {
                status = ActivityStatus.FULL;
            }
            return true;
        }
        return false;
    }

    // 移除参与者
    public void removeParticipant() {
        if (currentParticipants > 0) {
            currentParticipants--;
            if (status == ActivityStatus.FULL && currentParticipants < capacity) {
                status = ActivityStatus.ACTIVE;
            }
        }
    }

    @Override
    public String toString() {
        return "Activity{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", type=" + type +
                ", location='" + location + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", capacity=" + capacity +
                ", currentParticipants=" + currentParticipants +
                ", status=" + status +
                '}';
    }
} 