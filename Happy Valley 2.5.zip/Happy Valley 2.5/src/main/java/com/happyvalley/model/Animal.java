package com.happyvalley.model;

import java.util.Date;

/**
 * 动物信息实体类
 */
public class Animal {
    private Long id;
    private String name;
    private String species;
    private AnimalCategory category;
    private String habitat;
    private String description;
    private String diet;
    private String behavior;
    private String imageUrl;
    private AnimalStatus status;
    private Integer age;
    private String gender;
    private String caretaker;
    private Date feedingTime;
    private String healthStatus;
    private Date createTime;
    private Date updateTime;

    public enum AnimalCategory {
        MAMMAL("哺乳动物"),
        BIRD("鸟类"),
        REPTILE("爬行动物"),
        AMPHIBIAN("两栖动物"),
        FISH("鱼类"),
        INSECT("昆虫"),
        MARINE("海洋动物");

        private String description;

        AnimalCategory(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    public enum AnimalStatus {
        HEALTHY("健康"),
        SICK("生病"),
        RECOVERING("康复中"),
        QUARANTINE("隔离中"),
        DECEASED("已死亡"),
        TRANSFERRED("已转移");

        private String description;

        AnimalStatus(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    // 构造函数
    public Animal() {}

    public Animal(String name, String species, AnimalCategory category, String habitat, String description) {
        this.name = name;
        this.species = species;
        this.category = category;
        this.habitat = habitat;
        this.description = description;
        this.status = AnimalStatus.HEALTHY;
        this.createTime = new Date();
        this.updateTime = new Date();
    }

    // Getter 和 Setter 方法
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public AnimalCategory getCategory() {
        return category;
    }

    public void setCategory(AnimalCategory category) {
        this.category = category;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDiet() {
        return diet;
    }

    public void setDiet(String diet) {
        this.diet = diet;
    }

    public String getBehavior() {
        return behavior;
    }

    public void setBehavior(String behavior) {
        this.behavior = behavior;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public AnimalStatus getStatus() {
        return status;
    }

    public void setStatus(AnimalStatus status) {
        this.status = status;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCaretaker() {
        return caretaker;
    }

    public void setCaretaker(String caretaker) {
        this.caretaker = caretaker;
    }

    public Date getFeedingTime() {
        return feedingTime;
    }

    public void setFeedingTime(Date feedingTime) {
        this.feedingTime = feedingTime;
    }

    public String getHealthStatus() {
        return healthStatus;
    }

    public void setHealthStatus(String healthStatus) {
        this.healthStatus = healthStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", species='" + species + '\'' +
                ", category=" + category +
                ", habitat='" + habitat + '\'' +
                ", status=" + status +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                ", caretaker='" + caretaker + '\'' +
                '}';
    }
} 