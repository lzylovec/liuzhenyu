package com.happyvalley.dao;

import com.happyvalley.model.Ticket;
import com.happyvalley.util.DatabaseUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TicketDAO {
    
    public boolean save(Ticket ticket) {
        String sql = "INSERT INTO tickets (ticket_number, ticket_type, price, valid_date, visitor_id, visitor_name, visitor_phone, status, create_time, update_time, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setString(1, ticket.getTicketNumber());
            statement.setString(2, ticket.getTicketType().name());
            statement.setBigDecimal(3, ticket.getPrice());
            statement.setDate(4, new Date(ticket.getValidDate().getTime()));
            statement.setObject(5, ticket.getVisitorId());
            statement.setString(6, ticket.getVisitorName());
            statement.setString(7, ticket.getVisitorPhone());
            statement.setString(8, ticket.getStatus().name());
            statement.setTimestamp(9, new Timestamp(ticket.getCreateTime().getTime()));
            statement.setTimestamp(10, new Timestamp(ticket.getUpdateTime().getTime()));
            statement.setString(11, ticket.getRemarks());
            
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        ticket.setId(generatedKeys.getLong(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public Ticket findById(Long id) {
        String sql = "SELECT * FROM tickets WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, id);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapResultSetToTicket(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Ticket> findByVisitorId(Long visitorId) {
        List<Ticket> tickets = new ArrayList<>();
        String sql = "SELECT * FROM tickets WHERE visitor_id = ? ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, visitorId);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    tickets.add(mapResultSetToTicket(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tickets;
    }
    
    public List<Ticket> findAll() {
        List<Ticket> tickets = new ArrayList<>();
        String sql = "SELECT * FROM tickets ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            
            while (resultSet.next()) {
                tickets.add(mapResultSetToTicket(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tickets;
    }
    
    public boolean updateStatus(Long ticketId, Ticket.TicketStatus status) {
        String sql = "UPDATE tickets SET status = ?, update_time = ? WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, status.name());
            statement.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            statement.setLong(3, ticketId);
            
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * 统计指定日期和票型的已售票数量（不包括已取消和已退款的）
     */
    public int countSoldTicketsByDateAndType(Date validDate, Ticket.TicketType ticketType) {
        String sql = "SELECT COUNT(*) FROM tickets WHERE valid_date = ? AND ticket_type = ? AND status NOT IN ('CANCELLED', 'REFUNDED')";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setDate(1, validDate);
            statement.setString(2, ticketType.name());
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    /**
     * 获取指定日期所有票型的库存信息
     */
    public java.util.Map<Ticket.TicketType, Integer> getTicketInventoryByDate(Date validDate) {
        java.util.Map<Ticket.TicketType, Integer> inventory = new java.util.HashMap<>();
        String sql = "SELECT ticket_type, COUNT(*) as sold_count FROM tickets WHERE valid_date = ? AND status NOT IN ('CANCELLED', 'REFUNDED') GROUP BY ticket_type";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setDate(1, validDate);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                // 初始化所有票型的已售数量为0
                for (Ticket.TicketType type : Ticket.TicketType.values()) {
                    inventory.put(type, 0);
                }
                
                // 更新实际已售数量
                while (resultSet.next()) {
                    String ticketTypeStr = resultSet.getString("ticket_type");
                    int soldCount = resultSet.getInt("sold_count");
                    try {
                        Ticket.TicketType ticketType = Ticket.TicketType.valueOf(ticketTypeStr);
                        inventory.put(ticketType, soldCount);
                    } catch (IllegalArgumentException e) {
                        // 忽略无效的票型
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return inventory;
    }
    
    private Ticket mapResultSetToTicket(ResultSet resultSet) throws SQLException {
        Ticket ticket = new Ticket();
        ticket.setId(resultSet.getLong("id"));
        ticket.setTicketNumber(resultSet.getString("ticket_number"));
        ticket.setTicketType(Ticket.TicketType.valueOf(resultSet.getString("ticket_type")));
        ticket.setPrice(resultSet.getBigDecimal("price"));
        ticket.setValidDate(resultSet.getDate("valid_date"));
        ticket.setVisitorId(resultSet.getObject("visitor_id", Long.class));
        ticket.setVisitorName(resultSet.getString("visitor_name"));
        ticket.setVisitorPhone(resultSet.getString("visitor_phone"));
        ticket.setStatus(Ticket.TicketStatus.valueOf(resultSet.getString("status")));
        ticket.setCreateTime(resultSet.getTimestamp("create_time"));
        ticket.setUpdateTime(resultSet.getTimestamp("update_time"));
        ticket.setRemarks(resultSet.getString("remarks"));
        return ticket;
    }
} 