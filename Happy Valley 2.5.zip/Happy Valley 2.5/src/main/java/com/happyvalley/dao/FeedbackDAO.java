package com.happyvalley.dao;

import com.happyvalley.model.Feedback;
import com.happyvalley.util.DatabaseUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FeedbackDAO {
    
    public boolean save(Feedback feedback) {
        String sql = "INSERT INTO feedback (visitor_id, visitor_name, type, title, content, rating, status, create_time, update_time, contact, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setObject(1, feedback.getVisitorId());
            statement.setString(2, feedback.getVisitorName());
            statement.setString(3, feedback.getType().name());
            statement.setString(4, feedback.getTitle());
            statement.setString(5, feedback.getContent());
            statement.setObject(6, feedback.getRating());
            statement.setString(7, feedback.getStatus().name());
            statement.setTimestamp(8, new Timestamp(feedback.getCreateTime().getTime()));
            statement.setTimestamp(9, new Timestamp(feedback.getUpdateTime().getTime()));
            statement.setString(10, feedback.getContact());
            statement.setString(11, feedback.getCategory());
            
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        feedback.setId(generatedKeys.getLong(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public Feedback findById(Long id) {
        String sql = "SELECT * FROM feedback WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, id);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapResultSetToFeedback(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Feedback> findAll() {
        List<Feedback> feedbackList = new ArrayList<>();
        String sql = "SELECT * FROM feedback ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            
            while (resultSet.next()) {
                feedbackList.add(mapResultSetToFeedback(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return feedbackList;
    }
    
    public List<Feedback> findByVisitorId(Long visitorId) {
        List<Feedback> feedbackList = new ArrayList<>();
        String sql = "SELECT * FROM feedback WHERE visitor_id = ? ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, visitorId);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    feedbackList.add(mapResultSetToFeedback(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return feedbackList;
    }
    
    public List<Feedback> findByStatus(Feedback.FeedbackStatus status) {
        List<Feedback> feedbackList = new ArrayList<>();
        String sql = "SELECT * FROM feedback WHERE status = ? ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, status.name());
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    feedbackList.add(mapResultSetToFeedback(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return feedbackList;
    }
    
    public List<Feedback> findByType(Feedback.FeedbackType type) {
        List<Feedback> feedbackList = new ArrayList<>();
        String sql = "SELECT * FROM feedback WHERE type = ? ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, type.name());
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    feedbackList.add(mapResultSetToFeedback(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return feedbackList;
    }
    
    public boolean addReply(Long feedbackId, String replyContent, Long replyUserId, String replyUserName) {
        String sql = "UPDATE feedback SET reply = ?, reply_by_user_id = ?, reply_by_user_name = ?, reply_time = ?, status = ?, update_time = ? WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, replyContent);
            statement.setLong(2, replyUserId);
            statement.setString(3, replyUserName);
            statement.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
            statement.setString(5, Feedback.FeedbackStatus.REPLIED.name());
            statement.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
            statement.setLong(7, feedbackId);
            
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean updateStatus(Long feedbackId, Feedback.FeedbackStatus status) {
        String sql = "UPDATE feedback SET status = ?, update_time = ? WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, status.name());
            statement.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            statement.setLong(3, feedbackId);
            
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean delete(Long id) {
        String sql = "DELETE FROM feedback WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, id);
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // 获取反馈总数
    public int getTotalCount() {
        String sql = "SELECT COUNT(*) FROM feedback";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    // 带筛选条件的分页查询
    public List<Feedback> findWithPagination(int page, int pageSize, String type, String status, 
                                            String category, String startDate, String endDate, String search) {
        List<Feedback> feedbackList = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM feedback WHERE 1=1");
        List<Object> params = new ArrayList<>();
        
        // 添加筛选条件
        if (type != null && !type.isEmpty() && !"all".equals(type)) {
            sql.append(" AND type = ?");
            params.add(type);
        }
        
        if (status != null && !status.isEmpty() && !"all".equals(status)) {
            sql.append(" AND status = ?");
            params.add(status);
        }
        
        if (category != null && !category.isEmpty() && !"all".equals(category)) {
            sql.append(" AND category = ?");
            params.add(category);
        }
        
        if (startDate != null && !startDate.isEmpty()) {
            sql.append(" AND DATE(create_time) >= ?");
            params.add(startDate);
        }
        
        if (endDate != null && !endDate.isEmpty()) {
            sql.append(" AND DATE(create_time) <= ?");
            params.add(endDate);
        }
        
        if (search != null && !search.trim().isEmpty()) {
            sql.append(" AND (title LIKE ? OR content LIKE ? OR visitor_name LIKE ?)");
            String searchPattern = "%" + search.trim() + "%";
            params.add(searchPattern);
            params.add(searchPattern);
            params.add(searchPattern);
        }
        
        sql.append(" ORDER BY create_time DESC LIMIT ? OFFSET ?");
        params.add(pageSize);
        params.add((page - 1) * pageSize);
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                statement.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    feedbackList.add(mapResultSetToFeedback(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return feedbackList;
    }
    
    // 获取筛选条件下的总数
    public int getFilteredCount(String type, String status, String category, 
                              String startDate, String endDate, String search) {
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM feedback WHERE 1=1");
        List<Object> params = new ArrayList<>();
        
        // 添加筛选条件（与分页查询相同的逻辑）
        if (type != null && !type.isEmpty() && !"all".equals(type)) {
            sql.append(" AND type = ?");
            params.add(type);
        }
        
        if (status != null && !status.isEmpty() && !"all".equals(status)) {
            sql.append(" AND status = ?");
            params.add(status);
        }
        
        if (category != null && !category.isEmpty() && !"all".equals(category)) {
            sql.append(" AND category = ?");
            params.add(category);
        }
        
        if (startDate != null && !startDate.isEmpty()) {
            sql.append(" AND DATE(create_time) >= ?");
            params.add(startDate);
        }
        
        if (endDate != null && !endDate.isEmpty()) {
            sql.append(" AND DATE(create_time) <= ?");
            params.add(endDate);
        }
        
        if (search != null && !search.trim().isEmpty()) {
            sql.append(" AND (title LIKE ? OR content LIKE ? OR visitor_name LIKE ?)");
            String searchPattern = "%" + search.trim() + "%";
            params.add(searchPattern);
            params.add(searchPattern);
            params.add(searchPattern);
        }
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                statement.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    private Feedback mapResultSetToFeedback(ResultSet resultSet) throws SQLException {
        Feedback feedback = new Feedback();
        feedback.setId(resultSet.getLong("id"));
        feedback.setVisitorId(resultSet.getObject("visitor_id", Long.class));
        feedback.setVisitorName(resultSet.getString("visitor_name"));
        feedback.setType(Feedback.FeedbackType.valueOf(resultSet.getString("type")));
        feedback.setTitle(resultSet.getString("title"));
        feedback.setContent(resultSet.getString("content"));
        feedback.setRating(resultSet.getObject("rating", Integer.class));
        feedback.setStatus(Feedback.FeedbackStatus.valueOf(resultSet.getString("status")));
        feedback.setReply(resultSet.getString("reply"));
        feedback.setReplyByUserId(resultSet.getObject("reply_by_user_id", Long.class));
        feedback.setReplyByUserName(resultSet.getString("reply_by_user_name"));
        feedback.setReplyTime(resultSet.getTimestamp("reply_time"));
        feedback.setCreateTime(resultSet.getTimestamp("create_time"));
        feedback.setUpdateTime(resultSet.getTimestamp("update_time"));
        feedback.setContact(resultSet.getString("contact"));
        feedback.setCategory(resultSet.getString("category"));
        return feedback;
    }
}