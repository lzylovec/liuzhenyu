package com.happyvalley.dao;

import com.happyvalley.model.Activity;
import com.happyvalley.util.DatabaseUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ActivityDAO {
    
    public boolean save(Activity activity) {
        String sql = "INSERT INTO activities (name, description, type, location, start_time, end_time, capacity, current_participants, status, requirements, image_url, create_time, update_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setString(1, activity.getName());
            statement.setString(2, activity.getDescription());
            statement.setString(3, activity.getType().name());
            statement.setString(4, activity.getLocation());
            statement.setTimestamp(5, activity.getStartTime() != null ? new Timestamp(activity.getStartTime().getTime()) : null);
            statement.setTimestamp(6, activity.getEndTime() != null ? new Timestamp(activity.getEndTime().getTime()) : null);
            statement.setInt(7, activity.getCapacity());
            statement.setInt(8, activity.getCurrentParticipants());
            statement.setString(9, activity.getStatus().name());
            statement.setString(10, activity.getRequirements());
            statement.setString(11, activity.getImageUrl());
            statement.setTimestamp(12, new Timestamp(activity.getCreateTime().getTime()));
            statement.setTimestamp(13, new Timestamp(activity.getUpdateTime().getTime()));
            
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        activity.setId(generatedKeys.getLong(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public Activity findById(Long id) {
        String sql = "SELECT * FROM activities WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, id);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapResultSetToActivity(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Activity> findAll() {
        List<Activity> activities = new ArrayList<>();
        String sql = "SELECT * FROM activities ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            
            while (resultSet.next()) {
                activities.add(mapResultSetToActivity(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return activities;
    }
    
    public List<Activity> findByStatus(Activity.ActivityStatus status) {
        List<Activity> activities = new ArrayList<>();
        String sql = "SELECT * FROM activities WHERE status = ? ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, status.name());
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    activities.add(mapResultSetToActivity(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return activities;
    }
    
    public List<Activity> findByType(Activity.ActivityType type) {
        List<Activity> activities = new ArrayList<>();
        String sql = "SELECT * FROM activities WHERE type = ? ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, type.name());
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    activities.add(mapResultSetToActivity(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return activities;
    }
    
    public boolean update(Activity activity) {
        String sql = "UPDATE activities SET name = ?, description = ?, type = ?, location = ?, start_time = ?, end_time = ?, capacity = ?, current_participants = ?, status = ?, requirements = ?, image_url = ?, update_time = ? WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, activity.getName());
            statement.setString(2, activity.getDescription());
            statement.setString(3, activity.getType().name());
            statement.setString(4, activity.getLocation());
            statement.setTimestamp(5, activity.getStartTime() != null ? new Timestamp(activity.getStartTime().getTime()) : null);
            statement.setTimestamp(6, activity.getEndTime() != null ? new Timestamp(activity.getEndTime().getTime()) : null);
            statement.setInt(7, activity.getCapacity());
            statement.setInt(8, activity.getCurrentParticipants());
            statement.setString(9, activity.getStatus().name());
            statement.setString(10, activity.getRequirements());
            statement.setString(11, activity.getImageUrl());
            statement.setTimestamp(12, new Timestamp(activity.getUpdateTime().getTime()));
            statement.setLong(13, activity.getId());
            
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean delete(Long id) {
        String sql = "DELETE FROM activities WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, id);
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private Activity mapResultSetToActivity(ResultSet resultSet) throws SQLException {
        Activity activity = new Activity();
        activity.setId(resultSet.getLong("id"));
        activity.setName(resultSet.getString("name"));
        activity.setDescription(resultSet.getString("description"));
        activity.setType(Activity.ActivityType.valueOf(resultSet.getString("type")));
        activity.setLocation(resultSet.getString("location"));
        activity.setStartTime(resultSet.getTimestamp("start_time"));
        activity.setEndTime(resultSet.getTimestamp("end_time"));
        activity.setCapacity(resultSet.getInt("capacity"));
        activity.setCurrentParticipants(resultSet.getInt("current_participants"));
        activity.setStatus(Activity.ActivityStatus.valueOf(resultSet.getString("status")));
        activity.setRequirements(resultSet.getString("requirements"));
        activity.setImageUrl(resultSet.getString("image_url"));
        activity.setCreateTime(resultSet.getTimestamp("create_time"));
        activity.setUpdateTime(resultSet.getTimestamp("update_time"));
        return activity;
    }
} 