package com.happyvalley.dao;

import com.happyvalley.model.Animal;
import com.happyvalley.util.DatabaseUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnimalDAO {
    
    public boolean save(Animal animal) {
        String sql = "INSERT INTO animals (name, species, category, habitat, description, diet, behavior, image_url, status, age, gender, caretaker, feeding_time, health_status, create_time, update_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            statement.setString(1, animal.getName());
            statement.setString(2, animal.getSpecies());
            statement.setString(3, animal.getCategory().name());
            statement.setString(4, animal.getHabitat());
            statement.setString(5, animal.getDescription());
            statement.setString(6, animal.getDiet());
            statement.setString(7, animal.getBehavior());
            statement.setString(8, animal.getImageUrl());
            statement.setString(9, animal.getStatus().name());
            statement.setObject(10, animal.getAge());
            statement.setString(11, animal.getGender());
            statement.setString(12, animal.getCaretaker());
            statement.setTime(13, animal.getFeedingTime() != null ? new Time(animal.getFeedingTime().getTime()) : null);
            statement.setString(14, animal.getHealthStatus());
            statement.setTimestamp(15, new Timestamp(animal.getCreateTime().getTime()));
            statement.setTimestamp(16, new Timestamp(animal.getUpdateTime().getTime()));
            
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        animal.setId(generatedKeys.getLong(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public Animal findById(Long id) {
        String sql = "SELECT * FROM animals WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, id);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapResultSetToAnimal(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Animal> findAll() {
        List<Animal> animals = new ArrayList<>();
        String sql = "SELECT * FROM animals ORDER BY create_time DESC";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            
            while (resultSet.next()) {
                animals.add(mapResultSetToAnimal(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return animals;
    }
    
    public List<Animal> findByCategory(Animal.AnimalCategory category) {
        List<Animal> animals = new ArrayList<>();
        String sql = "SELECT * FROM animals WHERE category = ? ORDER BY name";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, category.name());
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    animals.add(mapResultSetToAnimal(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return animals;
    }
    
    public List<Animal> findByStatus(Animal.AnimalStatus status) {
        List<Animal> animals = new ArrayList<>();
        String sql = "SELECT * FROM animals WHERE status = ? ORDER BY name";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, status.name());
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    animals.add(mapResultSetToAnimal(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return animals;
    }
    
    public boolean update(Animal animal) {
        String sql = "UPDATE animals SET name = ?, species = ?, category = ?, habitat = ?, description = ?, diet = ?, behavior = ?, image_url = ?, status = ?, age = ?, gender = ?, caretaker = ?, feeding_time = ?, health_status = ?, update_time = ? WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, animal.getName());
            statement.setString(2, animal.getSpecies());
            statement.setString(3, animal.getCategory().name());
            statement.setString(4, animal.getHabitat());
            statement.setString(5, animal.getDescription());
            statement.setString(6, animal.getDiet());
            statement.setString(7, animal.getBehavior());
            statement.setString(8, animal.getImageUrl());
            statement.setString(9, animal.getStatus().name());
            statement.setObject(10, animal.getAge());
            statement.setString(11, animal.getGender());
            statement.setString(12, animal.getCaretaker());
            statement.setTime(13, animal.getFeedingTime() != null ? new Time(animal.getFeedingTime().getTime()) : null);
            statement.setString(14, animal.getHealthStatus());
            statement.setTimestamp(15, new Timestamp(animal.getUpdateTime().getTime()));
            statement.setLong(16, animal.getId());
            
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean delete(Long id) {
        String sql = "DELETE FROM animals WHERE id = ?";
        
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, id);
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private Animal mapResultSetToAnimal(ResultSet resultSet) throws SQLException {
        Animal animal = new Animal();
        animal.setId(resultSet.getLong("id"));
        animal.setName(resultSet.getString("name"));
        animal.setSpecies(resultSet.getString("species"));
        animal.setCategory(Animal.AnimalCategory.valueOf(resultSet.getString("category")));
        animal.setHabitat(resultSet.getString("habitat"));
        animal.setDescription(resultSet.getString("description"));
        animal.setDiet(resultSet.getString("diet"));
        animal.setBehavior(resultSet.getString("behavior"));
        animal.setImageUrl(resultSet.getString("image_url"));
        animal.setStatus(Animal.AnimalStatus.valueOf(resultSet.getString("status")));
        animal.setAge(resultSet.getObject("age", Integer.class));
        animal.setGender(resultSet.getString("gender"));
        animal.setCaretaker(resultSet.getString("caretaker"));
        animal.setFeedingTime(resultSet.getTime("feeding_time"));
        animal.setHealthStatus(resultSet.getString("health_status"));
        animal.setCreateTime(resultSet.getTimestamp("create_time"));
        animal.setUpdateTime(resultSet.getTimestamp("update_time"));
        return animal;
    }
} 