package com.happyvalley.servlet;

import com.happyvalley.dao.UserDAO;
import com.happyvalley.model.User;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    
    private UserDAO userDAO = new UserDAO();
    private Gson gson = new Gson();
    
    // 邮箱验证正则表达式
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    
    // 手机号验证正则表达式
    private static final Pattern PHONE_PATTERN = 
        Pattern.compile("^1[3-9]\\d{9}$");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // 转发到注册页面
        request.getRequestDispatcher("register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String realName = request.getParameter("realName");
        String roleStr = request.getParameter("role");
        
        Map<String, Object> result = new HashMap<>();
        
        // 验证输入
        String validationError = validateInput(username, password, confirmPassword, email, phone, realName);
        if (validationError != null) {
            result.put("success", false);
            result.put("message", validationError);
            writeJsonResponse(response, result);
            return;
        }
        
        try {
            // 检查用户名是否已存在
            if (userDAO.findByUsername(username) != null) {
                result.put("success", false);
                result.put("message", "用户名已存在");
                writeJsonResponse(response, result);
                return;
            }
            
            // 创建用户对象
            User user = new User(username, password, email, User.UserRole.VISITOR);
            user.setPhone(phone);
            user.setRealName(realName);
            
            // 保存用户
            if (userDAO.save(user)) {
                result.put("success", true);
                result.put("message", "注册成功，请登录");
                result.put("redirectUrl", "login");
            } else {
                result.put("success", false);
                result.put("message", "注册失败，请稍后重试");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "注册失败，请稍后重试");
        }
        
        writeJsonResponse(response, result);
    }
    
    private String validateInput(String username, String password, String confirmPassword, 
                               String email, String phone, String realName) {
        
        // 检查必填字段
        if (username == null || username.trim().isEmpty()) {
            return "用户名不能为空";
        }
        if (password == null || password.trim().isEmpty()) {
            return "密码不能为空";
        }
        if (confirmPassword == null || confirmPassword.trim().isEmpty()) {
            return "确认密码不能为空";
        }
        if (email == null || email.trim().isEmpty()) {
            return "邮箱不能为空";
        }
        if (realName == null || realName.trim().isEmpty()) {
            return "真实姓名不能为空";
        }

        
        // 检查用户名长度
        if (username.length() < 3 || username.length() > 20) {
            return "用户名长度必须在3-20个字符之间";
        }
        
        // 检查密码长度
        if (password.length() < 6 || password.length() > 50) {
            return "密码长度必须在6-50个字符之间";
        }
        
        // 检查密码确认
        if (!password.equals(confirmPassword)) {
            return "两次输入的密码不一致";
        }
        
        // 检查邮箱格式
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            return "邮箱格式不正确";
        }
        
        // 检查手机号格式（如果提供）
        if (phone != null && !phone.trim().isEmpty() && !PHONE_PATTERN.matcher(phone).matches()) {
            return "手机号格式不正确";
        }
        

        
        return null; // 验证通过
    }
    
    private void writeJsonResponse(HttpServletResponse response, Map<String, Object> result) 
            throws IOException {
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(result));
        out.flush();
    }
}