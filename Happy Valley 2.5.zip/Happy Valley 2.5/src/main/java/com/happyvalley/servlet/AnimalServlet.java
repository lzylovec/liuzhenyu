package com.happyvalley.servlet;

import com.happyvalley.service.AnimalService;
import com.happyvalley.model.Animal;
import com.happyvalley.model.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/animal/*")
public class AnimalServlet extends HttpServlet {
    
    private AnimalService animalService = new AnimalService();
    private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/list";
        }
        
        switch (pathInfo) {
            case "/list":
                handleGetAnimals(request, response);
                break;
            case "/detail":
                handleGetAnimalDetail(request, response);
                break;
            case "/healthy":
                handleGetHealthyAnimals(request, response);
                break;
            case "/need-attention":
                handleGetAnimalsNeedingAttention(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/add":
            case "/create":
                handleAddAnimal(request, response);
                break;
            case "/update":
                handleUpdateAnimal(request, response);
                break;
            case "/delete":
                handleDeleteAnimal(request, response);
                break;
            case "/update-health":
                handleUpdateHealthStatus(request, response);
                break;
            case "/assign-caretaker":
                handleAssignCaretaker(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void handleGetAnimals(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String category = request.getParameter("category");
            String status = request.getParameter("status");
            
            List<Animal> animals;
            
            if (category != null && !category.isEmpty()) {
                Animal.AnimalCategory animalCategory = Animal.AnimalCategory.valueOf(category.toUpperCase());
                animals = animalService.getAnimalsByCategory(animalCategory);
            } else if (status != null && !status.isEmpty()) {
                Animal.AnimalStatus animalStatus = Animal.AnimalStatus.valueOf(status.toUpperCase());
                animals = animalService.getAnimalsByStatus(animalStatus);
            } else {
                animals = animalService.getAllAnimals();
            }
            
            result.put("success", true);
            result.put("data", animals);
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取动物信息失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetAnimalDetail(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String animalIdStr = request.getParameter("id");
            if (animalIdStr == null) {
                result.put("success", false);
                result.put("message", "动物ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long animalId = Long.parseLong(animalIdStr);
            Animal animal = animalService.getAnimalById(animalId);
            
            if (animal != null) {
                result.put("success", true);
                result.put("data", animal);
            } else {
                result.put("success", false);
                result.put("message", "动物不存在");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取动物详情失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetHealthyAnimals(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            List<Animal> animals = animalService.getHealthyAnimals();
            result.put("success", true);
            result.put("data", animals);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取健康动物信息失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetAnimalsNeedingAttention(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查员工/管理员权限
        if (!checkEmployeePermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            List<Animal> animals = animalService.getAnimalsNeedingAttention();
            result.put("success", true);
            result.put("data", animals);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取需要关注的动物失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleAddAnimal(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 尝试读取JSON请求体
            JsonObject jsonData = readJsonFromRequest(request);
            
            String name, species, categoryStr, habitat, description, diet, behavior, imageUrl, gender, caretaker;
            Integer age;
            
            if (jsonData != null) {
                // JSON格式请求
                name = getJsonStringValue(jsonData, "name");
                species = getJsonStringValue(jsonData, "species");
                categoryStr = getJsonStringValue(jsonData, "category");
                habitat = getJsonStringValue(jsonData, "habitat");
                description = getJsonStringValue(jsonData, "description");
                diet = getJsonStringValue(jsonData, "diet");
                behavior = getJsonStringValue(jsonData, "behavior");
                imageUrl = getJsonStringValue(jsonData, "imageUrl");
                gender = getJsonStringValue(jsonData, "gender");
                caretaker = getJsonStringValue(jsonData, "caretaker");
                age = getJsonIntValue(jsonData, "age");
            } else {
                // 表单格式请求
                name = request.getParameter("name");
                species = request.getParameter("species");
                categoryStr = request.getParameter("category");
                habitat = request.getParameter("habitat");
                description = request.getParameter("description");
                diet = request.getParameter("diet");
                behavior = request.getParameter("behavior");
                imageUrl = request.getParameter("imageUrl");
                gender = request.getParameter("gender");
                caretaker = request.getParameter("caretaker");
                String ageStr = request.getParameter("age");
                age = ageStr != null && !ageStr.isEmpty() ? Integer.parseInt(ageStr) : null;
            }
            
            // 验证必填字段
            if (name == null || name.trim().isEmpty() ||
                species == null || species.trim().isEmpty() ||
                categoryStr == null) {
                result.put("success", false);
                result.put("message", "请填写完整的动物信息");
                writeJsonResponse(response, result);
                return;
            }
            
            Animal.AnimalCategory category = Animal.AnimalCategory.valueOf(categoryStr.toUpperCase());
            
            boolean success = animalService.addAnimal(name, species, category, habitat, description,
                    diet, behavior, imageUrl, age, gender, caretaker);
            
            if (success) {
                result.put("success", true);
                result.put("message", "动物添加成功");
            } else {
                result.put("success", false);
                result.put("message", "动物添加失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "动物添加失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleUpdateAnimal(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 尝试读取JSON请求体
            JsonObject jsonData = readJsonFromRequest(request);
            
            String animalIdStr;
            if (jsonData != null) {
                animalIdStr = getJsonStringValue(jsonData, "id");
            } else {
                animalIdStr = request.getParameter("id");
            }
            
            if (animalIdStr == null) {
                result.put("success", false);
                result.put("message", "动物ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long animalId = Long.parseLong(animalIdStr);
            Animal animal = animalService.getAnimalById(animalId);
            
            if (animal == null) {
                result.put("success", false);
                result.put("message", "动物不存在");
                writeJsonResponse(response, result);
                return;
            }
            
            // 更新动物信息
            String name, species, categoryStr, statusStr, habitat, description, diet, behavior, imageUrl, gender, caretaker, healthStatus;
            Integer age;
            
            if (jsonData != null) {
                // JSON格式请求
                name = getJsonStringValue(jsonData, "name");
                species = getJsonStringValue(jsonData, "species");
                categoryStr = getJsonStringValue(jsonData, "category");
                statusStr = getJsonStringValue(jsonData, "status");
                habitat = getJsonStringValue(jsonData, "habitat");
                description = getJsonStringValue(jsonData, "description");
                diet = getJsonStringValue(jsonData, "diet");
                behavior = getJsonStringValue(jsonData, "behavior");
                imageUrl = getJsonStringValue(jsonData, "imageUrl");
                gender = getJsonStringValue(jsonData, "gender");
                caretaker = getJsonStringValue(jsonData, "caretaker");
                healthStatus = getJsonStringValue(jsonData, "healthStatus");
                age = getJsonIntValue(jsonData, "age");
            } else {
                // 表单格式请求
                name = request.getParameter("name");
                species = request.getParameter("species");
                categoryStr = request.getParameter("category");
                statusStr = request.getParameter("status");
                habitat = request.getParameter("habitat");
                description = request.getParameter("description");
                diet = request.getParameter("diet");
                behavior = request.getParameter("behavior");
                imageUrl = request.getParameter("imageUrl");
                gender = request.getParameter("gender");
                caretaker = request.getParameter("caretaker");
                healthStatus = request.getParameter("healthStatus");
                String ageStr = request.getParameter("age");
                age = ageStr != null && !ageStr.isEmpty() ? Integer.parseInt(ageStr) : null;
            }
            
            if (name != null && !name.trim().isEmpty()) {
                animal.setName(name.trim());
            }
            
            if (species != null && !species.trim().isEmpty()) {
                animal.setSpecies(species.trim());
            }
            
            if (categoryStr != null && !categoryStr.trim().isEmpty()) {
                animal.setCategory(Animal.AnimalCategory.valueOf(categoryStr.toUpperCase()));
            }
            
            if (statusStr != null && !statusStr.trim().isEmpty()) {
                animal.setStatus(Animal.AnimalStatus.valueOf(statusStr.toUpperCase()));
            }
            
            if (habitat != null) {
                animal.setHabitat(habitat);
            }
            
            if (description != null) {
                animal.setDescription(description);
            }
            
            if (diet != null) {
                animal.setDiet(diet);
            }
            
            if (behavior != null) {
                animal.setBehavior(behavior);
            }
            
            if (imageUrl != null) {
                animal.setImageUrl(imageUrl);
            }
            
            if (gender != null) {
                animal.setGender(gender);
            }
            
            if (caretaker != null) {
                animal.setCaretaker(caretaker);
            }
            
            if (healthStatus != null) {
                animal.setHealthStatus(healthStatus);
            }
            
            if (age != null) {
                animal.setAge(age);
            }
            
            boolean success = animalService.updateAnimal(animal);
            
            if (success) {
                result.put("success", true);
                result.put("message", "动物信息更新成功");
            } else {
                result.put("success", false);
                result.put("message", "动物信息更新失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "动物信息更新失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleDeleteAnimal(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String animalIdStr = request.getParameter("id");
            if (animalIdStr == null) {
                result.put("success", false);
                result.put("message", "动物ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long animalId = Long.parseLong(animalIdStr);
            boolean success = animalService.deleteAnimal(animalId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "动物删除成功");
            } else {
                result.put("success", false);
                result.put("message", "动物删除失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "动物删除失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleUpdateHealthStatus(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查员工/管理员权限
        if (!checkEmployeePermission(request, response)) {
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            String animalIdStr = request.getParameter("animalId");
            String statusStr = request.getParameter("status");
            String healthDetail = request.getParameter("healthDetail");
            
            if (animalIdStr == null || statusStr == null) {
                result.put("success", false);
                result.put("message", "动物ID和健康状态不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long animalId = Long.parseLong(animalIdStr);
            Animal.AnimalStatus status = Animal.AnimalStatus.valueOf(statusStr.toUpperCase());
            
            boolean success = animalService.updateAnimalHealthStatus(animalId, status, healthDetail);
            
            if (success) {
                result.put("success", true);
                result.put("message", "动物健康状态更新成功");
            } else {
                result.put("success", false);
                result.put("message", "动物健康状态更新失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "动物健康状态更新失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleAssignCaretaker(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            String animalIdStr = request.getParameter("animalId");
            String caretakerName = request.getParameter("caretakerName");
            
            if (animalIdStr == null || caretakerName == null || caretakerName.trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "动物ID和饲养员姓名不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long animalId = Long.parseLong(animalIdStr);
            boolean success = animalService.assignCaretaker(animalId, caretakerName.trim());
            
            if (success) {
                result.put("success", true);
                result.put("message", "饲养员分配成功");
            } else {
                result.put("success", false);
                result.put("message", "饲养员分配失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "饲养员分配失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private boolean checkAdminPermission(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || user.getRole() != User.UserRole.ADMIN) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "权限不足，仅管理员可操作");
            writeJsonResponse(response, result);
            return false;
        }
        
        return true;
    }
    
    private boolean checkEmployeePermission(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || (user.getRole() != User.UserRole.ADMIN && user.getRole() != User.UserRole.EMPLOYEE)) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "权限不足，仅员工和管理员可操作");
            writeJsonResponse(response, result);
            return false;
        }
        
        return true;
    }
    
    private void writeJsonResponse(HttpServletResponse response, Map<String, Object> result) 
            throws IOException {
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(result));
        out.flush();
    }
    
    private JsonObject readJsonFromRequest(HttpServletRequest request) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = request.getReader().readLine()) != null) {
            sb.append(line);
        }
        String jsonString = sb.toString();
        if (jsonString.isEmpty()) {
            return null;
        }
        return JsonParser.parseString(jsonString).getAsJsonObject();
    }
    
    private String getJsonStringValue(JsonObject json, String key) {
        if (json.has(key) && !json.get(key).isJsonNull()) {
            return json.get(key).getAsString();
        }
        return null;
    }
    
    private Integer getJsonIntValue(JsonObject json, String key) {
        if (json.has(key) && !json.get(key).isJsonNull()) {
            String value = json.get(key).getAsString();
            if (value != null && !value.isEmpty()) {
                return Integer.parseInt(value);
            }
        }
        return null;
    }
}