package com.happyvalley.servlet;

import com.happyvalley.service.ActivityService;
import com.happyvalley.model.Activity;
import com.happyvalley.model.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/activity/*")
public class ActivityServlet extends HttpServlet {
    
    private ActivityService activityService = new ActivityService();
    private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/list";
        }
        
        switch (pathInfo) {
            case "/list":
                handleGetActivities(request, response);
                break;
            case "/detail":
                handleGetActivityDetail(request, response);
                break;
            case "/active":
                handleGetActiveActivities(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/create":
                handleCreateActivity(request, response);
                break;
            case "/update":
                handleUpdateActivity(request, response);
                break;
            case "/delete":
                handleDeleteActivity(request, response);
                break;
            case "/participate":
                handleParticipateActivity(request, response);
                break;
            case "/cancel-participation":
                handleCancelParticipation(request, response);
                break;
            case "/change-status":
                handleChangeStatus(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void handleGetActivities(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String type = request.getParameter("type");
            String status = request.getParameter("status");
            
            List<Activity> activities;
            
            if (type != null && !type.isEmpty()) {
                Activity.ActivityType activityType = Activity.ActivityType.valueOf(type.toUpperCase());
                activities = activityService.getActivitiesByType(activityType);
            } else if (status != null && !status.isEmpty()) {
                Activity.ActivityStatus activityStatus = Activity.ActivityStatus.valueOf(status.toUpperCase());
                activities = activityService.getActivitiesByStatus(activityStatus);
            } else {
                activities = activityService.getAllActivities();
            }
            
            result.put("success", true);
            result.put("data", activities);
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取活动信息失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetActivityDetail(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String activityIdStr = request.getParameter("id");
            if (activityIdStr == null) {
                result.put("success", false);
                result.put("message", "活动ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long activityId = Long.parseLong(activityIdStr);
            Activity activity = activityService.getActivityById(activityId);
            
            if (activity != null) {
                result.put("success", true);
                result.put("data", activity);
            } else {
                result.put("success", false);
                result.put("message", "活动不存在");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取活动详情失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetActiveActivities(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            List<Activity> activities = activityService.getActiveActivities();
            result.put("success", true);
            result.put("data", activities);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取开放活动失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleCreateActivity(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 读取JSON数据
            StringBuilder jsonBuffer = new StringBuilder();
            String line;
            while ((line = request.getReader().readLine()) != null) {
                jsonBuffer.append(line);
            }
            
            // 解析JSON
            Map<String, Object> jsonData = gson.fromJson(jsonBuffer.toString(), Map.class);
            
            String name = (String) jsonData.get("name");
            String description = (String) jsonData.get("description");
            String typeStr = (String) jsonData.get("type");
            String location = (String) jsonData.get("location");
            String startTimeStr = (String) jsonData.get("startTime");
            String endTimeStr = (String) jsonData.get("endTime");
            Object capacityObj = jsonData.get("capacity");
            String requirements = (String) jsonData.get("requirements");
            String imageUrl = (String) jsonData.get("imageUrl");
            
            // 验证必填字段
            if (name == null || name.trim().isEmpty() ||
                typeStr == null || capacityObj == null) {
                result.put("success", false);
                result.put("message", "请填写完整的活动信息");
                writeJsonResponse(response, result);
                return;
            }
            
            Activity.ActivityType type = Activity.ActivityType.valueOf(typeStr.toUpperCase());
            Integer capacity = null;
            if (capacityObj != null) {
                if (capacityObj instanceof Number) {
                    capacity = ((Number) capacityObj).intValue();
                } else if (capacityObj instanceof String && !((String) capacityObj).isEmpty()) {
                    capacity = Integer.parseInt((String) capacityObj);
                }
            }
            
            // 支持前端发送的日期格式 "2025-06-27T00:58"
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            Date startTime = null;
            Date endTime = null;
            
            if (startTimeStr != null && !startTimeStr.isEmpty()) {
                try {
                    startTime = dateFormat.parse(startTimeStr);
                } catch (Exception e) {
                    // 如果解析失败，尝试其他格式
                    SimpleDateFormat fallbackFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    startTime = fallbackFormat.parse(startTimeStr);
                }
            }
            
            if (endTimeStr != null && !endTimeStr.isEmpty()) {
                try {
                    endTime = dateFormat.parse(endTimeStr);
                } catch (Exception e) {
                    // 如果解析失败，尝试其他格式
                    SimpleDateFormat fallbackFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    endTime = fallbackFormat.parse(endTimeStr);
                }
            }
            
            boolean success = activityService.createActivity(name, description, type, location, 
                    startTime, endTime, capacity, requirements, imageUrl);
            
            if (success) {
                result.put("success", true);
                result.put("message", "活动创建成功");
            } else {
                result.put("success", false);
                result.put("message", "活动创建失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "活动创建失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleUpdateActivity(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 读取JSON数据
            StringBuilder jsonBuffer = new StringBuilder();
            String line;
            while ((line = request.getReader().readLine()) != null) {
                jsonBuffer.append(line);
            }
            
            // 解析JSON
            Map<String, Object> jsonData = gson.fromJson(jsonBuffer.toString(), Map.class);
            
            Object activityIdObj = jsonData.get("id");
            if (activityIdObj == null) {
                result.put("success", false);
                result.put("message", "活动ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long activityId;
            if (activityIdObj instanceof Number) {
                activityId = ((Number) activityIdObj).longValue();
            } else {
                activityId = Long.parseLong(activityIdObj.toString());
            }
            
            Activity activity = activityService.getActivityById(activityId);
            
            if (activity == null) {
                result.put("success", false);
                result.put("message", "活动不存在");
                writeJsonResponse(response, result);
                return;
            }
            
            // 更新活动信息
            String name = (String) jsonData.get("name");
            if (name != null && !name.trim().isEmpty()) {
                activity.setName(name.trim());
            }
            
            String description = (String) jsonData.get("description");
            if (description != null) {
                activity.setDescription(description);
            }
            
            String location = (String) jsonData.get("location");
            if (location != null) {
                activity.setLocation(location);
            }
            
            String requirements = (String) jsonData.get("requirements");
            if (requirements != null) {
                activity.setRequirements(requirements);
            }
            
            String imageUrl = (String) jsonData.get("imageUrl");
            if (imageUrl != null) {
                activity.setImageUrl(imageUrl);
            }
            
            boolean success = activityService.updateActivity(activity);
            
            if (success) {
                result.put("success", true);
                result.put("message", "活动更新成功");
            } else {
                result.put("success", false);
                result.put("message", "活动更新失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "活动更新失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleDeleteActivity(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 读取JSON数据
            StringBuilder jsonBuffer = new StringBuilder();
            String line;
            while ((line = request.getReader().readLine()) != null) {
                jsonBuffer.append(line);
            }
            
            // 解析JSON
            Map<String, Object> jsonData = gson.fromJson(jsonBuffer.toString(), Map.class);
            
            Object activityIdObj = jsonData.get("id");
            if (activityIdObj == null) {
                result.put("success", false);
                result.put("message", "活动ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long activityId;
            if (activityIdObj instanceof Number) {
                activityId = ((Number) activityIdObj).longValue();
            } else {
                activityId = Long.parseLong(activityIdObj.toString());
            }
            boolean success = activityService.deleteActivity(activityId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "活动删除成功");
            } else {
                result.put("success", false);
                result.put("message", "活动删除失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "活动删除失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleParticipateActivity(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String activityIdStr = request.getParameter("activityId");
            if (activityIdStr == null) {
                result.put("success", false);
                result.put("message", "活动ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long activityId = Long.parseLong(activityIdStr);
            boolean success = activityService.participateActivity(activityId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "参与活动成功");
            } else {
                result.put("success", false);
                result.put("message", "参与活动失败，可能活动已满员或不可用");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "参与活动失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleCancelParticipation(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String activityIdStr = request.getParameter("activityId");
            if (activityIdStr == null) {
                result.put("success", false);
                result.put("message", "活动ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long activityId = Long.parseLong(activityIdStr);
            boolean success = activityService.cancelParticipation(activityId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "取消参与成功");
            } else {
                result.put("success", false);
                result.put("message", "取消参与失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "取消参与失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleChangeStatus(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String activityIdStr = null;
            String statusStr = null;
            
            // 尝试从JSON请求体中读取数据
            try {
                StringBuilder jsonBuffer = new StringBuilder();
                String line;
                while ((line = request.getReader().readLine()) != null) {
                    jsonBuffer.append(line);
                }
                
                if (jsonBuffer.length() > 0) {
                    // 解析JSON
                    Map<String, Object> jsonData = gson.fromJson(jsonBuffer.toString(), Map.class);
                    Object idObj = jsonData.get("id");
                    if (idObj != null) {
                        activityIdStr = idObj.toString();
                    }
                    Object statusObj = jsonData.get("status");
                    if (statusObj != null) {
                        statusStr = statusObj.toString();
                    }
                }
            } catch (Exception e) {
                // 如果JSON解析失败，尝试从表单参数获取
                activityIdStr = request.getParameter("activityId");
                statusStr = request.getParameter("status");
            }
            
            // 如果JSON解析失败或没有数据，尝试从表单参数获取
            if (activityIdStr == null) {
                activityIdStr = request.getParameter("activityId");
            }
            if (statusStr == null) {
                statusStr = request.getParameter("status");
            }
            
            if (activityIdStr == null || statusStr == null) {
                result.put("success", false);
                result.put("message", "活动ID和状态不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            // 处理可能带小数点的ID字符串（如"2.0"）
            Long activityId;
            try {
                // 先尝试直接解析为Long
                activityId = Long.parseLong(activityIdStr);
            } catch (NumberFormatException e) {
                try {
                    // 如果失败，尝试先转换为Double再转换为Long
                    activityId = Double.valueOf(activityIdStr).longValue();
                } catch (NumberFormatException e2) {
                    result.put("success", false);
                    result.put("message", "无效的活动ID格式");
                    writeJsonResponse(response, result);
                    return;
                }
            }
            
            Activity.ActivityStatus status = Activity.ActivityStatus.valueOf(statusStr.toUpperCase());
            
            boolean success = activityService.changeActivityStatus(activityId, status);
            
            if (success) {
                result.put("success", true);
                result.put("message", "活动状态更新成功");
            } else {
                result.put("success", false);
                result.put("message", "活动状态更新失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "活动状态更新失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private boolean checkAdminPermission(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || user.getRole() != User.UserRole.ADMIN) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "权限不足，仅管理员可操作");
            writeJsonResponse(response, result);
            return false;
        }
        
        return true;
    }
    
    private void writeJsonResponse(HttpServletResponse response, Map<String, Object> result) 
            throws IOException {
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(result));
        out.flush();
    }
}