package com.happyvalley.servlet;

import com.happyvalley.dao.UserDAO;
import com.happyvalley.model.User;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    
    private UserDAO userDAO = new UserDAO();
    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // 如果已经登录，重定向到主页
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("user") != null) {
            response.sendRedirect("index.jsp");
        } else {
            // 转发到登录页面
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String redirectUrl = request.getParameter("redirect");
        
        Map<String, Object> result = new HashMap<>();
        
        // 验证输入
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            result.put("success", false);
            result.put("message", "用户名和密码不能为空");
            writeJsonResponse(response, result);
            return;
        }
        
        try {
            // 查找用户
            User user = userDAO.findByUsernameAndPassword(username.trim(), password);
            
            if (user != null) {
                // 登录成功，创建session
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                session.setAttribute("userId", user.getId());
                session.setAttribute("username", user.getUsername());
                session.setAttribute("userRole", user.getRole());
                
                result.put("success", true);
                result.put("message", "登录成功");
                result.put("role", user.getRole().name());
                
                // 根据重定向参数决定跳转页面
                if (redirectUrl != null && !redirectUrl.trim().isEmpty()) {
                    result.put("redirectUrl", redirectUrl.trim());
                } else {
                    result.put("redirectUrl", "index.jsp");
                }
                
            } else {
                result.put("success", false);
                result.put("message", "用户名或密码错误");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "登录失败，请稍后重试");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void writeJsonResponse(HttpServletResponse response, Map<String, Object> result) 
            throws IOException {
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(result));
        out.flush();
    }
}