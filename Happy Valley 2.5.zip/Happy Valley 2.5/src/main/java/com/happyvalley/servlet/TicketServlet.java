package com.happyvalley.servlet;

import com.happyvalley.service.TicketService;
import com.happyvalley.model.Ticket;
import com.happyvalley.model.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/ticket/*")
public class TicketServlet extends HttpServlet {
    
    private TicketService ticketService = new TicketService();
    private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/list";
        }
        
        switch (pathInfo) {
            case "/list":
                handleGetTickets(request, response);
                break;
            case "/detail":
                handleGetTicketDetail(request, response);
                break;
            case "/inventory":
                handleGetTicketInventory(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/purchase":
                handlePurchaseTicket(request, response);
                break;
            case "/pay":
                handlePayTicket(request, response);
                break;
            case "/cancel":
                handleCancelTicket(request, response);
                break;
            case "/refund":
                handleRefundTicket(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void handleGetTickets(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            
            // 获取搜索参数
            String keyword = request.getParameter("keyword");
            String status = request.getParameter("status");
            String ticketType = request.getParameter("ticketType");
            String date = request.getParameter("date");
            
            List<Ticket> tickets;
            if (user.getRole() == User.UserRole.ADMIN) {
                // 管理员可以查看所有票务
                tickets = ticketService.getAllTickets();
            } else {
                // 普通用户只能查看自己的票务
                tickets = ticketService.getVisitorTickets(user.getId());
            }
            
            // 应用搜索过滤器
            if (tickets != null) {
                tickets = tickets.stream()
                    .filter(ticket -> {
                        // 关键词搜索（姓名、手机号、票号）
                        if (keyword != null && !keyword.trim().isEmpty()) {
                            String searchKeyword = keyword.trim().toLowerCase();
                            boolean matchesKeyword = false;
                            
                            // 搜索票号
                            if (ticket.getTicketNumber() != null && 
                                ticket.getTicketNumber().toLowerCase().contains(searchKeyword)) {
                                matchesKeyword = true;
                            }
                            
                            // 搜索游客姓名
                            if (ticket.getVisitorName() != null && 
                                ticket.getVisitorName().toLowerCase().contains(searchKeyword)) {
                                matchesKeyword = true;
                            }
                            
                            // 搜索游客手机号
                            if (ticket.getVisitorPhone() != null && 
                                ticket.getVisitorPhone().contains(searchKeyword)) {
                                matchesKeyword = true;
                            }
                            
                            if (!matchesKeyword) {
                                return false;
                            }
                        }
                        
                        // 状态过滤
                        if (status != null && !status.trim().isEmpty() && !status.equals("ALL")) {
                            if (!status.equals(ticket.getStatus().name())) {
                                return false;
                            }
                        }
                        
                        // 票类型过滤
                        if (ticketType != null && !ticketType.trim().isEmpty() && !ticketType.equals("ALL")) {
                            if (!ticketType.equals(ticket.getTicketType().name())) {
                                return false;
                            }
                        }
                        
                        // 日期过滤
                        if (date != null && !date.trim().isEmpty()) {
                            try {
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                Date filterDate = dateFormat.parse(date);
                                Date ticketDate = ticket.getValidDate();
                                
                                if (ticketDate == null || !dateFormat.format(ticketDate).equals(dateFormat.format(filterDate))) {
                                    return false;
                                }
                            } catch (Exception e) {
                                // 日期解析失败，忽略日期过滤
                            }
                        }
                        
                        return true;
                    })
                    .collect(java.util.stream.Collectors.toList());
            }
            
            result.put("success", true);
            result.put("data", tickets);
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取票务信息失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetTicketDetail(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String ticketIdStr = request.getParameter("id");
            if (ticketIdStr == null) {
                result.put("success", false);
                result.put("message", "票务ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long ticketId = Long.parseLong(ticketIdStr);
            Ticket ticket = ticketService.getTicketById(ticketId);
            
            if (ticket != null) {
                result.put("success", true);
                result.put("data", ticket);
            } else {
                result.put("success", false);
                result.put("message", "票务不存在");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取票务详情失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetTicketInventory(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String validDateStr = request.getParameter("date");
            if (validDateStr == null || validDateStr.trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "请提供查询日期");
                writeJsonResponse(response, result);
                return;
            }
            
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date validDate = dateFormat.parse(validDateStr);
            
            // 获取库存信息
            Map<Ticket.TicketType, Integer> inventory = ticketService.getTicketInventoryInfo(validDate);
            
            // 转换为前端友好的格式
            Map<String, Object> inventoryData = new HashMap<>();
            for (Map.Entry<Ticket.TicketType, Integer> entry : inventory.entrySet()) {
                Map<String, Object> ticketInfo = new HashMap<>();
                ticketInfo.put("available", entry.getValue());
                ticketInfo.put("total", TicketService.DAILY_TICKET_LIMIT);
                ticketInfo.put("sold", TicketService.DAILY_TICKET_LIMIT - entry.getValue());
                ticketInfo.put("description", entry.getKey().getDescription());
                ticketInfo.put("price", entry.getKey().getDefaultPrice());
                inventoryData.put(entry.getKey().name(), ticketInfo);
            }
            
            result.put("success", true);
            result.put("data", inventoryData);
            result.put("date", validDateStr);
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取库存信息失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handlePurchaseTicket(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 读取JSON数据
            StringBuilder jsonBuffer = new StringBuilder();
            String line;
            while ((line = request.getReader().readLine()) != null) {
                jsonBuffer.append(line);
            }
            
            // 解析JSON
            Map<String, Object> jsonData = gson.fromJson(jsonBuffer.toString(), Map.class);
            
            String ticketTypeStr = (String) jsonData.get("ticketType");
            String validDateStr = (String) jsonData.get("validDate");
            String visitorName = (String) jsonData.get("visitorName");
            String visitorPhone = (String) jsonData.get("visitorPhone");
            Object quantityObj = jsonData.get("quantity");
            
            // 验证参数
            if (ticketTypeStr == null || ticketTypeStr.trim().isEmpty() ||
                validDateStr == null || validDateStr.trim().isEmpty() ||
                visitorName == null || visitorName.trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "请填写完整的购票信息");
                writeJsonResponse(response, result);
                return;
            }
            
            // 获取用户信息并验证登录状态
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            
            if (user == null) {
                result.put("success", false);
                result.put("message", "请先登录后再购票");
                writeJsonResponse(response, result);
                return;
            }
            
            // 验证用户角色：只有游客可以购票
            if (user.getRole() != User.UserRole.VISITOR) {
                result.put("success", false);
                result.put("message", "购票功能仅对游客开放");
                writeJsonResponse(response, result);
                return;
            }
            
            // 解析参数
            Ticket.TicketType ticketType = Ticket.TicketType.valueOf(ticketTypeStr);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date validDate = dateFormat.parse(validDateStr);
            
            int quantity = 1;
            if (quantityObj != null) {
                if (quantityObj instanceof Number) {
                    quantity = ((Number) quantityObj).intValue();
                } else if (quantityObj instanceof String && !((String) quantityObj).isEmpty()) {
                    quantity = Integer.parseInt((String) quantityObj);
                }
            }
            
            // 验证数量
            if (quantity < 1 || quantity > 10) {
                result.put("success", false);
                result.put("message", "购票数量必须在1-10之间");
                writeJsonResponse(response, result);
                return;
            }
            
            // 购买票务（支持库存检查）
            if (quantity == 1) {
                // 单张票购买
                String purchaseResult = ticketService.purchaseTicket(ticketType, validDate, 
                        user.getId(), visitorName, visitorPhone);
                
                if (purchaseResult.startsWith("购票成功")) {
                    result.put("success", true);
                    result.put("message", purchaseResult);
                    // 从消息中提取票号
                    String ticketNumber = purchaseResult.substring(purchaseResult.indexOf("：") + 1);
                    result.put("ticketNumber", ticketNumber);
                } else {
                    result.put("success", false);
                    result.put("message", purchaseResult);
                }
            } else {
                // 批量购买票务
                Map<String, Object> purchaseResult = ticketService.purchaseTickets(ticketType, validDate, 
                        user.getId(), visitorName, visitorPhone, quantity);
                
                result.putAll(purchaseResult);
                
                // 如果成功购买，添加额外信息
                if ((Boolean) purchaseResult.get("success")) {
                    result.put("message", result.get("message") + "，请及时支付");
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "购票失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handlePayTicket(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 验证用户登录状态
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            
            if (user == null) {
                result.put("success", false);
                result.put("message", "请先登录");
                writeJsonResponse(response, result);
                return;
            }
            
            String ticketIdStr = request.getParameter("ticketId");
            if (ticketIdStr == null) {
                result.put("success", false);
                result.put("message", "票务ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long ticketId = Long.parseLong(ticketIdStr);
            
            // 验证权限：用户只能支付自己的订单
            Ticket ticket = ticketService.getTicketById(ticketId);
            if (ticket == null) {
                result.put("success", false);
                result.put("message", "订单不存在");
                writeJsonResponse(response, result);
                return;
            }
            
            if (user.getRole() != User.UserRole.ADMIN && !ticket.getVisitorId().equals(user.getId())) {
                result.put("success", false);
                result.put("message", "您只能支付自己的订单");
                writeJsonResponse(response, result);
                return;
            }
            
            boolean success = ticketService.payTicket(ticketId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "支付成功");
            } else {
                result.put("success", false);
                result.put("message", "支付失败，请检查票务状态");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "支付失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleCancelTicket(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 验证用户登录状态
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            
            if (user == null) {
                result.put("success", false);
                result.put("message", "请先登录");
                writeJsonResponse(response, result);
                return;
            }
            
            String ticketIdStr = request.getParameter("ticketId");
            if (ticketIdStr == null) {
                result.put("success", false);
                result.put("message", "票务ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long ticketId = Long.parseLong(ticketIdStr);
            
            // 验证权限：用户只能取消自己的订单，管理员可以取消任何订单
            Ticket ticket = ticketService.getTicketById(ticketId);
            if (ticket == null) {
                result.put("success", false);
                result.put("message", "订单不存在");
                writeJsonResponse(response, result);
                return;
            }
            
            if (user.getRole() != User.UserRole.ADMIN && !ticket.getVisitorId().equals(user.getId())) {
                result.put("success", false);
                result.put("message", "您只能取消自己的订单");
                writeJsonResponse(response, result);
                return;
            }
            
            boolean success = ticketService.cancelTicket(ticketId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "取消成功");
            } else {
                result.put("success", false);
                result.put("message", "取消失败，请检查票务状态");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "取消失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleRefundTicket(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 验证用户登录状态
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            
            if (user == null) {
                result.put("success", false);
                result.put("message", "请先登录");
                writeJsonResponse(response, result);
                return;
            }
            
            String ticketIdStr = request.getParameter("ticketId");
            if (ticketIdStr == null) {
                result.put("success", false);
                result.put("message", "票务ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long ticketId = Long.parseLong(ticketIdStr);
            
            // 验证权限：用户只能申请自己订单的退款，管理员可以处理任何退款
            Ticket ticket = ticketService.getTicketById(ticketId);
            if (ticket == null) {
                result.put("success", false);
                result.put("message", "订单不存在");
                writeJsonResponse(response, result);
                return;
            }
            
            if (user.getRole() != User.UserRole.ADMIN && !ticket.getVisitorId().equals(user.getId())) {
                result.put("success", false);
                result.put("message", "您只能申请自己订单的退款");
                writeJsonResponse(response, result);
                return;
            }
            
            boolean success = ticketService.refundTicket(ticketId);
            
            if (success) {
                result.put("success", true);
                result.put("message", user.getRole() == User.UserRole.ADMIN ? "退款处理成功" : "退款申请成功");
            } else {
                result.put("success", false);
                result.put("message", "退款失败，请检查票务状态");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "退款失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void writeJsonResponse(HttpServletResponse response, Map<String, Object> result) 
            throws IOException {
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(result));
        out.flush();
    }
}