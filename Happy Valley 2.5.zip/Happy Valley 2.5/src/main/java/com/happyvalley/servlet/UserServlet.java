package com.happyvalley.servlet;

import com.happyvalley.service.UserService;
import com.happyvalley.model.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/user/*")
public class UserServlet extends HttpServlet {
    
    private UserService userService = new UserService();
    private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/profile";
        }
        
        switch (pathInfo) {
            case "/profile":
                handleGetProfile(request, response);
                break;
            case "/list":
                handleGetUsers(request, response);
                break;
            case "/employees":
                handleGetEmployees(request, response);
                break;
            case "/visitors":
                handleGetVisitors(request, response);
                break;
            case "/search":
                handleSearchUsers(request, response);
                break;
            case "/statistics":
                handleGetUserStatistics(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/update-profile":
                handleUpdateProfile(request, response);
                break;
            case "/change-password":
                handleChangePassword(request, response);
                break;
            case "/create":
                handleCreateUser(request, response);
                break;
            case "/update-role":
                handleUpdateUserRole(request, response);
                break;
            case "/activate":
                handleActivateUser(request, response);
                break;
            case "/deactivate":
                handleDeactivateUser(request, response);
                break;
            case "/delete":
                handleDeleteUser(request, response);
                break;
            case "/reset-password":
                handleResetPassword(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void handleGetProfile(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        if (user == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            writeJsonResponse(response, result);
            return;
        }
        
        try {
            // 重新从数据库获取最新的用户信息
            User latestUser = userService.getUserById(user.getId());
            if (latestUser != null) {
                // 不返回密码信息
                latestUser.setPassword("");
                result.put("success", true);
                result.put("data", latestUser);
            } else {
                result.put("success", false);
                result.put("message", "用户信息不存在");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取用户信息失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetUsers(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String roleStr = request.getParameter("role");
            List<User> users;
            
            if (roleStr != null && !roleStr.isEmpty()) {
                User.UserRole role = User.UserRole.valueOf(roleStr.toUpperCase());
                users = userService.getUsersByRole(role);
            } else {
                users = userService.getAllUsers();
            }
            
            // 清除密码信息
            for (User user : users) {
                user.setPassword("");
            }
            
            result.put("success", true);
            result.put("data", users);
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取用户列表失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetEmployees(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            List<User> employees = userService.getUsersByRole(User.UserRole.EMPLOYEE);
            
            // 清除密码信息
            for (User user : employees) {
                user.setPassword("");
            }
            
            result.put("success", true);
            result.put("data", employees);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取员工列表失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetVisitors(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            List<User> visitors = userService.getUsersByRole(User.UserRole.VISITOR);
            
            // 清除密码信息
            for (User user : visitors) {
                user.setPassword("");
            }
            
            result.put("success", true);
            result.put("data", visitors);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取游客列表失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleSearchUsers(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String keyword = request.getParameter("keyword");
            if (keyword == null || keyword.trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "搜索关键词不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            List<User> users = userService.searchUsers(keyword.trim());
            
            // 清除密码信息
            for (User user : users) {
                user.setPassword("");
            }
            
            result.put("success", true);
            result.put("data", users);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "搜索用户失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetUserStatistics(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            Map<String, Object> statistics = new HashMap<>();
            
            statistics.put("totalUsers", userService.countUsersByRole(null));
            statistics.put("totalAdmins", userService.countUsersByRole(User.UserRole.ADMIN));
            statistics.put("totalEmployees", userService.countUsersByRole(User.UserRole.EMPLOYEE));
            statistics.put("totalVisitors", userService.countUsersByRole(User.UserRole.VISITOR));
            
            result.put("success", true);
            result.put("data", statistics);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取用户统计信息失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleUpdateProfile(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        if (currentUser == null) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "请先登录");
            writeJsonResponse(response, result);
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String realName = request.getParameter("realName");
            
            // 验证邮箱格式
            if (email != null && !email.trim().isEmpty() && !userService.isValidEmail(email)) {
                result.put("success", false);
                result.put("message", "邮箱格式不正确");
                writeJsonResponse(response, result);
                return;
            }
            
            // 验证手机号格式
            if (phone != null && !phone.trim().isEmpty() && !userService.isValidPhone(phone)) {
                result.put("success", false);
                result.put("message", "手机号格式不正确");
                writeJsonResponse(response, result);
                return;
            }
            
            // 检查邮箱是否已被其他用户使用
            if (email != null && !email.trim().isEmpty()) {
                User existingUser = userService.getUserByEmail(email);
                if (existingUser != null && !existingUser.getId().equals(currentUser.getId())) {
                    result.put("success", false);
                    result.put("message", "该邮箱已被其他用户使用");
                    writeJsonResponse(response, result);
                    return;
                }
            }
            
            boolean success = userService.updateUserProfile(currentUser.getId(), email, phone, realName);
            
            if (success) {
                // 更新session中的用户信息
                User updatedUser = userService.getUserById(currentUser.getId());
                if (updatedUser != null) {
                    session.setAttribute("user", updatedUser);
                }
                
                result.put("success", true);
                result.put("message", "个人信息更新成功");
            } else {
                result.put("success", false);
                result.put("message", "个人信息更新失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "个人信息更新失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleChangePassword(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        Map<String, Object> result = new HashMap<>();
        
        if (user == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            writeJsonResponse(response, result);
            return;
        }
        
        try {
            String currentPassword = request.getParameter("currentPassword");
            String newPassword = request.getParameter("newPassword");
            String confirmPassword = request.getParameter("confirmPassword");
            
            if (currentPassword == null || newPassword == null || confirmPassword == null) {
                result.put("success", false);
                result.put("message", "所有密码字段都不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            if (!newPassword.equals(confirmPassword)) {
                result.put("success", false);
                result.put("message", "新密码和确认密码不匹配");
                writeJsonResponse(response, result);
                return;
            }
            
            if (newPassword.length() < 6) {
                result.put("success", false);
                result.put("message", "新密码长度不能少于6位");
                writeJsonResponse(response, result);
                return;
            }
            
            boolean success = userService.changePassword(user.getId(), currentPassword, newPassword);
            
            if (success) {
                result.put("success", true);
                result.put("message", "密码修改成功");
            } else {
                result.put("success", false);
                result.put("message", "当前密码错误");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "密码修改失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleCreateUser(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            String realName = request.getParameter("realName");
            String phone = request.getParameter("phone");
            String roleStr = request.getParameter("role");
            String password = request.getParameter("password");
            
            // 验证必填字段
            if (username == null || username.trim().isEmpty() ||
                email == null || email.trim().isEmpty() ||
                realName == null || realName.trim().isEmpty() ||
                phone == null || phone.trim().isEmpty() ||
                roleStr == null || roleStr.trim().isEmpty() ||
                password == null || password.trim().isEmpty()) {
                
                result.put("success", false);
                result.put("message", "所有字段都不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            // 验证角色
            User.UserRole role;
            try {
                role = User.UserRole.valueOf(roleStr.toUpperCase());
            } catch (IllegalArgumentException e) {
                result.put("success", false);
                result.put("message", "无效的角色类型");
                writeJsonResponse(response, result);
                return;
            }
            
            // 验证密码长度
            if (password.length() < 6) {
                result.put("success", false);
                result.put("message", "密码长度不能少于6位");
                writeJsonResponse(response, result);
                return;
            }
            
            // 检查用户名是否已存在
            if (userService.getUserByUsername(username.trim()) != null) {
                result.put("success", false);
                result.put("message", "用户名已存在");
                writeJsonResponse(response, result);
                return;
            }
            
            // 检查邮箱是否已存在
            if (userService.getUserByEmail(email.trim()) != null) {
                result.put("success", false);
                result.put("message", "邮箱已被使用");
                writeJsonResponse(response, result);
                return;
            }
            
            // 使用registerUser方法创建用户
            boolean success = userService.registerUser(
                username.trim(), 
                password, 
                email.trim(), 
                phone.trim(), 
                realName.trim(), 
                role
            );
            
            if (success) {
                result.put("success", true);
                result.put("message", "员工创建成功");
            } else {
                result.put("success", false);
                result.put("message", "员工创建失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "员工创建失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleUpdateUserRole(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            String userIdStr = request.getParameter("userId");
            String roleStr = request.getParameter("role");
            
            if (userIdStr == null || roleStr == null) {
                result.put("success", false);
                result.put("message", "用户ID和角色不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long userId = Long.parseLong(userIdStr);
            User.UserRole role = User.UserRole.valueOf(roleStr.toUpperCase());
            
            boolean success = userService.updateUserRole(userId, role);
            
            if (success) {
                result.put("success", true);
                result.put("message", "用户角色更新成功");
            } else {
                result.put("success", false);
                result.put("message", "用户角色更新失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "用户角色更新失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleActivateUser(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String userIdStr = request.getParameter("userId");
            if (userIdStr == null) {
                result.put("success", false);
                result.put("message", "用户ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long userId = Long.parseLong(userIdStr);
            boolean success = userService.activateUser(userId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "用户激活成功");
            } else {
                result.put("success", false);
                result.put("message", "用户激活失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "用户激活失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleDeactivateUser(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String userIdStr = request.getParameter("userId");
            if (userIdStr == null) {
                result.put("success", false);
                result.put("message", "用户ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long userId = Long.parseLong(userIdStr);
            boolean success = userService.deactivateUser(userId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "用户禁用成功");
            } else {
                result.put("success", false);
                result.put("message", "用户禁用失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "用户禁用失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleDeleteUser(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String userIdStr = request.getParameter("userId");
            if (userIdStr == null) {
                result.put("success", false);
                result.put("message", "用户ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long userId = Long.parseLong(userIdStr);
            
            // 防止删除自己
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            if (currentUser != null && currentUser.getId().equals(userId)) {
                result.put("success", false);
                result.put("message", "不能删除自己的账号");
                writeJsonResponse(response, result);
                return;
            }
            
            boolean success = userService.deleteUser(userId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "用户删除成功");
            } else {
                result.put("success", false);
                result.put("message", "用户删除失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "用户删除失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleResetPassword(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String userIdStr = request.getParameter("userId");
            String newPassword = request.getParameter("newPassword");
            
            if (userIdStr == null) {
                result.put("success", false);
                result.put("message", "用户ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long userId = Long.parseLong(userIdStr);
            
            // 如果没有提供新密码，使用默认密码
            if (newPassword == null || newPassword.trim().isEmpty()) {
                newPassword = "123456"; // 默认密码
            }
            
            // 验证新密码格式
            if (!userService.isValidPassword(newPassword)) {
                result.put("success", false);
                result.put("message", "新密码格式不正确，密码长度应为6-20位");
                writeJsonResponse(response, result);
                return;
            }
            
            boolean success = userService.resetPassword(userId, newPassword);
            
            if (success) {
                result.put("success", true);
                result.put("message", "密码重置成功");
                result.put("newPassword", newPassword);
            } else {
                result.put("success", false);
                result.put("message", "密码重置失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "密码重置失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private boolean checkAdminPermission(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || user.getRole() != User.UserRole.ADMIN) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "权限不足，仅管理员可操作");
            writeJsonResponse(response, result);
            return false;
        }
        
        return true;
    }
    
    private void writeJsonResponse(HttpServletResponse response, Map<String, Object> result) 
            throws IOException {
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(result));
        out.flush();
    }
} 