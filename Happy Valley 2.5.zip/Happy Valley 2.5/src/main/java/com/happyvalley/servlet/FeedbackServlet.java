package com.happyvalley.servlet;

import com.happyvalley.service.FeedbackService;
import com.happyvalley.model.Feedback;
import com.happyvalley.model.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

@WebServlet("/feedback/*")
@MultipartConfig
public class FeedbackServlet extends HttpServlet {
    
    private FeedbackService feedbackService = new FeedbackService();
    private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 设置请求和响应的字符编码
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/list";
        }
        
        switch (pathInfo) {
            case "/list":
                handleGetFeedbacks(request, response);
                break;
            case "/detail":
                handleGetFeedbackDetail(request, response);
                break;
            case "/pending":
                handleGetPendingFeedbacks(request, response);
                break;
            case "/my-feedback":
                handleGetMyFeedbacks(request, response);
                break;
            case "/statistics":
                handleGetStatistics(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 设置请求和响应的字符编码
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/submit":
                handleSubmitFeedback(request, response);
                break;
            case "/reply":
                handleReplyFeedback(request, response);
                break;
            case "/update-status":
                handleUpdateStatus(request, response);
                break;
            case "/delete":
                handleDeleteFeedback(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void handleGetFeedbacks(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 检查用户权限
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || user.getRole() != User.UserRole.EMPLOYEE) {
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"success\": false, \"message\": \"权限不足，仅员工可操作\"}");
            return;
        }
        
        try {
            // 获取分页参数
            int page = 1;
            int pageSize = 10;
            try {
                String pageParam = request.getParameter("page");
                String pageSizeParam = request.getParameter("pageSize");
                if (pageParam != null) page = Integer.parseInt(pageParam);
                if (pageSizeParam != null) pageSize = Integer.parseInt(pageSizeParam);
            } catch (NumberFormatException e) {
                // 使用默认值
            }
            
            // 获取筛选参数
            String type = request.getParameter("type");
            String status = request.getParameter("status");
            String category = request.getParameter("category");
            String startDate = request.getParameter("startDate");
            String endDate = request.getParameter("endDate");
            String search = request.getParameter("search");
            
            List<Feedback> feedbacks = feedbackService.getFeedbacksWithPagination(
                page, pageSize, type, status, category, startDate, endDate, search);
            
            // 获取筛选条件下的总数
            int filteredTotal = feedbackService.getFilteredFeedbackCount(
                type, status, category, startDate, endDate, search);
            
            // 构建响应JSON
            StringBuilder json = new StringBuilder();
            json.append("{\"success\": true, \"data\": [");
            
            for (int i = 0; i < feedbacks.size(); i++) {
                if (i > 0) json.append(",");
                Feedback feedback = feedbacks.get(i);
                json.append("{");
                json.append("\"id\": ").append(feedback.getId()).append(",");
                json.append("\"username\": \"").append(escapeJson(feedback.getVisitorName())).append("\",");
                json.append("\"type\": \"").append(feedback.getType().name()).append("\",");
                json.append("\"title\": \"").append(escapeJson(feedback.getTitle())).append("\",");
                json.append("\"content\": \"").append(escapeJson(feedback.getContent())).append("\",");
                json.append("\"status\": \"").append(feedback.getStatus().name()).append("\",");
                json.append("\"rating\": ").append(feedback.getRating() != null ? feedback.getRating() : "null").append(",");
                json.append("\"category\": \"").append(feedback.getCategory() != null ? escapeJson(feedback.getCategory()) : "").append("\",");
                json.append("\"createTime\": \"").append(feedback.getCreateTime()).append("\",");
                json.append("\"reply\": \"").append(feedback.getReply() != null ? escapeJson(feedback.getReply()) : "").append("\",");
                json.append("\"replyByUserName\": \"").append(feedback.getReplyByUserName() != null ? escapeJson(feedback.getReplyByUserName()) : "").append("\"");
                json.append("}");
            }
            
            json.append("], \"total\": ").append(filteredTotal).append(", \"totalPages\": ").append((int) Math.ceil((double) filteredTotal / pageSize)).append(", \"currentPage\": ").append(page).append("}");
            
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(json.toString());
            
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"success\": false, \"message\": \"获取反馈列表失败\"}");
        }
    }
    
    private void handleGetFeedbackDetail(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String feedbackIdStr = request.getParameter("id");
            if (feedbackIdStr == null) {
                result.put("success", false);
                result.put("message", "反馈ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long feedbackId = Long.parseLong(feedbackIdStr);
            Feedback feedback = feedbackService.getFeedbackById(feedbackId);
            
            if (feedback != null) {
                result.put("success", true);
                result.put("data", feedback);
            } else {
                result.put("success", false);
                result.put("message", "反馈不存在");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取反馈详情失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetPendingFeedbacks(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查员工/管理员权限
        if (!checkEmployeePermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            List<Feedback> feedbacks = feedbackService.getPendingFeedback();
            result.put("success", true);
            result.put("data", feedbacks);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取待处理反馈失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetMyFeedbacks(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "请先登录");
            writeJsonResponse(response, result);
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            List<Feedback> feedbacks = feedbackService.getFeedbackByVisitor(user.getId());
            result.put("success", true);
            result.put("data", feedbacks);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取我的反馈失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleGetStatistics(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查员工/管理员权限
        if (!checkEmployeePermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            Map<String, Object> statistics = new HashMap<>();
            
            // 总数统计
            long totalCount = feedbackService.getTotalFeedbackCount();
            statistics.put("total", totalCount);
            
            // 按状态统计
            statistics.put("pending", feedbackService.countFeedbackByStatus(Feedback.FeedbackStatus.PENDING));
            statistics.put("processing", feedbackService.countFeedbackByStatus(Feedback.FeedbackStatus.PROCESSING));
            statistics.put("replied", feedbackService.countFeedbackByStatus(Feedback.FeedbackStatus.REPLIED));
            statistics.put("resolved", feedbackService.countFeedbackByStatus(Feedback.FeedbackStatus.RESOLVED));
            statistics.put("closed", feedbackService.countFeedbackByStatus(Feedback.FeedbackStatus.CLOSED));
            
            // 按类型统计
            statistics.put("suggestion", feedbackService.countFeedbackByType(Feedback.FeedbackType.SUGGESTION));
            statistics.put("complaint", feedbackService.countFeedbackByType(Feedback.FeedbackType.COMPLAINT));
            statistics.put("praise", feedbackService.countFeedbackByType(Feedback.FeedbackType.PRAISE));
            statistics.put("inquiry", feedbackService.countFeedbackByType(Feedback.FeedbackType.INQUIRY));
            statistics.put("other", feedbackService.countFeedbackByType(Feedback.FeedbackType.OTHER));
            
            // 平均评分
            statistics.put("averageRating", feedbackService.calculateAverageRating());
            
            result.put("success", true);
            result.put("data", statistics);
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "获取统计信息失败");
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleSubmitFeedback(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "请先登录");
            writeJsonResponse(response, result);
            return;
        }
        
        // 检查用户角色，只有游客可以提交反馈
        if (user.getRole() != User.UserRole.VISITOR) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "只有游客用户可以提交反馈建议");
            writeJsonResponse(response, result);
            return;
        }
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            String typeStr = request.getParameter("type");
            String title = request.getParameter("title");
            String content = request.getParameter("content");
            String ratingStr = request.getParameter("rating");
            String contact = request.getParameter("contact");
            String category = request.getParameter("category");
            
            // 调试信息：打印接收到的参数
            System.out.println("=== 反馈提交调试信息 ===");
            System.out.println("typeStr: [" + typeStr + "]");
            System.out.println("title: [" + title + "]");
            System.out.println("content: [" + content + "]");
            System.out.println("ratingStr: [" + ratingStr + "]");
            System.out.println("contact: [" + contact + "]");
            System.out.println("category: [" + category + "]");
            System.out.println("========================");
            
            // 验证必填字段
            if (typeStr == null || typeStr.trim().isEmpty() || 
                title == null || title.trim().isEmpty() ||
                content == null || content.trim().isEmpty()) {
                System.out.println("验证失败 - typeStr为空: " + (typeStr == null || typeStr.trim().isEmpty()));
                System.out.println("验证失败 - title为空: " + (title == null || title.trim().isEmpty()));
                System.out.println("验证失败 - content为空: " + (content == null || content.trim().isEmpty()));
                result.put("success", false);
                result.put("message", "请填写完整的反馈信息");
                writeJsonResponse(response, result);
                return;
            }
            
            Feedback.FeedbackType type = Feedback.FeedbackType.valueOf(typeStr.toUpperCase());
            Integer rating = ratingStr != null && !ratingStr.isEmpty() ? Integer.parseInt(ratingStr) : null;
            
            boolean success = feedbackService.submitFeedback(user.getId(), user.getRealName(), type,
                    title.trim(), content.trim(), rating, contact, category);
            
            if (success) {
                result.put("success", true);
                result.put("message", "反馈提交成功");
            } else {
                result.put("success", false);
                result.put("message", "反馈提交失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "反馈提交失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleReplyFeedback(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查员工/管理员权限
        if (!checkEmployeePermission(request, response)) {
            return;
        }
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        
        try {
            String feedbackIdStr = request.getParameter("feedbackId");
            String replyContent = request.getParameter("reply");
            String statusStr = request.getParameter("status");
            
            if (feedbackIdStr == null || replyContent == null || replyContent.trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "反馈ID和回复内容不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long feedbackId = Long.parseLong(feedbackIdStr);
            
            // 先回复反馈
            boolean replySuccess = feedbackService.replyFeedback(feedbackId, replyContent.trim(), 
                    user.getId(), user.getRealName());
            
            // 如果提供了状态参数，同时更新状态
            if (replySuccess && statusStr != null && !statusStr.isEmpty()) {
                Feedback.FeedbackStatus status = Feedback.FeedbackStatus.valueOf(statusStr.toUpperCase());
                feedbackService.updateFeedbackStatus(feedbackId, status);
            }
            
            if (replySuccess) {
                result.put("success", true);
                result.put("message", "回复成功");
            } else {
                result.put("success", false);
                result.put("message", "回复失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "回复失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleUpdateStatus(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查员工/管理员权限
        if (!checkEmployeePermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String feedbackIdStr = request.getParameter("feedbackId");
            String statusStr = request.getParameter("status");
            
            if (feedbackIdStr == null || statusStr == null) {
                result.put("success", false);
                result.put("message", "反馈ID和状态不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long feedbackId = Long.parseLong(feedbackIdStr);
            Feedback.FeedbackStatus status = Feedback.FeedbackStatus.valueOf(statusStr.toUpperCase());
            
            boolean success = feedbackService.updateFeedbackStatus(feedbackId, status);
            
            if (success) {
                result.put("success", true);
                result.put("message", "状态更新成功");
            } else {
                result.put("success", false);
                result.put("message", "状态更新失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "状态更新失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private void handleDeleteFeedback(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> result = new HashMap<>();
        
        try {
            String feedbackIdStr = request.getParameter("id");
            if (feedbackIdStr == null) {
                result.put("success", false);
                result.put("message", "反馈ID不能为空");
                writeJsonResponse(response, result);
                return;
            }
            
            Long feedbackId = Long.parseLong(feedbackIdStr);
            boolean success = feedbackService.deleteFeedback(feedbackId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "反馈删除成功");
            } else {
                result.put("success", false);
                result.put("message", "反馈删除失败");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "反馈删除失败：" + e.getMessage());
        }
        
        writeJsonResponse(response, result);
    }
    
    private boolean checkAdminPermission(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || user.getRole() != User.UserRole.ADMIN) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "权限不足，仅管理员可操作");
            writeJsonResponse(response, result);
            return false;
        }
        
        return true;
    }
    
    private boolean checkEmployeePermission(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || user.getRole() != User.UserRole.EMPLOYEE) {
            response.setContentType("application/json;charset=UTF-8");
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "权限不足，仅员工可操作");
            writeJsonResponse(response, result);
            return false;
        }
        
        return true;
    }
    
    // 转义JSON字符串中的特殊字符
    private String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
    
    private String getPartValue(HttpServletRequest request, String partName) throws Exception {
        try {
            Part part = request.getPart(partName);
            if (part == null) return null;
            
            try (InputStream inputStream = part.getInputStream();
                 Scanner scanner = new Scanner(inputStream, "UTF-8")) {
                scanner.useDelimiter("\\A"); // 读取整个输入流
                return scanner.hasNext() ? scanner.next().trim() : null;
            }
        } catch (Exception e) {
            System.out.println("获取Part " + partName + " 失败: " + e.getMessage());
            return null;
        }
    }
    
    private void writeJsonResponse(HttpServletResponse response, Map<String, Object> result) 
            throws IOException {
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(result));
        out.flush();
    }
}