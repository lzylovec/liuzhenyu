package com.happyvalley.test;

import com.happyvalley.util.DatabaseUtil;
import com.happyvalley.dao.UserDAO;
import com.happyvalley.model.User;

/**
 * 数据库连接测试类
 */
public class DatabaseTest {
    
    public static void main(String[] args) {
        System.out.println("=== 欢乐谷管理系统数据库连接测试 ===");
        
        // 1. 测试数据库连接
        System.out.println("\n1. 测试数据库连接:");
        DatabaseUtil.printConnectionInfo();
        
        // 2. 测试用户DAO
        System.out.println("\n2. 测试用户DAO:");
        UserDAO userDAO = new UserDAO();
        
        try {
            // 测试查找管理员用户
            User admin = userDAO.findByUsernameAndPassword("admin", "admin123");
            if (admin != null) {
                System.out.println("✓ 找到管理员用户: " + admin.getUsername() + " (" + admin.getRole() + ")");
            } else {
                System.out.println("✗ 未找到管理员用户，请检查数据库初始化");
            }
            
            // 测试查找员工用户
            User employee = userDAO.findByUsernameAndPassword("employee1", "emp123");
            if (employee != null) {
                System.out.println("✓ 找到员工用户: " + employee.getUsername() + " (" + employee.getRole() + ")");
            } else {
                System.out.println("✗ 未找到员工用户");
            }
            
            // 测试查找游客用户
            User visitor = userDAO.findByUsernameAndPassword("visitor1", "vis123");
            if (visitor != null) {
                System.out.println("✓ 找到游客用户: " + visitor.getUsername() + " (" + visitor.getRole() + ")");
            } else {
                System.out.println("✗ 未找到游客用户");
            }
            
        } catch (Exception e) {
            System.out.println("✗ 测试用户DAO时发生错误: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("\n=== 测试完成 ===");
        System.out.println("\n如果所有测试都通过，说明后端基础功能正常。");
        System.out.println("接下来可以:");
        System.out.println("1. 启动Web服务器 (如Tomcat)");
        System.out.println("2. 访问登录页面测试用户登录功能");
        System.out.println("3. 测试各个模块的功能");
        
        System.out.println("\n默认测试账号:");
        System.out.println("管理员: admin / admin123");
        System.out.println("员工: employee1 / emp123");
        System.out.println("游客: visitor1 / vis123");
    }
} 