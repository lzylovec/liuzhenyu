package com.happyvalley.service;

import com.happyvalley.dao.TicketDAO;
import com.happyvalley.model.Ticket;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.Calendar;
import java.util.Map;

/**
 * 票务业务服务类
 */
public class TicketService {
    
    private TicketDAO ticketDAO = new TicketDAO();
    
    // 每日每种票型的限量
    public static final int DAILY_TICKET_LIMIT = 100;
    
    /**
     * 检查指定日期和票型的库存是否足够
     */
    public boolean checkTicketAvailability(Ticket.TicketType ticketType, Date validDate, int requestedQuantity) {
        try {
            java.sql.Date sqlDate = new java.sql.Date(validDate.getTime());
            int soldCount = ticketDAO.countSoldTicketsByDateAndType(sqlDate, ticketType);
            int availableCount = DAILY_TICKET_LIMIT - soldCount;
            return availableCount >= requestedQuantity;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 获取指定日期和票型的剩余库存
     */
    public int getAvailableTicketCount(Ticket.TicketType ticketType, Date validDate) {
        try {
            java.sql.Date sqlDate = new java.sql.Date(validDate.getTime());
            int soldCount = ticketDAO.countSoldTicketsByDateAndType(sqlDate, ticketType);
            return Math.max(0, DAILY_TICKET_LIMIT - soldCount);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * 获取指定日期所有票型的库存信息
     */
    public Map<Ticket.TicketType, Integer> getTicketInventoryInfo(Date validDate) {
        try {
            java.sql.Date sqlDate = new java.sql.Date(validDate.getTime());
            Map<Ticket.TicketType, Integer> soldCounts = ticketDAO.getTicketInventoryByDate(sqlDate);
            Map<Ticket.TicketType, Integer> availableCounts = new java.util.HashMap<>();
            
            for (Ticket.TicketType type : Ticket.TicketType.values()) {
                int soldCount = soldCounts.getOrDefault(type, 0);
                int availableCount = Math.max(0, DAILY_TICKET_LIMIT - soldCount);
                availableCounts.put(type, availableCount);
            }
            
            return availableCounts;
        } catch (Exception e) {
            e.printStackTrace();
            return new java.util.HashMap<>();
        }
    }

    /**
     * 购买票务 - 添加库存检查
     */
    public String purchaseTicket(Ticket.TicketType ticketType, Date validDate, 
                                Long visitorId, String visitorName, String visitorPhone) {
        try {
            // 验证有效日期不能是过去的日期
            Calendar today = Calendar.getInstance();
            today.set(Calendar.HOUR_OF_DAY, 0);
            today.set(Calendar.MINUTE, 0);
            today.set(Calendar.SECOND, 0);
            today.set(Calendar.MILLISECOND, 0);
            
            if (validDate.before(today.getTime())) {
                return "不能购买过期票"; 
            }
            
            // 检查库存
            if (!checkTicketAvailability(ticketType, validDate, 1)) {
                return "该日期该票型库存不足，当日限量" + DAILY_TICKET_LIMIT + "张";
            }
            
            // 创建票务对象
            Ticket ticket = new Ticket(ticketType, validDate, visitorId, visitorName, visitorPhone);
            
            // 保存到数据库
            if (ticketDAO.save(ticket)) {
                return "购票成功，票号：" + ticket.getTicketNumber();
            } else {
                return "购票失败，请稍后重试";
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            return "购票失败：" + e.getMessage();
        }
    }
    
    /**
     * 批量购买票务 - 添加库存检查
     */
    public Map<String, Object> purchaseTickets(Ticket.TicketType ticketType, Date validDate, 
                                       Long visitorId, String visitorName, String visitorPhone, int quantity) {
        Map<String, Object> result = new java.util.HashMap<>();
        List<String> ticketNumbers = new ArrayList<>();
        
        try {
            // 验证有效日期不能是过去的日期
            Calendar today = Calendar.getInstance();
            today.set(Calendar.HOUR_OF_DAY, 0);
            today.set(Calendar.MINUTE, 0);
            today.set(Calendar.SECOND, 0);
            today.set(Calendar.MILLISECOND, 0);
            
            if (validDate.before(today.getTime())) {
                result.put("success", false);
                result.put("message", "不能购买过期票");
                result.put("ticketNumbers", ticketNumbers);
                return result;
            }
            
            // 检查库存是否足够
            if (!checkTicketAvailability(ticketType, validDate, quantity)) {
                int available = getAvailableTicketCount(ticketType, validDate);
                result.put("success", false);
                result.put("message", "库存不足，该日期该票型剩余 " + available + " 张，您申请购买 " + quantity + " 张");
                result.put("ticketNumbers", ticketNumbers);
                return result;
            }
            
            // 批量创建票务
            for (int i = 0; i < quantity; i++) {
                Ticket ticket = new Ticket(ticketType, validDate, visitorId, visitorName, visitorPhone);
                if (ticketDAO.save(ticket)) {
                    ticketNumbers.add(ticket.getTicketNumber());
                } else {
                    // 如果某张票保存失败，记录错误但继续处理其他票
                    break;
                }
            }
            
            if (ticketNumbers.size() == quantity) {
                result.put("success", true);
                result.put("message", "成功购买 " + quantity + " 张票");
            } else {
                result.put("success", false);
                result.put("message", "部分购买成功，成功购买 " + ticketNumbers.size() + " 张，预期 " + quantity + " 张");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", "购票失败：" + e.getMessage());
        }
        
        result.put("ticketNumbers", ticketNumbers);
        return result;
    }
    
    /**
     * 支付票务
     */
    public boolean payTicket(Long ticketId) {
        try {
            Ticket ticket = ticketDAO.findById(ticketId);
            if (ticket != null && ticket.getStatus() == Ticket.TicketStatus.PENDING) {
                return ticketDAO.updateStatus(ticketId, Ticket.TicketStatus.PAID);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 使用票务
     */
    public boolean useTicket(Long ticketId) {
        try {
            Ticket ticket = ticketDAO.findById(ticketId);
            if (ticket != null && ticket.getStatus() == Ticket.TicketStatus.PAID) {
                // 检查是否在有效期内
                Date today = new Date();
                if (!ticket.getValidDate().before(today)) {
                    return ticketDAO.updateStatus(ticketId, Ticket.TicketStatus.USED);
                }
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 取消票务
     */
    public boolean cancelTicket(Long ticketId) {
        try {
            Ticket ticket = ticketDAO.findById(ticketId);
            if (ticket != null && 
                (ticket.getStatus() == Ticket.TicketStatus.PENDING || 
                 ticket.getStatus() == Ticket.TicketStatus.PAID)) {
                return ticketDAO.updateStatus(ticketId, Ticket.TicketStatus.CANCELLED);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 退款票务
     */
    public boolean refundTicket(Long ticketId) {
        try {
            Ticket ticket = ticketDAO.findById(ticketId);
            if (ticket != null && ticket.getStatus() == Ticket.TicketStatus.PAID) {
                return ticketDAO.updateStatus(ticketId, Ticket.TicketStatus.REFUNDED);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 获取游客的所有票务
     */
    public List<Ticket> getVisitorTickets(Long visitorId) {
        return ticketDAO.findByVisitorId(visitorId);
    }
    
    /**
     * 获取所有票务（管理员功能）
     */
    public List<Ticket> getAllTickets() {
        return ticketDAO.findAll();
    }
    
    /**
     * 根据ID获取票务详情
     */
    public Ticket getTicketById(Long ticketId) {
        return ticketDAO.findById(ticketId);
    }
    
    /**
     * 检查过期票务并更新状态
     */
    public void checkAndUpdateExpiredTickets() {
        try {
            List<Ticket> allTickets = ticketDAO.findAll();
            Date today = new Date();
            
            for (Ticket ticket : allTickets) {
                if (ticket.getValidDate().before(today) && 
                    (ticket.getStatus() == Ticket.TicketStatus.PENDING || 
                     ticket.getStatus() == Ticket.TicketStatus.PAID)) {
                    ticketDAO.updateStatus(ticket.getId(), Ticket.TicketStatus.EXPIRED);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}