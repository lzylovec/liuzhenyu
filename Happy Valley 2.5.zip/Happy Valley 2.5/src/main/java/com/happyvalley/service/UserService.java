package com.happyvalley.service;

import com.happyvalley.dao.UserDAO;
import com.happyvalley.model.User;
import java.util.List;
import java.util.Date;

/**
 * 用户管理业务服务类
 */
public class UserService {
    
    private UserDAO userDAO = new UserDAO();
    
    /**
     * 用户登录验证
     */
    public User authenticate(String username, String password) {
        try {
            if (username == null || username.trim().isEmpty() ||
                password == null || password.trim().isEmpty()) {
                return null;
            }
            
            return userDAO.findByUsernameAndPassword(username.trim(), password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * 用户注册
     */
    public boolean registerUser(String username, String password, String email, 
                              String phone, String realName, User.UserRole role) {
        try {
            // 验证必填字段
            if (username == null || username.trim().isEmpty() ||
                password == null || password.trim().isEmpty() ||
                email == null || email.trim().isEmpty() ||
                realName == null || realName.trim().isEmpty()) {
                return false;
            }
            
            // 检查用户名是否已存在
            if (userDAO.findByUsername(username.trim()) != null) {
                return false; // 用户名已存在
            }
            
            User user = new User(username.trim(), password, email.trim(), role);
            user.setPhone(phone);
            user.setRealName(realName.trim());
            
            return userDAO.save(user);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 更新用户信息
     */
    public boolean updateUser(User user) {
        try {
            if (user == null || user.getId() == null) {
                return false;
            }
            
            user.setUpdateTime(new Date());
            return userDAO.update(user);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 更新用户密码
     */
    public boolean updatePassword(Long userId, String oldPassword, String newPassword) {
        try {
            User user = userDAO.findById(userId);
            if (user == null || !user.getPassword().equals(oldPassword)) {
                return false; // 用户不存在或旧密码错误
            }
            
            return userDAO.updatePassword(userId, newPassword);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 管理员重置用户密码
     */
    public boolean resetPassword(Long userId, String newPassword) {
        try {
            return userDAO.updatePassword(userId, newPassword);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 停用用户
     */
    public boolean deactivateUser(Long userId) {
        try {
            return userDAO.delete(userId); // 软删除
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 激活用户
     */
    public boolean activateUser(Long userId) {
        try {
            User user = userDAO.findById(userId);
            if (user != null) {
                user.setIsActive(true);
                user.setUpdateTime(new Date());
                return userDAO.update(user);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 获取所有用户
     */
    public List<User> getAllUsers() {
        return userDAO.findAll();
    }
    
    /**
     * 根据角色获取用户
     */
    public List<User> getUsersByRole(User.UserRole role) {
        return userDAO.findByRole(role);
    }
    
    /**
     * 根据ID获取用户
     */
    public User getUserById(Long userId) {
        return userDAO.findById(userId);
    }
    
    /**
     * 根据用户名获取用户
     */
    public User getUserByUsername(String username) {
        return userDAO.findByUsername(username);
    }
    
    /**
     * 获取所有员工
     */
    public List<User> getAllEmployees() {
        return userDAO.findByRole(User.UserRole.EMPLOYEE);
    }
    
    /**
     * 获取所有游客
     */
    public List<User> getAllVisitors() {
        return userDAO.findByRole(User.UserRole.VISITOR);
    }
    
    /**
     * 检查用户名是否可用
     */
    public boolean isUsernameAvailable(String username) {
        return !userDAO.existsByUsername(username);
    }
    
    /**
     * 验证用户权限
     */
    public boolean hasPermission(Long userId, User.UserRole requiredRole) {
        try {
            User user = userDAO.findById(userId);
            if (user == null || !user.getIsActive()) {
                return false;
            }
            
            // 管理员拥有所有权限
            if (user.getRole() == User.UserRole.ADMIN) {
                return true;
            }
            
            // 员工权限检查
            if (requiredRole == User.UserRole.EMPLOYEE) {
                return user.getRole() == User.UserRole.EMPLOYEE;
            }
            
            // 游客权限检查
            if (requiredRole == User.UserRole.VISITOR) {
                return user.getRole() == User.UserRole.VISITOR ||
                       user.getRole() == User.UserRole.EMPLOYEE ||
                       user.getRole() == User.UserRole.ADMIN;
            }
            
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 统计活跃用户数量
     */
    public long countActiveUsers() {
        List<User> allUsers = userDAO.findAll();
        return allUsers != null ? allUsers.size() : 0;
    }
    
    /**
     * 更新用户个人信息
     */
    public boolean updateProfile(Long userId, String email, String phone, String realName) {
        try {
            User user = userDAO.findById(userId);
            if (user != null) {
                user.setEmail(email);
                user.setPhone(phone);
                user.setRealName(realName);
                user.setUpdateTime(new Date());
                return userDAO.update(user);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 更新用户个人信息（别名方法）
     */
    public boolean updateUserProfile(Long userId, String email, String phone, String realName) {
        return updateProfile(userId, email, phone, realName);
    }
    
    /**
     * 修改密码
     */
    public boolean changePassword(Long userId, String oldPassword, String newPassword) {
        return updatePassword(userId, oldPassword, newPassword);
    }
    
    /**
     * 根据邮箱获取用户
     */
    public User getUserByEmail(String email) {
        return userDAO.findByEmail(email);
    }
    
    /**
     * 搜索用户（按用户名、真实姓名、邮箱）
     */
    public List<User> searchUsers(String keyword) {
        return userDAO.searchUsers(keyword);
    }
    
    /**
     * 更新用户角色
     */
    public boolean updateUserRole(Long userId, User.UserRole role) {
        try {
            User user = userDAO.findById(userId);
            if (user != null) {
                user.setRole(role);
                user.setUpdateTime(new Date());
                return userDAO.update(user);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 删除用户
     */
    public boolean deleteUser(Long userId) {
        try {
            return userDAO.delete(userId);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 统计所有用户数量（当role为null时）
     */
    public long countUsersByRole(User.UserRole role) {
        if (role == null) {
            List<User> allUsers = userDAO.findAll();
            return allUsers != null ? allUsers.size() : 0;
        }
        List<User> users = userDAO.findByRole(role);
        return users != null ? users.size() : 0;
    }
    
    /**
     * 验证邮箱格式
     */
    public boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }
    
    /**
     * 验证手机号格式
     */
    public boolean isValidPhone(String phone) {
        if (phone == null || phone.trim().isEmpty()) {
            return false;
        }
        String phoneRegex = "^1[3-9]\\d{9}$";
        return phone.matches(phoneRegex);
    }
    
    /**
     * 验证密码格式
     */
    public boolean isValidPassword(String password) {
        if (password == null) {
            return false;
        }
        return password.length() >= 6 && password.length() <= 20;
    }
} 