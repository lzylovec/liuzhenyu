package com.happyvalley.service;

import com.happyvalley.dao.AnimalDAO;
import com.happyvalley.model.Animal;
import java.util.List;
import java.util.Date;

/**
 * 动物管理业务服务类
 */
public class AnimalService {
    
    private AnimalDAO animalDAO = new AnimalDAO();
    
    /**
     * 添加新动物
     */
    public boolean addAnimal(String name, String species, Animal.AnimalCategory category,
                           String habitat, String description, String diet, String behavior,
                           String imageUrl, Integer age, String gender, String caretaker) {
        try {
            // 验证必填字段
            if (name == null || name.trim().isEmpty() ||
                species == null || species.trim().isEmpty()) {
                return false;
            }
            
            Animal animal = new Animal(name, species, category, habitat, description);
            animal.setDiet(diet);
            animal.setBehavior(behavior);
            animal.setImageUrl(imageUrl);
            animal.setAge(age);
            animal.setGender(gender);
            animal.setCaretaker(caretaker);
            
            return animalDAO.save(animal);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 更新动物信息
     */
    public boolean updateAnimal(Animal animal) {
        try {
            if (animal == null || animal.getId() == null) {
                return false;
            }
            
            animal.setUpdateTime(new Date());
            return animalDAO.update(animal);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 删除动物记录
     */
    public boolean deleteAnimal(Long animalId) {
        try {
            Animal animal = animalDAO.findById(animalId);
            if (animal != null) {
                return animalDAO.delete(animalId);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 获取所有动物
     */
    public List<Animal> getAllAnimals() {
        return animalDAO.findAll();
    }
    
    /**
     * 根据类别获取动物
     */
    public List<Animal> getAnimalsByCategory(Animal.AnimalCategory category) {
        return animalDAO.findByCategory(category);
    }
    
    /**
     * 根据健康状态获取动物
     */
    public List<Animal> getAnimalsByStatus(Animal.AnimalStatus status) {
        return animalDAO.findByStatus(status);
    }
    
    /**
     * 根据ID获取动物详情
     */
    public Animal getAnimalById(Long animalId) {
        return animalDAO.findById(animalId);
    }
    
    /**
     * 获取健康的动物（游客可见）
     */
    public List<Animal> getHealthyAnimals() {
        return animalDAO.findByStatus(Animal.AnimalStatus.HEALTHY);
    }
    
    /**
     * 更新动物健康状态
     */
    public boolean updateAnimalHealthStatus(Long animalId, Animal.AnimalStatus status, String healthDetail) {
        try {
            Animal animal = animalDAO.findById(animalId);
            if (animal != null) {
                animal.setStatus(status);
                animal.setHealthStatus(healthDetail);
                animal.setUpdateTime(new Date());
                return animalDAO.update(animal);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 分配饲养员
     */
    public boolean assignCaretaker(Long animalId, String caretakerName) {
        try {
            Animal animal = animalDAO.findById(animalId);
            if (animal != null) {
                animal.setCaretaker(caretakerName);
                animal.setUpdateTime(new Date());
                return animalDAO.update(animal);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 设置喂食时间
     */
    public boolean setFeedingTime(Long animalId, Date feedingTime) {
        try {
            Animal animal = animalDAO.findById(animalId);
            if (animal != null) {
                animal.setFeedingTime(feedingTime);
                animal.setUpdateTime(new Date());
                return animalDAO.update(animal);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 获取需要关注的动物（生病、康复中、隔离中）
     */
    public List<Animal> getAnimalsNeedingAttention() {
        try {
            List<Animal> sickAnimals = animalDAO.findByStatus(Animal.AnimalStatus.SICK);
            List<Animal> recoveringAnimals = animalDAO.findByStatus(Animal.AnimalStatus.RECOVERING);
            List<Animal> quarantineAnimals = animalDAO.findByStatus(Animal.AnimalStatus.QUARANTINE);
            
            sickAnimals.addAll(recoveringAnimals);
            sickAnimals.addAll(quarantineAnimals);
            
            return sickAnimals;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * 统计各类别动物数量
     */
    public long countAnimalsByCategory(Animal.AnimalCategory category) {
        List<Animal> animals = animalDAO.findByCategory(category);
        return animals != null ? animals.size() : 0;
    }
    
    /**
     * 统计健康动物数量
     */
    public long countHealthyAnimals() {
        List<Animal> animals = animalDAO.findByStatus(Animal.AnimalStatus.HEALTHY);
        return animals != null ? animals.size() : 0;
    }
} 