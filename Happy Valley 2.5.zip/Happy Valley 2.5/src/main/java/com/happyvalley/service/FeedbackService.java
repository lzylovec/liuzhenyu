package com.happyvalley.service;

import com.happyvalley.dao.FeedbackDAO;
import com.happyvalley.model.Feedback;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * 反馈业务服务类
 */
public class FeedbackService {
    
    private FeedbackDAO feedbackDAO = new FeedbackDAO();
    
    /**
     * 提交反馈
     */
    public boolean submitFeedback(Long visitorId, String visitorName, Feedback.FeedbackType type,
                                String title, String content, Integer rating, String contact, String category) {
        try {
            // 验证必填字段
            if (visitorName == null || visitorName.trim().isEmpty() ||
                title == null || title.trim().isEmpty() ||
                content == null || content.trim().isEmpty()) {
                return false;
            }
            
            // 验证评分范围
            if (rating != null && (rating < 1 || rating > 5)) {
                return false;
            }
            
            Feedback feedback = new Feedback(visitorId, visitorName, type, title, content);
            feedback.setRating(rating);
            feedback.setContact(contact);
            feedback.setCategory(category);
            
            return feedbackDAO.save(feedback);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 员工/管理员回复反馈
     */
    public boolean replyFeedback(Long feedbackId, String replyContent, Long replyUserId, String replyUserName) {
        try {
            if (replyContent == null || replyContent.trim().isEmpty()) {
                return false;
            }
            
            return feedbackDAO.addReply(feedbackId, replyContent, replyUserId, replyUserName);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 获取所有反馈（管理员/员工）
     */
    public List<Feedback> getAllFeedback() {
        return feedbackDAO.findAll();
    }
    
    /**
     * 根据游客ID获取反馈
     */
    public List<Feedback> getFeedbackByVisitor(Long visitorId) {
        return feedbackDAO.findByVisitorId(visitorId);
    }
    
    /**
     * 根据状态获取反馈
     */
    public List<Feedback> getFeedbackByStatus(Feedback.FeedbackStatus status) {
        return feedbackDAO.findByStatus(status);
    }
    
    /**
     * 根据类型获取反馈
     */
    public List<Feedback> getFeedbackByType(Feedback.FeedbackType type) {
        return feedbackDAO.findByType(type);
    }
    
    /**
     * 根据ID获取反馈详情
     */
    public Feedback getFeedbackById(Long feedbackId) {
        return feedbackDAO.findById(feedbackId);
    }
    
    /**
     * 获取待处理的反馈
     */
    public List<Feedback> getPendingFeedback() {
        return feedbackDAO.findByStatus(Feedback.FeedbackStatus.PENDING);
    }
    
    /**
     * 获取已处理的反馈
     */
    public List<Feedback> getProcessedFeedback() {
        return feedbackDAO.findByStatus(Feedback.FeedbackStatus.REPLIED);
    }
    
    /**
     * 更新反馈状态
     */
    public boolean updateFeedbackStatus(Long feedbackId, Feedback.FeedbackStatus status) {
        try {
            return feedbackDAO.updateStatus(feedbackId, status);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 标记反馈为处理中
     */
    public boolean markAsProcessing(Long feedbackId) {
        return updateFeedbackStatus(feedbackId, Feedback.FeedbackStatus.PROCESSING);
    }
    
    /**
     * 关闭反馈
     */
    public boolean closeFeedback(Long feedbackId) {
        return updateFeedbackStatus(feedbackId, Feedback.FeedbackStatus.CLOSED);
    }
    
    /**
     * 标记反馈为已解决
     */
    public boolean markAsResolved(Long feedbackId) {
        return updateFeedbackStatus(feedbackId, Feedback.FeedbackStatus.RESOLVED);
    }
    
    /**
     * 删除反馈
     */
    public boolean deleteFeedback(Long feedbackId) {
        try {
            Feedback feedback = feedbackDAO.findById(feedbackId);
            if (feedback != null) {
                return feedbackDAO.delete(feedbackId);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 统计反馈数量按状态
     */
    public long countFeedbackByStatus(Feedback.FeedbackStatus status) {
        List<Feedback> feedbacks = feedbackDAO.findByStatus(status);
        return feedbacks != null ? feedbacks.size() : 0;
    }
    
    /**
     * 统计反馈数量按类型
     */
    public long countFeedbackByType(Feedback.FeedbackType type) {
        List<Feedback> feedbacks = feedbackDAO.findByType(type);
        return feedbacks != null ? feedbacks.size() : 0;
    }
    
    /**
     * 计算平均评分
     */
    public double calculateAverageRating() {
        try {
            List<Feedback> allFeedback = feedbackDAO.findAll();
            if (allFeedback == null || allFeedback.isEmpty()) {
                return 0.0;
            }
            
            double totalRating = 0.0;
            int ratedCount = 0;
            
            for (Feedback feedback : allFeedback) {
                if (feedback.getRating() != null) {
                    totalRating += feedback.getRating();
                    ratedCount++;
                }
            }
            
            return ratedCount > 0 ? totalRating / ratedCount : 0.0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0.0;
        }
    }
    
    /**
     * 获取反馈总数
     */
    public int getTotalFeedbackCount() {
        return feedbackDAO.getTotalCount();
    }
    
    /**
     * 带筛选条件的分页查询
     */
    public List<Feedback> getFeedbacksWithPagination(int page, int pageSize, String type, 
                                                    String status, String category, 
                                                    String startDate, String endDate, String search) {
        return feedbackDAO.findWithPagination(page, pageSize, type, status, category, startDate, endDate, search);
    }
    
    /**
     * 获取筛选条件下的总数
     */
    public int getFilteredFeedbackCount(String type, String status, String category, 
                                      String startDate, String endDate, String search) {
        return feedbackDAO.getFilteredCount(type, status, category, startDate, endDate, search);
    }
    
    /**
     * 分页获取反馈列表（带筛选）
     */
    public Map<String, Object> getFeedbacksWithPagination(int page, int size, Map<String, Object> filters) {
        try {
            // 获取所有反馈
            List<Feedback> allFeedbacks = feedbackDAO.findAll();
            
            // 应用筛选条件
            List<Feedback> filteredFeedbacks = applyFilters(allFeedbacks, filters);
            
            // 计算分页
            int totalCount = filteredFeedbacks.size();
            int totalPages = (int) Math.ceil((double) totalCount / size);
            int startIndex = (page - 1) * size;
            int endIndex = Math.min(startIndex + size, totalCount);
            
            List<Feedback> pagedFeedbacks;
            if (startIndex < totalCount) {
                pagedFeedbacks = filteredFeedbacks.subList(startIndex, endIndex);
            } else {
                pagedFeedbacks = new java.util.ArrayList<>();
            }
            
            // 构建返回结果
            Map<String, Object> result = new HashMap<>();
            result.put("feedbacks", pagedFeedbacks);
            result.put("totalCount", totalCount);
            result.put("totalPages", totalPages);
            result.put("currentPage", page);
            result.put("pageSize", size);
            
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            Map<String, Object> result = new HashMap<>();
            result.put("feedbacks", new java.util.ArrayList<>());
            result.put("totalCount", 0);
            result.put("totalPages", 0);
            result.put("currentPage", page);
            result.put("pageSize", size);
            return result;
        }
    }
    
    /**
     * 应用筛选条件
     */
    private List<Feedback> applyFilters(List<Feedback> feedbacks, Map<String, Object> filters) {
        if (filters == null || filters.isEmpty()) {
            return feedbacks;
        }
        
        List<Feedback> filtered = new java.util.ArrayList<>();
        
        for (Feedback feedback : feedbacks) {
            boolean matches = true;
            
            // 类型筛选
            if (filters.containsKey("type")) {
                String typeFilter = (String) filters.get("type");
                if (!feedback.getType().name().equalsIgnoreCase(typeFilter)) {
                    matches = false;
                }
            }
            
            // 状态筛选
            if (matches && filters.containsKey("status")) {
                String statusFilter = (String) filters.get("status");
                if (!feedback.getStatus().name().equalsIgnoreCase(statusFilter)) {
                    matches = false;
                }
            }
            
            // 分类筛选
            if (matches && filters.containsKey("category")) {
                String categoryFilter = (String) filters.get("category");
                if (feedback.getCategory() == null || !feedback.getCategory().equals(categoryFilter)) {
                    matches = false;
                }
            }
            
            // 日期筛选
            if (matches && filters.containsKey("date")) {
                String dateFilter = (String) filters.get("date");
                if (feedback.getCreateTime() != null) {
                    String feedbackDate = feedback.getCreateTime().toString().substring(0, 10);
                    if (!feedbackDate.equals(dateFilter)) {
                        matches = false;
                    }
                }
            }
            
            // 搜索筛选（标题、内容、用户名）
            if (matches && filters.containsKey("search")) {
                String searchFilter = ((String) filters.get("search")).toLowerCase();
                boolean searchMatches = false;
                
                if (feedback.getTitle() != null && feedback.getTitle().toLowerCase().contains(searchFilter)) {
                    searchMatches = true;
                }
                if (!searchMatches && feedback.getContent() != null && feedback.getContent().toLowerCase().contains(searchFilter)) {
                    searchMatches = true;
                }
                if (!searchMatches && feedback.getVisitorName() != null && feedback.getVisitorName().toLowerCase().contains(searchFilter)) {
                    searchMatches = true;
                }
                
                if (!searchMatches) {
                    matches = false;
                }
            }
            
            if (matches) {
                filtered.add(feedback);
            }
        }
        
        return filtered;
    }
}