package com.happyvalley.service;

import com.happyvalley.dao.ActivityDAO;
import com.happyvalley.model.Activity;
import java.util.List;
import java.util.Date;

/**
 * 活动业务服务类
 */
public class ActivityService {
    
    private ActivityDAO activityDAO = new ActivityDAO();
    
    /**
     * 创建新活动
     */
    public boolean createActivity(String name, String description, Activity.ActivityType type,
                                String location, Date startTime, Date endTime, Integer capacity,
                                String requirements, String imageUrl) {
        try {
            // 验证输入参数
            if (name == null || name.trim().isEmpty()) {
                return false;
            }
            if (capacity == null || capacity <= 0) {
                return false;
            }
            if (endTime != null && startTime != null && endTime.before(startTime)) {
                return false; // 结束时间不能早于开始时间
            }
            
            Activity activity = new Activity(name, description, type, location, startTime, endTime, capacity);
            activity.setRequirements(requirements);
            activity.setImageUrl(imageUrl);
            
            return activityDAO.save(activity);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 更新活动信息
     */
    public boolean updateActivity(Activity activity) {
        try {
            if (activity == null || activity.getId() == null) {
                return false;
            }
            
            activity.setUpdateTime(new Date());
            return activityDAO.update(activity);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 删除活动
     */
    public boolean deleteActivity(Long activityId) {
        try {
            Activity activity = activityDAO.findById(activityId);
            if (activity != null) {
                return activityDAO.delete(activityId);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 获取所有活动
     */
    public List<Activity> getAllActivities() {
        return activityDAO.findAll();
    }
    
    /**
     * 根据状态获取活动
     */
    public List<Activity> getActivitiesByStatus(Activity.ActivityStatus status) {
        return activityDAO.findByStatus(status);
    }
    
    /**
     * 根据类型获取活动
     */
    public List<Activity> getActivitiesByType(Activity.ActivityType type) {
        return activityDAO.findByType(type);
    }
    
    /**
     * 根据ID获取活动详情
     */
    public Activity getActivityById(Long activityId) {
        return activityDAO.findById(activityId);
    }
    
    /**
     * 获取开放中的活动（游客可见）
     */
    public List<Activity> getActiveActivities() {
        return activityDAO.findByStatus(Activity.ActivityStatus.ACTIVE);
    }
    
    /**
     * 参与活动
     */
    public boolean participateActivity(Long activityId) {
        try {
            Activity activity = activityDAO.findById(activityId);
            if (activity != null && activity.addParticipant()) {
                return activityDAO.update(activity);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 取消参与活动
     */
    public boolean cancelParticipation(Long activityId) {
        try {
            Activity activity = activityDAO.findById(activityId);
            if (activity != null) {
                activity.removeParticipant();
                return activityDAO.update(activity);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 更改活动状态
     */
    public boolean changeActivityStatus(Long activityId, Activity.ActivityStatus newStatus) {
        try {
            Activity activity = activityDAO.findById(activityId);
            if (activity != null) {
                activity.setStatus(newStatus);
                activity.setUpdateTime(new Date());
                return activityDAO.update(activity);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 检查活动是否可以参与
     */
    public boolean canParticipate(Long activityId) {
        Activity activity = activityDAO.findById(activityId);
        return activity != null && activity.hasAvailableSpots();
    }
} 