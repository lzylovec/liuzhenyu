package com.happyvalley.filter;

import com.happyvalley.model.User;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * 权限验证过滤器
 * 验证用户登录状态和访问权限
 */
public class AuthenticationFilter implements Filter {

    // 不需要登录就能访问的路径
    private static final Set<String> PUBLIC_PATHS = new HashSet<>(Arrays.asList(
        "/login",
        "/register",
        "/logout",
        "/index.jsp",
        "/",
        "/assets",
        "/common",
        "/about",
        "/contact",
        "/privacy",
        "/terms"
    ));

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // 初始化操作
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        String requestURI = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();
        
        // 获取相对路径
        String path = requestURI.substring(contextPath.length());
        
        // 检查是否是公开路径
        if (isPublicPath(path)) {
            chain.doFilter(request, response);
            return;
        }
        
        // 检查是否需要验证
        HttpSession session = httpRequest.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            // 未登录，重定向到登录页面
            // 保存请求的URL，登录后可以重定向回来
            session = httpRequest.getSession(true);
            session.setAttribute("redirectUrl", requestURI);
            httpResponse.sendRedirect(contextPath + "/login");
            return;
        }
        
        User user = (User) session.getAttribute("user");
        
        // 检查角色权限
        if (!hasPermission(user, path)) {
            // 权限不足，返回403错误
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "权限不足");
            return;
        }
        
        // 继续过滤链
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // 清理资源
    }
    
    /**
     * 判断是否是公开路径
     */
    private boolean isPublicPath(String path) {
        // 检查是否是静态资源
        if (path.startsWith("/assets/") || 
            path.endsWith(".css") || 
            path.endsWith(".js") || 
            path.endsWith(".jpg") || 
            path.endsWith(".png") || 
            path.endsWith(".gif") || 
            path.endsWith(".ico")) {
            return true;
        }
        
        // 检查是否是公开页面
        for (String publicPath : PUBLIC_PATHS) {
            if (path.startsWith(publicPath)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 检查用户是否有访问指定路径的权限
     */
    private boolean hasPermission(User user, String path) {
        if (user == null) {
            return false;
        }
        
        User.UserRole role = user.getRole();
        
        // 管理员可以访问所有路径
        if (role == User.UserRole.ADMIN) {
            return true;
        }
        
        // 员工可以访问员工和访客路径
        if (role == User.UserRole.EMPLOYEE) {
            return !path.startsWith("/admin/");
        }
        
        // 访客只能访问访客路径
        if (role == User.UserRole.VISITOR) {
            // 用户个人中心相关路径
            if (path.startsWith("/user/")) {
                return true;
            }
            
            // 游客可访问的功能路径
            return path.startsWith("/visitor/") ||
                   path.startsWith("/activities") ||
                   path.startsWith("/animals") ||
                   path.startsWith("/tickets") ||
                   path.startsWith("/feedback");
        }
        
        return false;
    }
} 