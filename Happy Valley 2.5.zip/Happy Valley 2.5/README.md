# 欢乐谷管理系统

## 项目概述

这是一个基于Java Servlet + JDBC + JSP技术栈开发的欢乐谷主题公园管理系统。

## 系统功能

### 三种用户角色：
- **管理员**：管理购票订单、员工信息、动物信息、园区游乐活动
- **员工**：查看个人信息、注册登录、查看游客反馈建议与留言
- **游客**：购票、填写建议与留言、查看园区游乐活动、查看动物信息

## 技术栈

- **后端框架**：Java Servlet 4.0
- **数据库**：MySQL 8.0
- **数据访问**：JDBC
- **前端模板**：JSP + JSTL
- **JSON处理**：Gson
- **构建工具**：Maven
- **日志框架**：SLF4J + Logback
- **服务器**：Tomcat 9.0+

## 项目结构

```
src/
├── main/
│   ├── java/
│   │   └── com/happyvalley/
│   │       ├── dao/           # 数据访问层
│   │       ├── filter/        # 过滤器
│   │       ├── model/         # 实体类
│   │       ├── service/       # 业务逻辑层
│   │       ├── servlet/       # 控制器层
│   │       ├── test/          # 测试类
│   │       └── util/          # 工具类
│   ├── resources/
│   │   ├── database.properties    # 数据库配置
│   │   └── init-database.sql      # 数据库初始化脚本
│   └── webapp/
│       └── WEB-INF/
│           └── web.xml        # Web应用配置
└── test/                      # 测试代码
```

## 快速开始

### 1. 环境要求
- JDK 11+
- MySQL 8.0+
- Maven 3.6+
- Tomcat 9.0+

### 2. 数据库设置
```sql
-- 1. 创建数据库
CREATE DATABASE happy_valley DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 2. 执行初始化脚本
source src/main/resources/init-database.sql;
```

### 3. 配置数据库连接
修改 `src/main/resources/database.properties` 文件：
```properties
database.url=jdbc:mysql://localhost:3306/happy_valley?useSSL=false&serverTimezone=UTC&characterEncoding=utf8
database.username=root
database.password=your_password
```

### 4. 编译和运行
```bash
# 编译项目
mvn clean compile

# 测试数据库连接
mvn exec:java -Dexec.mainClass="com.happyvalley.test.DatabaseTest"

# 打包项目
mvn clean package

# 部署到Tomcat（将target/happy-valley-1.0.0.war复制到Tomcat的webapps目录）
```

### 5. 访问系统
- 访问地址：http://localhost:8080/happy-valley
- 默认账号：
  - 管理员：admin / admin123
  - 员工：employee1 / emp123  
  - 游客：visitor1 / vis123

## API接口说明

### 用户相关
- `POST /login` - 用户登录
- `POST /register` - 用户注册
- `GET /logout` - 退出登录

### 票务相关
- `GET /ticket/list` - 获取票务列表
- `POST /ticket/purchase` - 购买票务
- `POST /ticket/pay` - 支付票务
- `POST /ticket/cancel` - 取消票务

### 活动相关（需要实现）
- `GET /activity/list` - 获取活动列表
- `POST /activity/create` - 创建活动（管理员）

### 动物相关（需要实现）
- `GET /animal/list` - 获取动物列表
- `POST /animal/create` - 添加动物信息（管理员）

### 反馈相关（需要实现）
- `GET /feedback/list` - 获取反馈列表
- `POST /feedback/create` - 提交反馈
- `POST /feedback/reply` - 回复反馈（员工/管理员）

## 数据库表结构

### 用户表 (users)
- 存储用户基本信息和角色

### 票务表 (tickets)  
- 存储门票信息和购买记录

### 活动表 (activities)
- 存储园区游乐活动信息

### 动物表 (animals)
- 存储动物展示信息

### 反馈表 (feedback)
- 存储游客反馈和员工回复

## 开发状态

### ✅ 已完成
- [x] 项目基础架构搭建
- [x] 数据库设计和初始化脚本
- [x] 用户登录注册功能
- [x] 票务购买管理功能
- [x] 权限控制和过滤器
- [x] 基础DAO和Service层

### 🚧 待完成（前端部分）
- [ ] JSP页面开发
- [ ] 活动管理功能完善
- [ ] 动物信息管理功能完善  
- [ ] 反馈系统功能完善
- [ ] 前端页面美化
- [ ] 错误处理页面

## 注意事项

1. **数据库连接**：确保MySQL服务正在运行，且配置文件中的连接信息正确
2. **字符编码**：项目使用UTF-8编码，确保数据库也使用utf8mb4字符集
3. **权限控制**：系统实现了基于角色的访问控制，不同角色用户访问不同功能
4. **安全性**：生产环境中应该对密码进行加密存储，当前版本为明文存储仅供开发测试

## 故障排除

### 数据库连接失败
1. 检查MySQL服务是否启动
2. 验证数据库连接配置是否正确
3. 确认MySQL用户权限是否足够

### 编译错误
1. 检查JDK版本是否为11+
2. 确认Maven依赖是否下载完成
3. 验证项目结构是否正确

## 联系信息

如有问题，请查看项目文档或提交Issue。 