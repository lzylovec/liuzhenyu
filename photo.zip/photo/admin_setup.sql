-- 管理员系统数据库更新脚本
-- 为user表添加role字段
ALTER TABLE `user` ADD COLUMN `role` varchar(10) DEFAULT 'user' AFTER `sex`;

-- 更新现有用户的角色为普通用户
UPDATE `user` SET `role` = 'user' WHERE `role` IS NULL;

-- 插入默认管理员账户
INSERT INTO `user` (`uid`, `name`, `passwd`, `sex`, `role`, `rtime`) VALUES
(100, 'admin', 'admin123', 'man', 'admin', NOW());

-- 如果需要，可以将某个现有用户设置为管理员
-- UPDATE `user` SET `role` = 'admin' WHERE `name` = 'user1'; 