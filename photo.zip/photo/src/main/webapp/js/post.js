function input_show() {
  if(document.getElementById("ci").style.display == "none") {
    document.getElementById("ci").style.display = "block";
  }else{
    document.getElementById("ci").style.display = "none";
  }
}