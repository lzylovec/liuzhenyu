package com.util;

import javax.servlet.http.Part;
import javax.servlet.ServletContext;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * 文件上传工具类
 * 支持图片上传到webapp/uploads目录
 */
public class FileUploadUtil {
    
    // 上传目录 - 使用webapp目录下的uploads
    private static final String UPLOAD_DIR = "uploads";
    
    // 允许的图片文件类型
    private static final String[] ALLOWED_IMAGE_TYPES = {
        "image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp"
    };
    
    // 允许的文件扩展名
    private static final String[] ALLOWED_EXTENSIONS = {
        ".jpg", ".jpeg", ".png", ".gif", ".webp"
    };
    
    // 最大文件大小 (5MB)
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024;
    
    /**
     * 获取项目源码目录下的uploads路径
     */
    private static String getSourceUploadsPath() {
        // 直接使用项目的绝对路径
        String projectRoot = "/Users/duanxukang/code/2025课设/new/photo";
        String uploadsPath = projectRoot + File.separator + "src" + File.separator + "main" + 
                           File.separator + "webapp" + File.separator + UPLOAD_DIR;
        
        // 添加调试信息
        System.out.println("=== FileUploadUtil Debug Info ===");
        System.out.println("Project root: " + projectRoot);
        System.out.println("Target uploads path: " + uploadsPath);
        System.out.println("Directory exists: " + new File(uploadsPath).exists());
        
        return uploadsPath;
    }
    
    /**
     * 初始化上传目录
     */
    public static void initUploadDirectory() {
        try {
            String uploadPath = getSourceUploadsPath();
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                boolean created = uploadDir.mkdirs();
                System.out.println("创建上传目录: " + uploadPath + " - 结果: " + created);
            } else {
                System.out.println("上传目录已存在: " + uploadPath);
            }
        } catch (Exception e) {
            System.err.println("初始化上传目录失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 上传多个图片文件
     */
    public static List<String> uploadImages(Collection<Part> imageParts) throws IOException {
        List<String> uploadedFiles = new ArrayList<>();
        
        // 初始化上传目录
        initUploadDirectory();
        
        for (Part part : imageParts) {
            if (part != null && part.getSize() > 0) {
                String fileName = uploadImage(part);
                if (fileName != null) {
                    uploadedFiles.add(fileName);
                }
            }
        }
        
        return uploadedFiles;
    }
    
    /**
     * 上传单个图片文件
     */
    public static String uploadImage(Part imagePart) throws IOException {
        if (imagePart == null || imagePart.getSize() == 0) {
            return null;
        }
        
        // 验证文件类型
        String contentType = imagePart.getContentType();
        if (!isValidImageType(contentType)) {
            throw new IOException("不支持的文件类型: " + contentType);
        }
        
        // 验证文件大小
        if (imagePart.getSize() > MAX_FILE_SIZE) {
            throw new IOException("文件大小超过限制: " + imagePart.getSize() + " bytes");
        }
        
        // 获取原始文件名
        String originalFileName = getFileName(imagePart);
        if (originalFileName == null || originalFileName.trim().isEmpty()) {
            throw new IOException("无效的文件名");
        }
        
        // 验证文件扩展名
        if (!isValidExtension(originalFileName)) {
            throw new IOException("不支持的文件扩展名");
        }
        
        // 生成唯一文件名
        String fileExtension = getFileExtension(originalFileName);
        String uniqueFileName = UUID.randomUUID().toString() + fileExtension;
        
        // 构建保存路径
        String uploadPath = getSourceUploadsPath();
        Path filePath = Paths.get(uploadPath, uniqueFileName);
        
        System.out.println("=== File Upload Process ===");
        System.out.println("Original filename: " + originalFileName);
        System.out.println("Generated unique filename: " + uniqueFileName);
        System.out.println("Upload path: " + uploadPath);
        System.out.println("Full file path: " + filePath.toString());
        System.out.println("File size: " + imagePart.getSize() + " bytes");
        
        // 保存文件
        try (InputStream inputStream = imagePart.getInputStream()) {
            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("文件保存成功: " + filePath);
            
            // 验证文件是否真的保存了
            File savedFile = new File(filePath.toString());
            System.out.println("文件验证 - 存在: " + savedFile.exists() + ", 大小: " + savedFile.length());
        }
        
        // 返回相对路径
        String relativePath = UPLOAD_DIR + "/" + uniqueFileName;
        System.out.println("返回相对路径: " + relativePath);
        return relativePath;
    }
    
    /**
     * 删除图片文件
     */
    public static boolean deleteImage(String imagePath) {
        try {
            if (imagePath == null || imagePath.trim().isEmpty()) {
                return false;
            }
            
            // 构建完整路径
            String uploadPath = getSourceUploadsPath();
            String fileName = imagePath.substring(imagePath.lastIndexOf("/") + 1);
            String fullPath = uploadPath + File.separator + fileName;
            File file = new File(fullPath);
            
            if (file.exists() && file.isFile()) {
                return file.delete();
            }
            
            return false;
        } catch (Exception e) {
            System.err.println("删除文件失败: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 删除多个图片文件
     */
    public static void deleteImages(List<String> imagePaths) {
        for (String imagePath : imagePaths) {
            deleteImage(imagePath);
        }
    }
    
    /**
     * 验证是否为允许的图片类型
     */
    private static boolean isValidImageType(String contentType) {
        if (contentType == null) {
            return false;
        }
        
        for (String allowedType : ALLOWED_IMAGE_TYPES) {
            if (contentType.toLowerCase().contains(allowedType)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 验证文件扩展名
     */
    private static boolean isValidExtension(String fileName) {
        if (fileName == null) {
            return false;
        }
        
        String lowerFileName = fileName.toLowerCase();
        for (String extension : ALLOWED_EXTENSIONS) {
            if (lowerFileName.endsWith(extension)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 获取文件名
     */
    private static String getFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        if (contentDisposition != null) {
            for (String content : contentDisposition.split(";")) {
                if (content.trim().startsWith("filename")) {
                    String fileName = content.substring(content.indexOf('=') + 1).trim();
                    // 移除引号
                    return fileName.replace("\"", "");
                }
            }
        }
        return null;
    }
    
    /**
     * 获取文件扩展名
     */
    private static String getFileExtension(String fileName) {
        if (fileName == null || fileName.lastIndexOf('.') == -1) {
            return "";
        }
        return fileName.substring(fileName.lastIndexOf('.'));
    }
    
    /**
     * 格式化文件大小
     */
    public static String formatFileSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        } else {
            return String.format("%.1f MB", size / (1024.0 * 1024.0));
        }
    }
    
    /**
     * 检查文件是否存在
     */
    public static boolean fileExists(String imagePath) {
        try {
            if (imagePath == null || imagePath.trim().isEmpty()) {
                return false;
            }
            
            String uploadPath = getSourceUploadsPath();
            String fileName = imagePath.substring(imagePath.lastIndexOf("/") + 1);
            String fullPath = uploadPath + File.separator + fileName;
            File file = new File(fullPath);
            
            return file.exists() && file.isFile();
        } catch (Exception e) {
            return false;
        }
    }
} 