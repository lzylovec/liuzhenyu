package com.service;

import com.bean.User;
import com.dao.IUserDAO;
import com.db.DBConn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO implements IUserDAO {
  protected static final String FIELDS_INSERT = "uid, name, passwd, sex, role, rtime";
  protected static String INSERT_SQL = "insert into user (" + FIELDS_INSERT+ ")" +"values(0,?,?,?,?,NOW())";
  protected static String SELECT_SQL = "select " + FIELDS_INSERT + " from user where uid=?";
  protected static String SELECT_SQL2 = "select " + FIELDS_INSERT + " from user where name=?";
  protected static String UPDATE_SQL = "update user set" + " name=?,passwd=?,sex=?,role=? where uid=?";
  protected static String DELETE_SQL = "delete from user where uid=?";


  @Override
  public void create(User user) throws Exception {
    Connection conn;
    PreparedStatement pstm;
    conn = DBConn.getDBconnection();

    assert conn != null;
    pstm = conn.prepareStatement(INSERT_SQL);
      pstm.setString(1, user.getName());
      pstm.setString(2,user.getPasswd());
      pstm.setString(3,user.getSex());
      pstm.setString(4, user.getRole() != null ? user.getRole() : "user");
      pstm.executeUpdate();

    DBConn.closeDB(conn,pstm,null);
  }

  @Override
  public void remove(User user) throws Exception {
    Connection conn;
    PreparedStatement pstm;
    conn = DBConn.getDBconnection();
    assert conn != null;
    pstm = conn.prepareStatement(DELETE_SQL);
      pstm.setInt(1,user.getUid());
      pstm.executeUpdate();
      DBConn.closeDB(conn,pstm,null);
  }

  @Override
  public User findById(User user) throws Exception {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    User user2 = null;
    conn = DBConn.getDBconnection();
    assert conn != null;
    pstm = conn.prepareStatement(SELECT_SQL);
    pstm.setInt(1,user.getUid());
    rs = pstm.executeQuery();
    if (rs.next()){
      user2 = new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getDate(6));
    }
    DBConn.closeDB(conn,pstm,rs);
    return user2;
  }

  @Override
  public User findByName(User user) throws Exception {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    User user2 = null;
    conn = DBConn.getDBconnection();
    assert conn != null;
    pstm = conn.prepareStatement(SELECT_SQL2);
      pstm.setString(1,user.getName());
      rs = pstm.executeQuery();
      if (rs.next()){
        user2 = new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getDate(6));
      }
    DBConn.closeDB(conn,pstm,rs);
    return user2;
  }

  @Override
  public List<User> findAll() throws Exception {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    List<User> user = new ArrayList<>();
    conn = DBConn.getDBconnection();
    assert conn != null;
    pstm = conn.prepareStatement("select uid, name, passwd, sex, role, rtime from user ORDER BY rtime DESC");
      rs = pstm.executeQuery();
      while (rs.next()){
        User user1 = new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getDate(6));
        user.add(user1);
      }
    DBConn.closeDB(conn,pstm,rs);
    return user;
  }

  @Override
  public void update(User user) throws Exception {
    Connection conn;
    PreparedStatement pstm;
    conn = DBConn.getDBconnection();
    assert conn != null;
    pstm = conn.prepareStatement(UPDATE_SQL);
    pstm.setString(1,user.getName());
    pstm.setString(2,user.getPasswd());
    pstm.setString(3,user.getSex());
    pstm.setString(4,user.getRole());
    pstm.setInt(5,user.getUid());
      int rowCount = pstm.executeUpdate();
      if (rowCount == 0) {
        throw new SQLException("Update Error:User uid:" + user.getUid());
      }
    DBConn.closeDB(conn,pstm,null);
  }

  @Override
  public int check(User user) throws Exception{
    Connection conn = null;
    PreparedStatement pstm = null;
    ResultSet rs = null;
    
    try {
      conn = DBConn.getDBconnection();
      if (conn == null) {
        throw new Exception("数据库连接失败");
      }
      
      pstm = conn.prepareStatement("select name, passwd, role from user where name=?");
      pstm.setString(1, user.getName());
      rs = pstm.executeQuery();
      
      if (rs.next()) {
        // 用户存在，检查密码
        String dbUsername = rs.getString("name");
        String dbPassword = rs.getString("passwd");
        String dbRole = rs.getString("role");
        
        if (user.getPasswd().equals(dbPassword)) {
          // 设置用户角色信息
          user.setRole(dbRole);
          return 1; // 用户名和密码都正确
        } else {
          return 0; // 密码不正确
        }
      } else {
        return -1; // 用户名不存在
      }
    } finally {
      DBConn.closeDB(conn, pstm, rs);
    }
  }

  public boolean check(String name) throws Exception {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    conn = DBConn.getDBconnection();
    assert conn != null;
    pstm = conn.prepareStatement("select name from user where name=?");
    pstm.setString(1,name);
    rs = pstm.executeQuery();
    User user1 = new User();
    if (rs.next()){
      user1.setName(rs.getString(1));
    }
    return !name.equals(user1.getName()); // 用户名存在返回false
  }

  // 管理员专用方法
  public List<User> findAllUsers() throws Exception {
    return findAll();
  }

  public void deleteUserById(int uid) throws Exception {
    Connection conn = null;
    PreparedStatement pstm = null;
    
    try {
      conn = DBConn.getDBconnection();
      assert conn != null;
      pstm = conn.prepareStatement("DELETE FROM user WHERE uid = ?");
      pstm.setInt(1, uid);
      pstm.executeUpdate();
    } finally {
      DBConn.closeDB(conn, pstm, null);
    }
  }

  public void updateUserRole(int uid, String role) throws Exception {
    Connection conn = null;
    PreparedStatement pstm = null;
    
    try {
      conn = DBConn.getDBconnection();
      assert conn != null;
      pstm = conn.prepareStatement("UPDATE user SET role = ? WHERE uid = ?");
      pstm.setString(1, role);
      pstm.setInt(2, uid);
      pstm.executeUpdate();
    } finally {
      DBConn.closeDB(conn, pstm, null);
    }
  }

  public void updateWithoutPassword(User user) throws Exception {
    Connection conn = null;
    PreparedStatement pstm = null;
    
    try {
      conn = DBConn.getDBconnection();
      assert conn != null;
      pstm = conn.prepareStatement("UPDATE user SET name = ?, sex = ?, role = ? WHERE uid = ?");
      pstm.setString(1, user.getName());
      pstm.setString(2, user.getSex());
      pstm.setString(3, user.getRole());
      pstm.setInt(4, user.getUid());
      int rowCount = pstm.executeUpdate();
      if (rowCount == 0) {
        throw new SQLException("Update Error: User uid:" + user.getUid());
      }
    } finally {
      DBConn.closeDB(conn, pstm, null);
    }
  }
}
