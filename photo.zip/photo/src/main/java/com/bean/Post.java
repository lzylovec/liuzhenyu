package com.bean;

import java.util.List;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

public class Post {
  private int id;
  private String title;
  private String author;
  private String type;
  private String content;
  private java.sql.Date date;
  private String images; // JSON字符串形式存储图片路径列表
  
  // Gson实例用于JSON转换
  private static final Gson gson = new Gson();
  private static final Type listType = new TypeToken<List<String>>(){}.getType();

  public Post() {}

  public Post(
      int id, String title, String author, String type, String content, java.sql.Date date) {
    this.id = id;
    this.title = title;
    this.author = author;
    this.type = type;
    this.content = content;
    this.date = date;
    this.images = "[]"; // 默认空数组
  }

  public Post(
      int id, String title, String author, String type, String content, java.sql.Date date, String images) {
    this.id = id;
    this.title = title;
    this.author = author;
    this.type = type;
    this.content = content;
    this.date = date;
    this.images = images != null ? images : "[]";
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public java.sql.Date getDate() {
    return date;
  }

  public void setDate(java.sql.Date date) {
    this.date = date;
  }

  public String getImages() {
    return images;
  }

  public void setImages(String images) {
    this.images = images != null ? images : "[]";
  }

  // 获取图片列表（将JSON字符串转换为List）
  public List<String> getImageList() {
    if (images == null || images.trim().isEmpty()) {
      return new ArrayList<>();
    }
    try {
      return gson.fromJson(images, listType);
    } catch (Exception e) {
      return new ArrayList<>();
    }
  }

  // 设置图片列表（将List转换为JSON字符串）
  public void setImageList(List<String> imageList) {
    if (imageList == null) {
      this.images = "[]";
    } else {
      this.images = gson.toJson(imageList);
    }
  }

  // 添加单张图片
  public void addImage(String imagePath) {
    List<String> imageList = getImageList();
    if (!imageList.contains(imagePath)) {
      imageList.add(imagePath);
      setImageList(imageList);
    }
  }

  // 移除单张图片
  public void removeImage(String imagePath) {
    List<String> imageList = getImageList();
    imageList.remove(imagePath);
    setImageList(imageList);
  }

  // 检查是否有图片
  public boolean hasImages() {
    List<String> imageList = getImageList();
    return !imageList.isEmpty();
  }

  // 获取图片数量
  public int getImageCount() {
    return getImageList().size();
  }

  @Override
  public String toString() {
    return "Post{"
        + "id="
        + id
        + ", title='"
        + title
        + '\''
        + ", author='"
        + author
        + '\''
        + ", type='"
        + type
        + '\''
        + ", content='"
        + content
        + '\''
        + ", date='"
        + date
        + '\''
        + ", images='"
        + images
        + '\''
        + '}';
  }
}
