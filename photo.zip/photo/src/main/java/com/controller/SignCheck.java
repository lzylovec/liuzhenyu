package com.controller;

import com.bean.User;
import com.dao.IUserDAO;
import com.service.UserDAO;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SignCheck")
public class SignCheck extends HttpServlet {

  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
    
    // 设置字符编码
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html;charset=UTF-8");
    
    String username = request.getParameter("username");
    String userpwd = request.getParameter("userpwd");
    String reuserpwd = request.getParameter("reuserpwd");
    
    // 输入验证
    if (username == null || username.trim().isEmpty()) {
      request.setAttribute("outputMessage", "用户名不能为空");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
      return;
    }
    
    if (userpwd == null || userpwd.trim().isEmpty()) {
      request.setAttribute("outputMessage", "密码不能为空");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
      return;
    }
    
    if (reuserpwd == null || reuserpwd.trim().isEmpty()) {
      request.setAttribute("outputMessage", "请确认密码");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
      return;
    }
    
    // 用户名长度验证
    if (username.trim().length() < 3 || username.trim().length() > 20) {
      request.setAttribute("outputMessage", "用户名长度必须在3-20个字符之间");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
      return;
    }
    
    // 密码长度验证
    if (userpwd.length() < 6 || userpwd.length() > 20) {
      request.setAttribute("outputMessage", "密码长度必须在6-20个字符之间");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
      return;
    }
    
    // 密码一致性验证
    if (!userpwd.equals(reuserpwd)) {
      request.setAttribute("outputMessage", "两次输入的密码不一致，请重新输入");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
      return;
    }
    
    IUserDAO iUserDAO = new UserDAO();
    
    try {
      // 检查用户名是否已存在（注意：UserDAO的check方法返回true表示用户名可用）
      if (!iUserDAO.check(username.trim())) {
        request.setAttribute("outputMessage", "用户名已存在，请选择其他用户名");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
        dispatcher.forward(request, response);
        return;
      }
      
      // 创建新用户
      User user = new User();
      user.setName(username.trim());
      user.setPasswd(userpwd);
      user.setSex("man"); // 默认值，可以后续添加性别选择
      
      iUserDAO.create(user);
      
      // 注册成功
      request.setAttribute("outputMessage", "注册成功！欢迎加入摄影分享论坛");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
      
    } catch (Exception e) {
      e.printStackTrace();
      request.setAttribute("outputMessage", "系统错误，注册失败，请稍后重试");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
    }
  }

  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
    doPost(request, response);
  }
}

