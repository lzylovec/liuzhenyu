package com.controller;

import com.bean.Post;
import com.dao.IPostDAO;
import com.service.PostDAO;
import com.util.FileUploadUtil;
import java.io.IOException;
import java.util.List;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/PostWrite")
@MultipartConfig(
    maxFileSize = 5 * 1024 * 1024, // 5MB
    maxRequestSize = 50 * 1024 * 1024, // 50MB
    fileSizeThreshold = 1024 * 1024 // 1MB
)
public class PostWrite extends HttpServlet {
  
  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
    request.setCharacterEncoding("UTF-8");
    
    System.out.println("=== PostWrite开始处理请求 ===");
    
    String title = request.getParameter("title");
    HttpSession session = request.getSession();
    String author = (String) session.getAttribute("username_session");
    String type = request.getParameter("ntype");
    String content = request.getParameter("content");

    System.out.println("表单参数 - 标题: " + title + ", 作者: " + author + ", 类型: " + type);

    // 处理图片上传
    List<String> uploadedImages = null;
    try {
      System.out.println("开始处理图片上传...");
      Collection<Part> imageParts = request.getParts();
      System.out.println("获取到的Parts数量: " + imageParts.size());
      
      // 过滤出图片文件
      Collection<Part> imageFiles = new java.util.ArrayList<>();
      for (Part part : imageParts) {
        System.out.println("Part名称: " + part.getName() + ", 大小: " + part.getSize() + ", ContentType: " + part.getContentType());
        if ("images".equals(part.getName()) && part.getSize() > 0) {
          imageFiles.add(part);
          System.out.println("找到有效图片文件: " + part.getName());
        }
      }
      
      System.out.println("有效图片文件数量: " + imageFiles.size());
      
      // 上传图片
      if (!imageFiles.isEmpty()) {
        System.out.println("开始上传图片文件...");
        uploadedImages = FileUploadUtil.uploadImages(imageFiles);
        System.out.println("上传完成，成功上传: " + (uploadedImages != null ? uploadedImages.size() : 0) + " 个文件");
        if (uploadedImages != null) {
          for (String path : uploadedImages) {
            System.out.println("上传的文件路径: " + path);
          }
        }
      } else {
        System.out.println("没有有效的图片文件需要上传");
      }
    } catch (Exception e) {
      System.err.println("图片上传失败:");
      e.printStackTrace();
      String info = "图片上传失败: " + e.getMessage();
      request.setAttribute("outputMessage", info);
      response.sendRedirect("info.jsp");
      return;
    }

    // 创建帖子对象
    Post post = new Post();
    post.setTitle(title);
    post.setAuthor(author);
    post.setType(type);
    post.setContent(content);
    
    // 设置图片列表
    if (uploadedImages != null && !uploadedImages.isEmpty()) {
      post.setImageList(uploadedImages);
      System.out.println("设置帖子图片列表: " + post.getImages());
    } else {
      System.out.println("帖子没有图片");
    }

    IPostDAO iPostDAO = new PostDAO();
    try {
      System.out.println("开始保存帖子到数据库...");
      iPostDAO.create(post);
      post = iPostDAO.findByTitle(post);
      System.out.println("帖子保存成功，ID: " + post.getId());
      response
          .getWriter()
          .print(
              "<script type=\"text/javascript\">\n"
                  + "window.location.href='post.jsp?id="+post.getId()+"'\n"
                  + "</script>");
    } catch (Exception e) {
      System.err.println("数据库操作失败:");
      e.printStackTrace();
      String info = "文章录入失败: " + e.getMessage();
      request.setAttribute("outputMessage", info);
      response.sendRedirect("info.jsp");
    }
  }

  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
    doPost(request, response);
  }
}
