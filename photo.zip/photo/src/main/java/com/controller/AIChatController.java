package com.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

@WebServlet("/AIChat")
public class AIChatController extends HttpServlet {
    
    // DeepSeek API配置
    private static final String API_URL = "https://api.deepseek.com/v1/chat/completions";
    private static final String API_KEY = "sk-e4f7afcb45b54ba5904edfff83a47121";
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 设置字符编码
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        String userMessage = request.getParameter("message");
        
        if (userMessage == null || userMessage.trim().isEmpty()) {
            sendErrorResponse(response, "消息不能为空");
            return;
        }
        
        try {
            String aiResponse = callDeepSeekAPI(userMessage.trim());
            sendSuccessResponse(response, aiResponse);
        } catch (Exception e) {
            e.printStackTrace();
            sendErrorResponse(response, "AI服务暂时不可用，请稍后重试");
        }
    }
    
    private String callDeepSeekAPI(String userMessage) throws IOException {
        URL url = new URL(API_URL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        // 设置请求头
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + API_KEY);
        connection.setDoOutput(true);
        
        // 构建请求体
        JsonObject requestBody = new JsonObject();
        requestBody.addProperty("model", "deepseek-chat");
        requestBody.addProperty("max_tokens", 1000);
        requestBody.addProperty("temperature", 0.7);
        
        JsonArray messages = new JsonArray();
        
        // 系统提示词 - 让AI专注于摄影领域
        JsonObject systemMessage = new JsonObject();
        systemMessage.addProperty("role", "system");
        systemMessage.addProperty("content", 
            "你是一个专业的摄影助手，专门帮助用户解答摄影相关的问题。" +
            "你的专业领域包括：相机器材选择、拍摄技巧、构图方法、光线运用、后期处理、不同题材的拍摄要点等。" +
            "请用简洁易懂的语言回答，并尽可能提供实用的建议。" +
            "如果用户问的不是摄影相关问题，请礼貌地引导他们回到摄影话题。" +
            "回答时要友好、专业，并且适合中文用户。");
        messages.add(systemMessage);
        
        // 用户消息
        JsonObject userMessageObj = new JsonObject();
        userMessageObj.addProperty("role", "user");
        userMessageObj.addProperty("content", userMessage);
        messages.add(userMessageObj);
        
        requestBody.add("messages", messages);
        
        // 发送请求
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = requestBody.toString().getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }
        
        // 读取响应
        int responseCode = connection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                
                // 解析响应JSON
                Gson gson = new Gson();
                JsonObject responseJson = gson.fromJson(response.toString(), JsonObject.class);
                
                if (responseJson.has("choices") && 
                    responseJson.getAsJsonArray("choices").size() > 0) {
                    JsonObject choice = responseJson.getAsJsonArray("choices").get(0).getAsJsonObject();
                    JsonObject message = choice.getAsJsonObject("message");
                    return message.get("content").getAsString();
                }
                
                throw new IOException("Invalid API response format");
            }
        } else {
            // 读取错误响应
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(connection.getErrorStream(), StandardCharsets.UTF_8))) {
                StringBuilder errorResponse = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    errorResponse.append(responseLine.trim());
                }
                throw new IOException("API Error: " + responseCode + " - " + errorResponse.toString());
            }
        }
    }
    
    private void sendSuccessResponse(HttpServletResponse response, String aiResponse) throws IOException {
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.addProperty("success", true);
        jsonResponse.addProperty("response", aiResponse);
        
        response.getWriter().write(jsonResponse.toString());
    }
    
    private void sendErrorResponse(HttpServletResponse response, String errorMessage) throws IOException {
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.addProperty("success", false);
        jsonResponse.addProperty("error", errorMessage);
        
        response.setStatus(HttpServletResponse.SC_OK); // 仍然返回200，让前端处理错误
        response.getWriter().write(jsonResponse.toString());
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        sendErrorResponse(response, "请使用POST方法发送消息");
    }
} 