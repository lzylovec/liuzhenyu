package com.controller;

import com.bean.User;
import com.dao.IUserDAO;
import com.service.UserDAO;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginCheck")
public class loginCheck extends HttpServlet {
  public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
    // 设置请求和响应的字符编码
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html;charset=UTF-8");
    
    String userName = request.getParameter("username");
    String userPwd = request.getParameter("userpwd");
    
    // 输入验证
    if (userName == null || userName.trim().isEmpty() || 
        userPwd == null || userPwd.trim().isEmpty()) {
      request.setAttribute("outputMessage", "用户名和密码不能为空");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
      return;
    }
    
    String info;
    User user = new User();
    user.setName(userName.trim());
    user.setPasswd(userPwd);
    
    IUserDAO iUserDAO = new UserDAO();
    int result = 0;
    
    try {
      result = iUserDAO.check(user);
    } catch (Exception e) {
      e.printStackTrace();
      request.setAttribute("outputMessage", "系统错误，请稍后重试");
      RequestDispatcher dispatcher = request.getRequestDispatcher("/info.jsp");
      dispatcher.forward(request, response);
      return;
    }
    
    HttpSession session = request.getSession();
    
    switch (result) {
      case -1:
        info = "用户名不存在，请检查用户名或注册新账户";
        request.setAttribute("outputMessage", info);
        RequestDispatcher dispatcher1 = request.getRequestDispatcher("/info.jsp");
        dispatcher1.forward(request, response);
        break;
        
      case 0:
        info = "密码不正确，请重新输入";
        request.setAttribute("outputMessage", info);
        RequestDispatcher dispatcher2 = request.getRequestDispatcher("/info.jsp");
        dispatcher2.forward(request, response);
        break;
        
      case 1:
        // 登录成功，设置session
        session.setAttribute("username_session", userName.trim());
        session.setAttribute("user_role", user.getRole());
        
        // 根据用户角色进行不同的处理
        if ("admin".equals(user.getRole())) {
          info = "管理员登录成功，欢迎您！";
          request.setAttribute("outputMessage", info);
          // 管理员登录后跳转到管理面板
          response.sendRedirect("admin/dashboard");
        } else {
          info = "登录成功，欢迎来到摄影分享论坛！";
          // 普通用户登录后跳转到主页
          response.sendRedirect("home.jsp");
        }
        break;
        
      default:
        info = "未知错误，请重试";
        request.setAttribute("outputMessage", info);
        RequestDispatcher dispatcher3 = request.getRequestDispatcher("/info.jsp");
        dispatcher3.forward(request, response);
        break;
    }
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
    doPost(request, response);
  }
}
