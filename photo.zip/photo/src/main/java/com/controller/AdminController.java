package com.controller;

import com.bean.User;
import com.bean.Post;
import com.bean.Comment;
import com.service.UserDAO;
import com.service.PostDAO;
import com.service.CommentDAO;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/admin/*")
public class AdminController extends HttpServlet {
    
    private UserDAO userDAO = new UserDAO();
    private PostDAO postDAO = new PostDAO();
    private CommentDAO commentDAO = new CommentDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        String pathInfo = request.getPathInfo();
        String action = request.getParameter("action");
        
        if (pathInfo == null) {
            pathInfo = "/dashboard";
        }
        
        try {
            switch (pathInfo) {
                case "/dashboard":
                    showDashboard(request, response);
                    break;
                case "/users":
                    showUsers(request, response);
                    break;
                case "/posts":
                    if ("getPost".equals(action)) {
                        getPostForEdit(request, response);
                    } else {
                        showPosts(request, response);
                    }
                    break;
                case "/comments":
                    showComments(request, response);
                    break;
                default:
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "系统错误：" + e.getMessage());
            RequestDispatcher dispatcher = request.getRequestDispatcher("/admin_error.jsp");
            dispatcher.forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        // 检查管理员权限
        if (!checkAdminPermission(request, response)) {
            return;
        }
        
        String pathInfo = request.getPathInfo();
        String action = request.getParameter("action");
        
        try {
            if ("/users".equals(pathInfo)) {
                handleUserAction(request, response, action);
            } else if ("/posts".equals(pathInfo)) {
                handlePostAction(request, response, action);
            } else if ("/comments".equals(pathInfo)) {
                handleCommentAction(request, response, action);
            } else {
                sendJsonResponse(response, false, "未知操作");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJsonResponse(response, false, "操作失败：" + e.getMessage());
        }
    }
    
    private boolean checkAdminPermission(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username_session");
        String userRole = (String) session.getAttribute("user_role");
        
        if (username == null || !"admin".equals(userRole)) {
            if (request.getMethod().equals("GET")) {
                response.sendRedirect(request.getContextPath() + "/index.html");
            } else {
                sendJsonResponse(response, false, "权限不足，需要管理员权限");
            }
            return false;
        }
        return true;
    }
    
    private void showDashboard(HttpServletRequest request, HttpServletResponse response)
            throws Exception, ServletException, IOException {
        
        try {
            // 统计数据
            List<User> users = userDAO.findAllUsers();
            List<Post> posts = postDAO.findAll();
            List<Comment> comments = commentDAO.findAll();
            
            int totalUsers = users != null ? users.size() : 0;
            int totalPosts = posts != null ? posts.size() : 0;
            int totalComments = comments != null ? comments.size() : 0;
            int adminUsers = users != null ? (int) users.stream().filter(u -> "admin".equals(u.getRole())).count() : 0;
            
            System.out.println("管理员统计数据：总用户=" + totalUsers + ", 总帖子=" + totalPosts + ", 总评论=" + totalComments + ", 管理员=" + adminUsers);
            
            request.setAttribute("totalUsers", totalUsers);
            request.setAttribute("totalPosts", totalPosts);
            request.setAttribute("totalComments", totalComments);
            request.setAttribute("adminUsers", adminUsers);
            request.setAttribute("recentUsers", users != null ? users.stream().limit(5).toArray() : new Object[0]);
            request.setAttribute("recentPosts", posts != null ? posts.stream().limit(5).toArray() : new Object[0]);
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("/admin_dashboard.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("管理员仪表板错误：" + e.getMessage());
            throw e;
        }
    }
    
    private void showUsers(HttpServletRequest request, HttpServletResponse response)
            throws Exception, ServletException, IOException {
        
        List<User> users = userDAO.findAllUsers();
        request.setAttribute("users", users);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("/admin_users.jsp");
        dispatcher.forward(request, response);
    }
    
    private void showPosts(HttpServletRequest request, HttpServletResponse response)
            throws Exception, ServletException, IOException {
        
        List<Post> posts = postDAO.findAll();
        request.setAttribute("posts", posts);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("/admin_posts.jsp");
        dispatcher.forward(request, response);
    }
    
    private void showComments(HttpServletRequest request, HttpServletResponse response)
            throws Exception, ServletException, IOException {
        
        List<Comment> comments = commentDAO.findAll();
        request.setAttribute("comments", comments);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("/admin_comments.jsp");
        dispatcher.forward(request, response);
    }
    
    private void handleUserAction(HttpServletRequest request, HttpServletResponse response, String action)
            throws Exception, IOException {
        
        switch (action) {
            case "delete":
                int uid = Integer.parseInt(request.getParameter("uid"));
                userDAO.deleteUserById(uid);
                sendJsonResponse(response, true, "用户删除成功");
                break;
                
            case "updateRole":
                int updateUid = Integer.parseInt(request.getParameter("uid"));
                String newRole = request.getParameter("role");
                userDAO.updateUserRole(updateUid, newRole);
                sendJsonResponse(response, true, "用户角色更新成功");
                break;
                
            case "create":
                String name = request.getParameter("name");
                String passwd = request.getParameter("passwd");
                String sex = request.getParameter("sex");
                String role = request.getParameter("role");
                
                User newUser = new User();
                newUser.setName(name);
                newUser.setPasswd(passwd);
                newUser.setSex(sex);
                newUser.setRole(role);
                
                userDAO.create(newUser);
                sendJsonResponse(response, true, "用户创建成功");
                break;
                
            case "update":
                int updateAllUid = Integer.parseInt(request.getParameter("uid"));
                String updateName = request.getParameter("name");
                String updatePasswd = request.getParameter("passwd");
                String updateSex = request.getParameter("sex");
                String updateRoleAll = request.getParameter("role");
                
                User updateUser = new User();
                updateUser.setUid(updateAllUid);
                updateUser.setName(updateName);
                updateUser.setSex(updateSex);
                updateUser.setRole(updateRoleAll);
                
                // 如果密码不是占位符，则更新密码
                if (!"KEEP_ORIGINAL_PASSWORD".equals(updatePasswd)) {
                    updateUser.setPasswd(updatePasswd);
                    userDAO.update(updateUser);
                } else {
                    // 不更新密码的情况，需要特殊处理
                    userDAO.updateWithoutPassword(updateUser);
                }
                
                sendJsonResponse(response, true, "用户信息更新成功");
                break;
                
            default:
                sendJsonResponse(response, false, "未知用户操作");
                break;
        }
    }
    
    private void handlePostAction(HttpServletRequest request, HttpServletResponse response, String action)
            throws Exception, IOException {
        
        switch (action) {
            case "delete":
                int postId = Integer.parseInt(request.getParameter("postId"));
                Post post = new Post();
                post.setId(postId);
                postDAO.remove(post);
                sendJsonResponse(response, true, "帖子删除成功");
                break;
                
            case "create":
                String title = request.getParameter("title");
                String author = request.getParameter("author");
                String type = request.getParameter("type");
                String content = request.getParameter("content");
                
                Post newPost = new Post();
                newPost.setTitle(title);
                newPost.setAuthor(author);
                newPost.setType(type);
                newPost.setContent(content);
                
                postDAO.create(newPost);
                sendJsonResponse(response, true, "帖子创建成功");
                break;
                
            case "update":
                int updatePostId = Integer.parseInt(request.getParameter("postId"));
                String updateTitle = request.getParameter("title");
                String updateAuthor = request.getParameter("author");
                String updateType = request.getParameter("type");
                String updateContent = request.getParameter("content");
                
                Post updatePost = new Post();
                updatePost.setId(updatePostId);
                updatePost.setTitle(updateTitle);
                updatePost.setAuthor(updateAuthor);
                updatePost.setType(updateType);
                updatePost.setContent(updateContent);
                
                postDAO.update(updatePost);
                sendJsonResponse(response, true, "帖子更新成功");
                break;
                
            default:
                sendJsonResponse(response, false, "未知帖子操作");
                break;
        }
    }
    
    private void handleCommentAction(HttpServletRequest request, HttpServletResponse response, String action)
            throws Exception, IOException {
        
        switch (action) {
            case "delete":
                int commentId = Integer.parseInt(request.getParameter("commentId"));
                Comment comment = new Comment();
                comment.setId(commentId);
                commentDAO.remove(comment);
                sendJsonResponse(response, true, "评论删除成功");
                break;
                
            default:
                sendJsonResponse(response, false, "未知评论操作");
                break;
        }
    }
    
    private void sendJsonResponse(HttpServletResponse response, boolean success, String message) 
            throws IOException {
        Gson gson = new Gson();
        response.getWriter().write(gson.toJson(new JsonResponse(success, message)));
    }
    
    private void getPostForEdit(HttpServletRequest request, HttpServletResponse response)
            throws Exception, IOException {
        
        response.setContentType("application/json;charset=UTF-8");
        
        int postId = Integer.parseInt(request.getParameter("postId"));
        Post queryPost = new Post();
        queryPost.setId(postId);
        Post post = postDAO.findById(queryPost);
        
        if (post != null) {
            Gson gson = new Gson();
            PostResponse postResponse = new PostResponse(true, "获取成功", post);
            response.getWriter().write(gson.toJson(postResponse));
        } else {
            sendJsonResponse(response, false, "帖子不存在");
        }
    }
    
    private static class JsonResponse {
        boolean success;
        String message;
        
        JsonResponse(boolean success, String message) {
            this.success = success;
            this.message = message;
        }
    }
    
    private static class PostResponse {
        boolean success;
        String message;
        Post post;
        
        PostResponse(boolean success, String message, Post post) {
            this.success = success;
            this.message = message;
            this.post = post;
        }
    }
} 