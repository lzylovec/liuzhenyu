package com.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * 静态文件服务Servlet
 * 用于提供src/main/webapp/uploads目录下文件的访问
 */
@WebServlet("/uploads/*")
public class StaticFileServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // 获取文件名
        String fileName = pathInfo.substring(1); // 移除开头的 "/"
        
        // 直接使用项目的绝对路径
        String projectRoot = "/Users/duanxukang/code/2025课设/new/photo";
        
        String filePath = projectRoot + File.separator + "src" + File.separator + "main" + 
                         File.separator + "webapp" + File.separator + "uploads" + File.separator + fileName;
        
        File file = new File(filePath);
        
        System.out.println("StaticFileServlet - 请求文件: " + fileName);
        System.out.println("StaticFileServlet - 完整路径: " + filePath);
        System.out.println("StaticFileServlet - 文件存在: " + file.exists());
        
        // 检查文件是否存在且在uploads目录中
        if (!file.exists() || !file.isFile()) {
            System.out.println("StaticFileServlet - 文件不存在或不是文件");
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // 设置Content-Type
        String contentType = getServletContext().getMimeType(fileName);
        if (contentType == null) {
            // 根据文件扩展名设置默认的图片类型
            String extension = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
            switch (extension) {
                case "jpg":
                case "jpeg":
                    contentType = "image/jpeg";
                    break;
                case "png":
                    contentType = "image/png";
                    break;
                case "gif":
                    contentType = "image/gif";
                    break;
                case "webp":
                    contentType = "image/webp";
                    break;
                default:
                    contentType = "application/octet-stream";
            }
        }
        
        response.setContentType(contentType);
        response.setContentLength((int) file.length());
        
        // 设置缓存头
        response.setHeader("Cache-Control", "public, max-age=3600");
        response.setDateHeader("Expires", System.currentTimeMillis() + 3600000L);
        
        System.out.println("StaticFileServlet - 开始输出文件内容，大小: " + file.length());
        
        // 输出文件内容
        try (FileInputStream fileInputStream = new FileInputStream(file);
             OutputStream outputStream = response.getOutputStream()) {
            
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }
        
        System.out.println("StaticFileServlet - 文件输出完成");
    }
} 