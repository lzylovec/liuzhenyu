-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2020-12-29 13:27:02
-- 服务器版本： 8.0.22
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `forumsys`
--

-- --------------------------------------------------------

--
-- 表的结构 `comment`
--

CREATE TABLE `comment` (
  `id` int NOT NULL,
  `post_id` int DEFAULT NULL,
  `author` varchar(20) DEFAULT NULL,
  `content` text,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- 转存表中的数据 `comment`
--

INSERT INTO `comment` (`id`, `post_id`, `author`, `content`, `date`) VALUES
(3, 14, 'user1', '怎么有人没水了呀', '2020-12-14'),
(4, 11, 'user1', '感谢分享！', '2020-12-14'),
(5, 12, 'user1', '+1！！！', '2020-12-14'),
(6, 12, 'user1', '11111111111', '2020-12-14'),
(12, 11, 'user1', '1111', '2020-12-16'),
(13, 18, 'zzr', '1111', '2020-12-16'),
(14, 11, 'user1', '111', '2020-12-16'),
(15, 20, 'photographer1', '光线处理得很棒！', '2024-01-15'),
(16, 21, 'photographer2', '构图很有创意', '2024-01-16'),
(17, 22, 'user1', '这个镜头很不错，推荐！', '2024-01-17'),
(18, 23, 'gearmaster', '街拍技巧很实用', '2024-01-18'),
(19, 24, 'streetphoto', '冬季拍摄确实要注意保暖', '2024-01-19');

-- --------------------------------------------------------

--
-- 表的结构 `post`
--

CREATE TABLE `post` (
  `id` int NOT NULL COMMENT '//序号',
  `title` varchar(255) NOT NULL COMMENT '//标题',
  `author` varchar(128) NOT NULL COMMENT '//作者',
  `type` varchar(40) NOT NULL COMMENT '//类型',
  `content` text NOT NULL COMMENT '//文章内容',
  `date` date NOT NULL COMMENT '//发布日期'
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

--
-- 转存表中的数据 `post`
--

INSERT INTO `post` (`id`, `title`, `author`, `type`, `content`, `date`) VALUES
(11, 'C++入门分享', 'user1', '学习讨论', '学习 C++，可以分为两大部分：C++语言和 C++标准库先说 C++语言部分：1.语言基础，推荐图书 C++ Primer（中文版 第5版）2.进一步提升，可以读 Effective C++（第3版 中文版）和 More Effective C++（中文版）这两本书，帮助你写更规范专业的 C++代码3.有C基础的，也可以直接看 C++面向对象开发 | 博览网 Boolan对1&2中的重点难点做了深入剖析，BTW 课程主讲就是上面两书的翻译侯捷老师然后 C++标准库的部分：1.经典之作：侯捷的 《STL源码剖析》2.觉得书难啃的，可以看对应的在线课 STL标准库与泛型编程 | 博览网 Boolan课程还有个综合版 《C++开发工程师》微专业 | 博览网 Boolan 适合想系统学习 C++的掌握这两部分，才是真正的 C++入门了，即可以从事 C++开发的相关岗位工作。', '2020-12-14'),
(12, '表白钟俊龙', 'user1', '表白墙', '表白19计本3班钟俊龙！！！', '2020-12-14'),
(14, '怎么宿舍又没水了', 'user2', '校园生活', '包租婆没水了！！！', '2020-12-14'),
(16, '有人有二手小电驴出售吗', 'user1', '校园生活', '如题！', '2020-12-14'),
(18, '求大一下学期计本书单！', 'zzr', '校园生活', '求大一下学期计本书单！', '2020-12-16'),
(20, '夕阳下的人像摄影技巧', 'photographer1', '人像摄影', '分享一些在夕阳下拍摄人像的心得：\n\n1. 逆光拍摄：利用夕阳作为背景光源，营造唯美的轮廓光效果\n2. 补光技巧：使用反光板或闪光灯为面部补光，避免过度曝光\n3. 色温调节：适当调节白平衡，让画面更加温暖\n4. 构图要点：注意人物与背景的比例关系\n\n拍摄参数参考：\n- 光圈：f/2.8-f/4\n- 快门：1/200s\n- ISO：100-400\n- 焦距：85mm-135mm', '2024-01-15'),
(21, '山景摄影的黄金时刻', 'photographer2', '风景摄影', '分享山景摄影的最佳时机和技巧：\n\n黄金时刻拍摄要点：\n- 日出前30分钟到日出后1小时\n- 日落前1小时到日落后30分钟\n\n构图技巧：\n1. 前景、中景、远景的层次安排\n2. 利用引导线创造视觉焦点\n3. 三分法构图让画面更和谐\n\n器材推荐：\n- 广角镜头：14-24mm\n- 三脚架必备\n- 偏振镜和渐变镜\n- 快门线或遥控器\n\n后期处理要点：\n- 适度增强对比度\n- 调整高光和阴影\n- 色彩分离调色', '2024-01-16'),
(22, '索尼A7R5使用心得', 'gearmaster', '器材交流', '入手索尼A7R5半年了，分享一些使用心得：\n\n优点：\n- 6100万像素，画质出色\n- 8K视频录制能力\n- 5轴防抖效果显著\n- 对焦速度和精度都很不错\n- 电池续航有明显改善\n\n缺点：\n- 体积和重量相对较大\n- 高像素对镜头要求较高\n- 存储卡写入速度要求高\n- 价格相对偏高\n\n适合用户：\n- 风景摄影师\n- 商业摄影师\n- 对画质有极高要求的用户\n\n搭配镜头推荐：\n- 24-70mm f/2.8 GM\n- 70-200mm f/2.8 GM\n- 16-35mm f/2.8 GM', '2024-01-17'),
(23, '街头人像抓拍技巧', 'streetphoto', '人像摄影', '街头人像摄影的抓拍心得：\n\n设备选择：\n- 相机：选择静音快门模式\n- 镜头：50mm或85mm定焦镜头\n- 设置：光圈优先模式，f/2.8-f/4\n\n拍摄技巧：\n1. 观察和等待：找到有趣的光影和背景\n2. 快速对焦：使用单点对焦模式\n3. 连拍模式：捕捉最自然的表情\n4. 保持距离：使用长焦镜头避免打扰被摄者\n\n伦理考量：\n- 尊重被摄者的隐私权\n- 必要时征得同意\n- 避免在私人场所拍摄', '2024-01-18'),
(24, '冬季山景拍摄攻略', 'mountainlover', '风景摄影', '冬季山景摄影的特殊技巧：\n\n器材准备：\n- 保暖措施：相机和电池的保温\n- 防潮处理：避免镜头起雾\n- 额外电池：低温下电池消耗快\n\n拍摄技巧：\n1. 雪景曝光：适当增加曝光补偿+0.7至+1.3EV\n2. 白平衡：使用日光或阴天模式\n3. 构图：利用雪地的纹理和线条\n4. 时机：雪后初晴的光线最美\n\n安全注意：\n- 天气预报：关注天气变化\n- 路线规划：选择安全的拍摄点\n- 装备检查：确保保暖和通讯设备\n- 结伴出行：避免独自前往危险地区', '2024-01-19');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE `user` (
  `uid` int NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `passwd` varchar(20) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL,
  `rtime` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`uid`, `name`, `passwd`, `sex`, `rtime`) VALUES
(1, 'user1', '111111', 'man', '2020-12-08'),
(3, 'user2', '222222', 'man', '2020-12-09'),
(6, 'zzr', '111111', 'man', '2020-12-16'),
(7, 'photographer1', '123456', 'man', '2024-01-15'),
(8, 'photographer2', '123456', 'woman', '2024-01-16'),
(9, 'gearmaster', '123456', 'man', '2024-01-17'),
(10, 'streetphoto', '123456', 'woman', '2024-01-18'),
(11, 'mountainlover', '123456', 'man', '2024-01-19');

--
-- 转储表的索引
--

--
-- 表的索引 `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- 使用表AUTO_INCREMENT `post`
--
ALTER TABLE `post`
  MODIFY `id` int NOT NULL AUTO_INCREMENT COMMENT '//序号', AUTO_INCREMENT=25;

--
-- 使用表AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `uid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
