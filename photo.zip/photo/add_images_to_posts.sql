
-- 1. 为posts表添加images字段，用于存储图片路径（JSON格式）
ALTER TABLE post ADD COLUMN images TEXT COMMENT '图片路径列表，JSON格式存储';
-- 3. 更新现有posts表的images字段为空JSON数组（如果需要）
UPDATE post SET images = '[]' WHERE images IS NULL;