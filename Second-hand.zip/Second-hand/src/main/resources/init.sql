-- 二手商城数据库初始化脚本

-- 创建数据库
CREATE DATABASE IF NOT EXISTS secondhand_mall CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE secondhand_mall;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(255) NOT NULL COMMENT '密码（加密后）',
    email VARCHAR(100) COMMENT '邮箱',
    phone VARCHAR(20) COMMENT '电话',
    real_name VARCHAR(50) COMMENT '真实姓名',
    address TEXT COMMENT '地址',
    user_type INT NOT NULL DEFAULT 1 COMMENT '用户类型：1-普通用户，2-商家，3-管理员',
    balance DECIMAL(10,2) DEFAULT 0.00 COMMENT '余额',
    credit_score INT DEFAULT 100 COMMENT '信用分数',
    status INT DEFAULT 1 COMMENT '状态：1-正常，0-拉黑',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_username (username),
    INDEX idx_user_type (user_type),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- 商品表
CREATE TABLE IF NOT EXISTS products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(200) NOT NULL COMMENT '商品名称',
    description TEXT COMMENT '商品描述',
    price DECIMAL(10,2) NOT NULL COMMENT '价格',
    stock INT NOT NULL DEFAULT 0 COMMENT '库存',
    category VARCHAR(50) COMMENT '分类',
    image_url VARCHAR(500) COMMENT '图片URL',
    seller_id INT NOT NULL COMMENT '卖家ID',
    seller_name VARCHAR(50) COMMENT '卖家名称',
    status INT DEFAULT 1 COMMENT '状态：1-上架，0-下架',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_seller_id (seller_id),
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_price (price),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品表';

-- 订单表
CREATE TABLE IF NOT EXISTS orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(50) NOT NULL UNIQUE COMMENT '订单号',
    buyer_id INT NOT NULL COMMENT '买家ID',
    buyer_name VARCHAR(50) COMMENT '买家姓名',
    product_id INT NOT NULL COMMENT '商品ID',
    product_name VARCHAR(200) COMMENT '商品名称',
    seller_id INT NOT NULL COMMENT '卖家ID',
    seller_name VARCHAR(50) COMMENT '卖家姓名',
    quantity INT NOT NULL COMMENT '购买数量',
    unit_price DECIMAL(10,2) NOT NULL COMMENT '单价',
    total_amount DECIMAL(10,2) NOT NULL COMMENT '总金额',
    shipping_address TEXT COMMENT '收货地址',
    contact_phone VARCHAR(20) COMMENT '联系电话',
    status INT DEFAULT 1 COMMENT '订单状态：1-待支付，2-已支付，3-已发货，4-已完成，5-已取消',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (buyer_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_order_number (order_number),
    INDEX idx_buyer_id (buyer_id),
    INDEX idx_seller_id (seller_id),
    INDEX idx_product_id (product_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单表';

-- 插入初始数据

-- 插入管理员用户（密码：admin123，已加密）
INSERT INTO users (username, password, email, real_name, user_type, balance, credit_score) VALUES 
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iKXIGfMxO5EhKYDHUv4HJbVRIlFK', 'admin@secondhand.com', '系统管理员', 3, 0.00, 100);

-- 插入测试商家（密码：seller123，已加密）
INSERT INTO users (username, password, email, phone, real_name, address, user_type, balance, credit_score) VALUES 
('seller1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iKXIGfMxO5EhKYDHUv4HJbVRIlFK', 'seller1@test.com', '13800138001', '张三', '北京市朝阳区', 2, 1000.00, 100),
('seller2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iKXIGfMxO5EhKYDHUv4HJbVRIlFK', 'seller2@test.com', '13800138002', '李四', '上海市浦东新区', 2, 800.00, 95);

-- 插入测试用户（密码：user123，已加密）
INSERT INTO users (username, password, email, phone, real_name, address, user_type, balance, credit_score) VALUES 
('user1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iKXIGfMxO5EhKYDHUv4HJbVRIlFK', 'user1@test.com', '13900139001', '王五', '广州市天河区', 1, 500.00, 100),
('user2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iKXIGfMxO5EhKYDHUv4HJbVRIlFK', 'user2@test.com', '13900139002', '赵六', '深圳市南山区', 1, 300.00, 98);

-- 插入测试商品
INSERT INTO products (product_name, description, price, stock, category, image_url, seller_id, seller_name, status) VALUES 
('iPhone 13 二手', '9成新iPhone 13，128GB，无拆无修，功能正常', 4500.00, 1, '数码电子', 'https://example.com/iphone13.jpg', 2, 'seller1', 1),
('MacBook Pro 2021', '95新MacBook Pro，M1芯片，512GB SSD', 8800.00, 1, '数码电子', 'https://example.com/macbook.jpg', 2, 'seller1', 1),
('Nike Air Jordan 1', '全新Nike AJ1，US9码，带盒带标', 1200.00, 2, '服装鞋帽', 'https://example.com/aj1.jpg', 3, 'seller2', 1),
('小米电视55寸', '小米电视4A，55寸4K，使用1年', 1800.00, 1, '家用电器', 'https://example.com/tv.jpg', 3, 'seller2', 1),
('戴森吸尘器V8', '戴森V8无线吸尘器，8成新，配件齐全', 1500.00, 1, '家用电器', 'https://example.com/dyson.jpg', 2, 'seller1', 1);

-- 插入测试订单
INSERT INTO orders (order_number, buyer_id, buyer_name, product_id, product_name, seller_id, seller_name, quantity, unit_price, total_amount, shipping_address, contact_phone, status) VALUES 
('ORD20240101001', 4, 'user1', 1, 'iPhone 13 二手', 2, 'seller1', 1, 4500.00, 4500.00, '广州市天河区天河路123号', '13900139001', 2),
('ORD20240101002', 5, 'user2', 3, 'Nike Air Jordan 1', 3, 'seller2', 1, 1200.00, 1200.00, '深圳市南山区科技园456号', '13900139002', 4),
('ORD20240101003', 4, 'user1', 5, '戴森吸尘器V8', 2, 'seller1', 1, 1500.00, 1500.00, '广州市天河区天河路123号', '13900139001', 1);

-- 创建视图：商品销售统计
CREATE VIEW product_sales_stats AS
SELECT 
    p.product_id,
    p.product_name,
    p.seller_id,
    p.seller_name,
    p.category,
    p.price,
    p.stock,
    COALESCE(SUM(o.quantity), 0) as total_sold,
    COALESCE(SUM(o.total_amount), 0) as total_revenue,
    COUNT(o.order_id) as order_count
FROM products p
LEFT JOIN orders o ON p.product_id = o.product_id AND o.status IN (2, 3, 4)
GROUP BY p.product_id;

-- 创建视图：用户订单统计
CREATE VIEW user_order_stats AS
SELECT 
    u.user_id,
    u.username,
    u.real_name,
    u.user_type,
    COALESCE(buyer_stats.order_count, 0) as buy_order_count,
    COALESCE(buyer_stats.total_spent, 0) as total_spent,
    COALESCE(seller_stats.sell_order_count, 0) as sell_order_count,
    COALESCE(seller_stats.total_earned, 0) as total_earned
FROM users u
LEFT JOIN (
    SELECT 
        buyer_id,
        COUNT(*) as order_count,
        SUM(total_amount) as total_spent
    FROM orders 
    WHERE status IN (2, 3, 4)
    GROUP BY buyer_id
) buyer_stats ON u.user_id = buyer_stats.buyer_id
LEFT JOIN (
    SELECT 
        seller_id,
        COUNT(*) as sell_order_count,
        SUM(total_amount) as total_earned
    FROM orders 
    WHERE status IN (2, 3, 4)
    GROUP BY seller_id
) seller_stats ON u.user_id = seller_stats.seller_id;

-- 创建存储过程：更新用户信用分数
DELIMITER //
CREATE PROCEDURE UpdateUserCreditScore(IN userId INT)
BEGIN
    DECLARE orderCount INT DEFAULT 0;
    DECLARE completedCount INT DEFAULT 0;
    DECLARE cancelledCount INT DEFAULT 0;
    DECLARE newCreditScore INT DEFAULT 100;
    
    -- 统计用户订单情况
    SELECT COUNT(*) INTO orderCount FROM orders WHERE buyer_id = userId;
    SELECT COUNT(*) INTO completedCount FROM orders WHERE buyer_id = userId AND status = 4;
    SELECT COUNT(*) INTO cancelledCount FROM orders WHERE buyer_id = userId AND status = 5;
    
    -- 计算信用分数
    IF orderCount > 0 THEN
        SET newCreditScore = 100 + (completedCount * 2) - (cancelledCount * 5);
        IF newCreditScore > 150 THEN
            SET newCreditScore = 150;
        ELSEIF newCreditScore < 0 THEN
            SET newCreditScore = 0;
        END IF;
    END IF;
    
    -- 更新用户信用分数
    UPDATE users SET credit_score = newCreditScore WHERE user_id = userId;
END //
DELIMITER ;

-- 创建触发器：订单状态变更时自动更新用户信用分数
DELIMITER //
CREATE TRIGGER update_credit_after_order_status_change
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status AND NEW.status IN (4, 5) THEN
        CALL UpdateUserCreditScore(NEW.buyer_id);
    END IF;
END //
DELIMITER ;

-- 创建索引优化查询性能
CREATE INDEX idx_products_name_category ON products(product_name, category);
CREATE INDEX idx_orders_buyer_status ON orders(buyer_id, status);
CREATE INDEX idx_orders_seller_status ON orders(seller_id, status);
CREATE INDEX idx_users_type_status ON users(user_type, status);

-- 显示创建结果
SELECT 'Database initialization completed successfully!' as message;
SELECT 'Default admin user: admin/admin123' as admin_info;
SELECT 'Test seller users: seller1/seller123, seller2/seller123' as seller_info;
SELECT 'Test buyer users: user1/user123, user2/user123' as buyer_info;