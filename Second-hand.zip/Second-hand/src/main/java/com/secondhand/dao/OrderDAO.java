package com.secondhand.dao;

import com.secondhand.entity.Order;
import com.secondhand.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 订单数据访问对象
 */
public class OrderDAO {
    
    /**
     * 创建订单
     */
    public boolean createOrder(Order order) {
        String sql = "INSERT INTO orders (order_number, buyer_id, buyer_name, product_id, product_name, seller_id, seller_name, quantity, unit_price, total_amount, shipping_address, contact_phone, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, order.getOrderNo());
            pstmt.setInt(2, order.getUserId());
            pstmt.setString(3, order.getUserName());
            pstmt.setInt(4, order.getProductId());
            pstmt.setString(5, order.getProductName());
            pstmt.setInt(6, order.getSellerId());
            pstmt.setString(7, order.getSellerName());
            pstmt.setInt(8, order.getQuantity());
            pstmt.setBigDecimal(9, order.getUnitPrice());
            pstmt.setBigDecimal(10, order.getTotalAmount());
            pstmt.setString(11, order.getShippingAddress());
            pstmt.setString(12, order.getPhone());
            pstmt.setInt(13, order.getStatus());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 根据订单号查找订单
     */
    public Order findByOrderNo(String orderNo) {
        String sql = "SELECT o.*, u.username as user_name, p.product_name, s.username as seller_name " +
                    "FROM orders o " +
                    "LEFT JOIN users u ON o.buyer_id = u.user_id " +
                    "LEFT JOIN products p ON o.product_id = p.product_id " +
                    "LEFT JOIN users s ON o.seller_id = s.user_id " +
                    "WHERE o.order_number = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, orderNo);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToOrder(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * 根据ID查找订单
     */
    public Order findById(Integer orderId) {
        String sql = "SELECT o.*, u.username as user_name, p.product_name, s.username as seller_name " +
                    "FROM orders o " +
                    "LEFT JOIN users u ON o.buyer_id = u.user_id " +
                    "LEFT JOIN products p ON o.product_id = p.product_id " +
                    "LEFT JOIN users s ON o.seller_id = s.user_id " +
                    "WHERE o.order_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, orderId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToOrder(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * 更新订单状态
     */
    public boolean updateStatus(Integer orderId, Integer status) {
        String sql = "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, status);
            pstmt.setInt(2, orderId);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 更新订单收货地址
     */
    public boolean updateShippingAddress(Integer orderId, String address, String phone) {
        String sql = "UPDATE orders SET shipping_address = ?, contact_phone = ?, updated_at = CURRENT_TIMESTAMP WHERE order_id = ? AND status = 1";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, address);
            pstmt.setString(2, phone);
            pstmt.setInt(3, orderId);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 删除订单（仅限待支付状态）
     */
    public boolean deleteOrder(Integer orderId, Integer userId) {
        String sql = "DELETE FROM orders WHERE order_id = ? AND buyer_id = ? AND status = 1";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, orderId);
            pstmt.setInt(2, userId);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 根据用户ID查找订单
     */
    public List<Order> findByUserId(Integer userId) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.*, u.username as user_name, p.product_name, s.username as seller_name " +
                    "FROM orders o " +
                    "LEFT JOIN users u ON o.buyer_id = u.user_id " +
                    "LEFT JOIN products p ON o.product_id = p.product_id " +
                    "LEFT JOIN users s ON o.seller_id = s.user_id " +
                    "WHERE o.buyer_id = ? ORDER BY o.created_at DESC";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    orders.add(mapResultSetToOrder(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
    
    /**
     * 根据卖家ID查找订单
     */
    public List<Order> findBySellerId(Integer sellerId) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.*, u.username as user_name, p.product_name, s.username as seller_name " +
                    "FROM orders o " +
                    "LEFT JOIN users u ON o.buyer_id = u.user_id " +
                    "LEFT JOIN products p ON o.product_id = p.product_id " +
                    "LEFT JOIN users s ON o.seller_id = s.user_id " +
                    "WHERE o.seller_id = ? ORDER BY o.created_at DESC";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, sellerId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    orders.add(mapResultSetToOrder(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
    
    /**
     * 获取所有订单（管理员功能）
     */
    public List<Order> findAllOrders() {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.*, u.username as user_name, p.product_name, s.username as seller_name " +
                    "FROM orders o " +
                    "LEFT JOIN users u ON o.buyer_id = u.user_id " +
                    "LEFT JOIN products p ON o.product_id = p.product_id " +
                    "LEFT JOIN users s ON o.seller_id = s.user_id " +
                    "ORDER BY o.created_at DESC";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
    
    /**
     * 根据状态查找订单
     */
    public List<Order> findByStatus(Integer status) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.*, u.username as user_name, p.product_name, s.username as seller_name " +
                    "FROM orders o " +
                    "LEFT JOIN users u ON o.buyer_id = u.user_id " +
                    "LEFT JOIN products p ON o.product_id = p.product_id " +
                    "LEFT JOIN users s ON o.seller_id = s.user_id " +
                    "WHERE o.status = ? ORDER BY o.created_at DESC";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, status);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    orders.add(mapResultSetToOrder(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
    
    /**
     * 生成订单号
     */
    public String generateOrderNo() {
        return "ORD" + System.currentTimeMillis();
    }
    
    /**
     * 将ResultSet映射为Order对象
     */
    private Order mapResultSetToOrder(ResultSet rs) throws SQLException {
        Order order = new Order();
        order.setOrderId(rs.getInt("order_id"));
        order.setOrderNo(rs.getString("order_number"));
        order.setUserId(rs.getInt("buyer_id"));
        order.setUserName(rs.getString("buyer_name"));
        order.setProductId(rs.getInt("product_id"));
        order.setProductName(rs.getString("product_name"));
        order.setSellerId(rs.getInt("seller_id"));
        order.setSellerName(rs.getString("seller_name"));
        order.setQuantity(rs.getInt("quantity"));
        order.setUnitPrice(rs.getBigDecimal("unit_price"));
        order.setTotalAmount(rs.getBigDecimal("total_amount"));
        order.setShippingAddress(rs.getString("shipping_address"));
        order.setPhone(rs.getString("contact_phone"));
        order.setStatus(rs.getInt("status"));
        order.setCreateTime(rs.getTimestamp("created_at"));
        order.setUpdateTime(rs.getTimestamp("updated_at"));
        return order;
    }
} 