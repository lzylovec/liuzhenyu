package com.secondhand.servlet;

import com.google.gson.Gson;
import com.secondhand.entity.Product;
import com.secondhand.entity.User;
import com.secondhand.service.ProductService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 商品相关的Servlet
 */

public class ProductServlet extends HttpServlet {
    private ProductService productService;
    private Gson gson;
    
    @Override
    public void init() throws ServletException {
        productService = new ProductService();
        gson = new Gson();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/list":
                getProductList(request, response);
                break;
            case "/detail":
                getProductDetail(request, response);
                break;
            case "/myProducts":
                getMyProducts(request, response);
                break;
            case "/categories":
                getCategories(request, response);
                break;
            case "/search":
                searchProducts(request, response);
                break;
            case "/category":
                getProductsByCategory(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/add":
                addProduct(request, response);
                break;
            case "/update":
                updateProduct(request, response);
                break;
            case "/delete":
                deleteProduct(request, response);
                break;
            case "/publish":
                publishProduct(request, response);
                break;
            case "/unpublish":
                unpublishProduct(request, response);
                break;
            case "/addStock":
                addStock(request, response);
                break;
            case "/updateStatus":
                updateStatus(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    /**
     * 添加商品
     */
    private void addProduct(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        if (currentUser.getUserType() != 2 && currentUser.getUserType() != 3) {
            result.put("success", false);
            result.put("message", "只有商家可以添加商品");
            sendJsonResponse(response, result);
            return;
        }
        
        String productName = request.getParameter("productName");
        String description = request.getParameter("description");
        String priceStr = request.getParameter("price");
        String stockStr = request.getParameter("stock");
        String category = request.getParameter("category");
        String imageUrl = request.getParameter("imageUrl");
        
        try {
            BigDecimal price = new BigDecimal(priceStr);
            Integer stock = Integer.parseInt(stockStr);
            
            // 验证商品信息
            String validationError = productService.validateProduct(productName, description, price, stock, category);
            if (validationError != null) {
                result.put("success", false);
                result.put("message", validationError);
                sendJsonResponse(response, result);
                return;
            }
            
            boolean success = productService.addProduct(productName, description, price, stock, category, imageUrl, currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "商品添加成功");
            } else {
                result.put("success", false);
                result.put("message", "商品添加失败");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "价格或库存格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 更新商品
     */
    private void updateProduct(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String productIdStr = request.getParameter("productId");
        String productName = request.getParameter("productName");
        String description = request.getParameter("description");
        String priceStr = request.getParameter("price");
        String stockStr = request.getParameter("stock");
        String category = request.getParameter("category");
        String imageUrl = request.getParameter("imageUrl");
        
        try {
            Integer productId = Integer.parseInt(productIdStr);
            BigDecimal price = new BigDecimal(priceStr);
            Integer stock = Integer.parseInt(stockStr);
            
            // 验证商品信息
            String validationError = productService.validateProduct(productName, description, price, stock, category);
            if (validationError != null) {
                result.put("success", false);
                result.put("message", validationError);
                sendJsonResponse(response, result);
                return;
            }
            
            boolean success = productService.updateProduct(productId, productName, description, price, stock, category, imageUrl, currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "商品更新成功");
            } else {
                result.put("success", false);
                result.put("message", "商品更新失败，可能不是您的商品");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "参数格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 删除商品
     */
    private void deleteProduct(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String productIdStr = request.getParameter("productId");
        
        try {
            Integer productId = Integer.parseInt(productIdStr);
            boolean success = productService.deleteProduct(productId, currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "商品删除成功");
            } else {
                result.put("success", false);
                result.put("message", "商品删除失败，可能不是您的商品");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "商品ID格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 上架商品
     */
    private void publishProduct(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String productIdStr = request.getParameter("productId");
        
        try {
            Integer productId = Integer.parseInt(productIdStr);
            boolean success = productService.publishProduct(productId, currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "商品上架成功");
            } else {
                result.put("success", false);
                result.put("message", "商品上架失败");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "商品ID格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 下架商品
     */
    private void unpublishProduct(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String productIdStr = request.getParameter("productId");
        
        try {
            Integer productId = Integer.parseInt(productIdStr);
            boolean success = productService.unpublishProduct(productId, currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "商品下架成功");
            } else {
                result.put("success", false);
                result.put("message", "商品下架失败");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "商品ID格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 增加库存
     */
    private void addStock(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String productIdStr = request.getParameter("productId");
        String quantityStr = request.getParameter("quantity");
        
        try {
            Integer productId = Integer.parseInt(productIdStr);
            Integer quantity = Integer.parseInt(quantityStr);
            
            boolean success = productService.addStock(productId, quantity, currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "库存增加成功");
            } else {
                result.put("success", false);
                result.put("message", "库存增加失败");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "参数格式错误");
        }
        
                sendJsonResponse(response, result);
    }

    /**
     * 更新商品状态
     */
    private void updateStatus(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String productIdStr = request.getParameter("productId");
        String statusStr = request.getParameter("status");
        
        try {
            Integer productId = Integer.parseInt(productIdStr);
            Integer status = Integer.parseInt(statusStr);
            
            boolean success = productService.updateProductStatus(productId, status, currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", status == 1 ? "商品上架成功" : "商品下架成功");
            } else {
                result.put("success", false);
                result.put("message", "状态更新失败，可能不是您的商品");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "参数格式错误");
        }
        
        sendJsonResponse(response, result);
    }

    /**
     * 获取商品列表
     */
    private void getProductList(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        List<Product> products = productService.getAllProducts();
        
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("products", products);
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取商品详情
     */
    private void getProductDetail(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String productIdStr = request.getParameter("productId");
        Map<String, Object> result = new HashMap<>();
        
        try {
            Integer productId = Integer.parseInt(productIdStr);
            Product product = productService.getProductById(productId);
            
            if (product != null) {
                result.put("success", true);
                result.put("product", product);
            } else {
                result.put("success", false);
                result.put("message", "商品不存在");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "商品ID格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取我的商品
     */
    private void getMyProducts(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        List<Product> products = productService.getProductsBySeller(currentUser.getUserId());
        result.put("success", true);
        result.put("products", products);
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取商品分类
     */
    private void getCategories(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        List<String> categories = productService.getCategories();
        
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("categories", categories);
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 搜索商品
     */
    private void searchProducts(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String keyword = request.getParameter("keyword");
        
        List<Product> products = productService.searchProducts(keyword);
        
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("products", products);
        result.put("keyword", keyword);
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 根据分类获取商品
     */
    private void getProductsByCategory(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String category = request.getParameter("category");
        
        List<Product> products = productService.getProductsByCategory(category);
        
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("products", products);
        result.put("category", category);
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取当前登录用户
     */
    private User getCurrentUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            return (User) session.getAttribute("user");
        }
        return null;
    }
    
    /**
     * 发送JSON响应
     */
    private void sendJsonResponse(HttpServletResponse response, Object data) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(data));
        out.flush();
    }
}