package com.secondhand.servlet;

import com.google.gson.Gson;
import com.secondhand.entity.User;
import com.secondhand.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户相关的Servlet
 */

public class UserServlet extends HttpServlet {
    private UserService userService;
    private Gson gson;
    
    @Override
    public void init() throws ServletException {
        userService = new UserService();
        gson = new Gson();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/profile":
                getUserProfile(request, response);
                break;
            case "/list":
                getUserList(request, response);
                break;
            case "/logout":
                logout(request, response);
                break;
            case "/checkUsername":
                checkUsername(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/register":
                register(request, response);
                break;
            case "/login":
                login(request, response);
                break;
            case "/update":
                updateProfile(request, response);
                break;
            case "/recharge":
                recharge(request, response);
                break;
            case "/withdraw":
                withdraw(request, response);
                break;
            case "/updateCredit":
                updateCredit(request, response);
                break;
            case "/blacklist":
                blacklistUser(request, response);
                break;
            case "/unblacklist":
                unblacklistUser(request, response);
                break;
            case "/changePassword":
                changePassword(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    /**
     * 用户注册
     */
    private void register(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String userTypeStr = request.getParameter("userType");
        
        // 检查是否为Ajax请求
        String accept = request.getHeader("Accept");
        boolean isAjax = accept != null && accept.contains("application/json");
        
        if (username == null || password == null || email == null || phone == null) {
            if (isAjax) {
                Map<String, Object> result = new HashMap<>();
                result.put("success", false);
                result.put("message", "参数不完整");
                sendJsonResponse(response, result);
            } else {
                response.sendRedirect(request.getContextPath() + "/user/register.jsp?error=incomplete");
            }
            return;
        }
        
        Integer userType = 1; // 默认普通用户
        if (userTypeStr != null && !userTypeStr.isEmpty()) {
            try {
                userType = Integer.parseInt(userTypeStr);
            } catch (NumberFormatException e) {
                userType = 1;
            }
        }
        
        boolean success = userService.register(username, password, email, phone, userType);
        
        if (success) {
            if (isAjax) {
                Map<String, Object> result = new HashMap<>();
                result.put("success", true);
                result.put("message", "注册成功");
                sendJsonResponse(response, result);
            } else {
                response.sendRedirect(request.getContextPath() + "/user/login.jsp?success=registered");
            }
        } else {
            if (isAjax) {
                Map<String, Object> result = new HashMap<>();
                result.put("success", false);
                result.put("message", "注册失败，用户名可能已存在");
                sendJsonResponse(response, result);
            } else {
                response.sendRedirect(request.getContextPath() + "/user/register.jsp?error=exists&username=" + username + "&email=" + email + "&phone=" + phone + "&userType=" + userType);
            }
        }
    }
    
    /**
     * 用户登录
     */
    private void login(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        // 检查是否为Ajax请求
        String accept = request.getHeader("Accept");
        boolean isAjax = accept != null && accept.contains("application/json");
        
        if (username == null || password == null || username.trim().isEmpty() || password.trim().isEmpty()) {
            if (isAjax) {
                Map<String, Object> result = new HashMap<>();
                result.put("success", false);
                result.put("message", "用户名和密码不能为空");
                sendJsonResponse(response, result);
            } else {
                response.sendRedirect(request.getContextPath() + "/user/login.jsp?error=empty&username=" + (username != null ? username : ""));
            }
            return;
        }
        
        User user = userService.login(username, password);
        
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            
            if (isAjax) {
                Map<String, Object> result = new HashMap<>();
                result.put("success", true);
                result.put("message", "登录成功");
                result.put("user", user);
                sendJsonResponse(response, result);
            } else {
                // 根据用户类型跳转到不同页面
                if (user.getUserType() == 3) {
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard.jsp");
                } else {
                    response.sendRedirect(request.getContextPath() + "/index.jsp");
                }
            }
        } else {
            if (isAjax) {
                Map<String, Object> result = new HashMap<>();
                result.put("success", false);
                result.put("message", "用户名或密码错误，或账户已被拉黑");
                sendJsonResponse(response, result);
            } else {
                response.sendRedirect(request.getContextPath() + "/user/login.jsp?error=invalid&username=" + username);
            }
        }
    }
    
    /**
     * 用户登出
     */
    private void logout(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", "登出成功");
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取用户信息
     */
    private void getUserProfile(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        // 重新从数据库获取最新用户信息
        User user = userService.getUserById(currentUser.getUserId());
        
        if (user != null) {
            result.put("success", true);
            result.put("user", user);
        } else {
            result.put("success", false);
            result.put("message", "用户不存在");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 更新用户信息
     */
    private void updateProfile(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        
        // 检查是否为Ajax请求
        String accept = request.getHeader("Accept");
        boolean isAjax = accept != null && accept.contains("application/json");
        
        if (currentUser == null) {
            if (isAjax) {
                Map<String, Object> result = new HashMap<>();
                result.put("success", false);
                result.put("message", "请先登录");
                sendJsonResponse(response, result);
            } else {
                response.sendRedirect(request.getContextPath() + "/user/login.jsp?error=unauthorized");
            }
            return;
        }
        
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String realName = request.getParameter("realName");
        String address = request.getParameter("address");
        
        boolean success = userService.updateUserInfo(currentUser.getUserId(), email, phone, realName, address);
        
        if (success) {
            // 更新session中的用户信息
            User updatedUser = userService.getUserById(currentUser.getUserId());
            if (updatedUser != null) {
                HttpSession session = request.getSession();
                session.setAttribute("user", updatedUser);
            }
            
            if (isAjax) {
                Map<String, Object> result = new HashMap<>();
                result.put("success", true);
                result.put("message", "更新成功");
                sendJsonResponse(response, result);
            } else {
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?success=updated");
            }
        } else {
            if (isAjax) {
                Map<String, Object> result = new HashMap<>();
                result.put("success", false);
                result.put("message", "更新失败");
                sendJsonResponse(response, result);
            } else {
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=update_failed");
            }
        }
    }
    
    /**
     * 充值
     */
    private void recharge(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/user/login.jsp?error=login_required");
            return;
        }
        
        String amountStr = request.getParameter("amount");
        
        try {
            BigDecimal amount = new BigDecimal(amountStr);
            
            // 验证金额范围
            if (amount.compareTo(BigDecimal.ZERO) <= 0 || amount.compareTo(new BigDecimal("10000")) > 0) {
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=充值金额必须在1-10000元之间");
                return;
            }
            
            boolean success = userService.recharge(currentUser.getUserId(), amount);
            
            if (success) {
                // 更新session中的用户信息
                User updatedUser = userService.getUserById(currentUser.getUserId());
                request.getSession().setAttribute("user", updatedUser);
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?success=recharge");
            } else {
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=充值失败");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=金额格式错误");
        }
    }
    
    /**
     * 提现
     */
    private void withdraw(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/user/login.jsp?error=login_required");
            return;
        }
        
        String amountStr = request.getParameter("amount");
        
        try {
            BigDecimal amount = new BigDecimal(amountStr);
            
            // 验证金额范围
            if (amount.compareTo(BigDecimal.ZERO) <= 0 || amount.compareTo(currentUser.getBalance()) > 0) {
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=提现金额不能超过当前余额");
                return;
            }
            
            boolean success = userService.withdrawBalance(currentUser.getUserId(), amount);
            
            if (success) {
                // 更新session中的用户信息
                User updatedUser = userService.getUserById(currentUser.getUserId());
                request.getSession().setAttribute("user", updatedUser);
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?success=withdraw");
            } else {
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=提现失败，余额不足");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=金额格式错误");
        }
    }
    
    /**
     * 获取用户列表（管理员功能）
     */
    private void getUserList(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null || currentUser.getUserType() != 3) {
            result.put("success", false);
            result.put("message", "权限不足");
            sendJsonResponse(response, result);
            return;
        }
        
        List<User> users = userService.getAllUsers();
        result.put("success", true);
        result.put("users", users);
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 更新用户信用分数（管理员功能）
     */
    private void updateCredit(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null || currentUser.getUserType() != 3) {
            result.put("success", false);
            result.put("message", "权限不足");
            sendJsonResponse(response, result);
            return;
        }
        
        String userIdStr = request.getParameter("userId");
        String creditScoreStr = request.getParameter("creditScore");
        
        try {
            Integer userId = Integer.parseInt(userIdStr);
            Integer creditScore = Integer.parseInt(creditScoreStr);
            
            boolean success = userService.updateCreditScore(userId, creditScore);
            
            if (success) {
                result.put("success", true);
                result.put("message", "更新成功");
            } else {
                result.put("success", false);
                result.put("message", "更新失败");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "参数格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 拉黑用户（管理员功能）
     */
    private void blacklistUser(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null || currentUser.getUserType() != 3) {
            result.put("success", false);
            result.put("message", "权限不足");
            sendJsonResponse(response, result);
            return;
        }
        
        String userIdStr = request.getParameter("userId");
        
        try {
            Integer userId = Integer.parseInt(userIdStr);
            boolean success = userService.blacklistUser(userId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "拉黑成功");
            } else {
                result.put("success", false);
                result.put("message", "拉黑失败");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "用户ID格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 解封用户（管理员功能）
     */
    private void unblacklistUser(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null || currentUser.getUserType() != 3) {
            result.put("success", false);
            result.put("message", "权限不足");
            sendJsonResponse(response, result);
            return;
        }
        
        String userIdStr = request.getParameter("userId");
        
        try {
            Integer userId = Integer.parseInt(userIdStr);
            boolean success = userService.unblacklistUser(userId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "解封成功");
            } else {
                result.put("success", false);
                result.put("message", "解封失败");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "用户ID格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 检查用户名是否可用
     */
    private void checkUsername(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String username = request.getParameter("username");
        Map<String, Object> result = new HashMap<>();
        
        if (username == null || username.trim().isEmpty()) {
            result.put("available", false);
            result.put("message", "用户名不能为空");
        } else {
            boolean available = userService.isUsernameAvailable(username);
            result.put("available", available);
            result.put("message", available ? "用户名可用" : "用户名已存在");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 修改密码
     */
    private void changePassword(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        
        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/user/login.jsp?error=login_required");
            return;
        }
        
        String oldPassword = request.getParameter("oldPassword");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");
        
        if (oldPassword == null || newPassword == null || confirmPassword == null) {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=参数不完整");
            return;
        }
        
        // 验证新密码长度
        if (newPassword.length() < 6) {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=密码长度至少6位");
            return;
        }
        
        // 验证新密码确认
        if (!newPassword.equals(confirmPassword)) {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=两次输入的密码不一致");
            return;
        }
        
        boolean success = userService.changePassword(currentUser.getUserId(), oldPassword, newPassword);
        
        if (success) {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?success=password_changed");
        } else {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?error=原密码错误");
        }
    }
    
    /**
     * 获取当前登录用户
     */
    private User getCurrentUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            return (User) session.getAttribute("user");
        }
        return null;
    }
    
    /**
     * 发送JSON响应
     */
    private void sendJsonResponse(HttpServletResponse response, Object data) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(data));
        out.flush();
    }
}