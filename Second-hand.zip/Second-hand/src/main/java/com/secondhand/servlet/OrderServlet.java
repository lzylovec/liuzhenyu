package com.secondhand.servlet;

import com.google.gson.Gson;
import com.secondhand.entity.Order;
import com.secondhand.entity.User;
import com.secondhand.service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 订单相关的Servlet
 */
public class OrderServlet extends HttpServlet {
    private OrderService orderService;
    private Gson gson;
    
    @Override
    public void init() throws ServletException {
        orderService = new OrderService();
        gson = new Gson();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/list":
                getOrderList(request, response);
                break;
            case "/detail":
                getOrderDetail(request, response);
                break;
            case "/myOrders":
                getMyOrders(request, response);
                break;
            case "/sellerOrders":
                getSellerOrders(request, response);
                break;
            case "/allOrders":
                getAllOrders(request, response);
                break;
            case "/statistics":
                getOrderStatistics(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        
        if (pathInfo == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        switch (pathInfo) {
            case "/create":
                createOrder(request, response);
                break;
            case "/pay":
                payOrder(request, response);
                break;
            case "/ship":
                shipOrder(request, response);
                break;
            case "/confirm":
                confirmOrder(request, response);
                break;
            case "/cancel":
                cancelOrder(request, response);
                break;
            case "/delete":
                deleteOrder(request, response);
                break;
            case "/updateAddress":
                updateOrderAddress(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    /**
     * 创建订单
     */
    private void createOrder(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        if (currentUser.getUserType() != 1) {
            result.put("success", false);
            result.put("message", "只有普通用户可以下单");
            sendJsonResponse(response, result);
            return;
        }
        
        String productIdStr = request.getParameter("productId");
        String quantityStr = request.getParameter("quantity");
        String shippingAddress = request.getParameter("shippingAddress");
        String contactPhone = request.getParameter("contactPhone");
        
        try {
            Integer productId = Integer.parseInt(productIdStr);
            Integer quantity = Integer.parseInt(quantityStr);
            
            String orderNumber = orderService.createOrder(currentUser.getUserId(), productId, quantity, shippingAddress, contactPhone);
            
            if (orderNumber != null) {
                result.put("success", true);
                result.put("message", "订单创建成功");
                result.put("orderNumber", orderNumber);
            } else {
                result.put("success", false);
                result.put("message", "订单创建失败");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "参数格式错误");
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", e.getMessage());
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 支付订单
     */
    private void payOrder(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String orderNumber = request.getParameter("orderNumber");
        
        try {
            boolean success = orderService.payOrder(orderNumber, currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "支付成功");
            } else {
                result.put("success", false);
                result.put("message", "支付失败，请检查余额或订单状态");
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", e.getMessage());
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 发货
     */
    private void shipOrder(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String orderNumber = request.getParameter("orderNumber");
        
        try {
            // 首先根据订单号获取订单
            Order order = orderService.getOrderByOrderNo(orderNumber);
            if (order == null) {
                result.put("success", false);
                result.put("message", "订单不存在");
                sendJsonResponse(response, result);
                return;
            }
            
            boolean success = orderService.shipOrder(order.getOrderId(), currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "发货成功");
            } else {
                result.put("success", false);
                result.put("message", "发货失败，请检查订单状态");
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", e.getMessage());
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 确认收货
     */
    private void confirmOrder(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String orderNumber = request.getParameter("orderNumber");
        
        try {
            // 首先根据订单号获取订单
            Order order = orderService.getOrderByOrderNo(orderNumber);
            if (order == null) {
                result.put("success", false);
                result.put("message", "订单不存在");
                sendJsonResponse(response, result);
                return;
            }
            
            boolean success = orderService.confirmOrder(order.getOrderId(), currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "确认收货成功");
            } else {
                result.put("success", false);
                result.put("message", "确认收货失败，请检查订单状态");
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", e.getMessage());
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 取消订单
     */
    private void cancelOrder(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String orderNumber = request.getParameter("orderNumber");
        
        try {
            // 首先根据订单号获取订单
            Order order = orderService.getOrderByOrderNo(orderNumber);
            if (order == null) {
                result.put("success", false);
                result.put("message", "订单不存在");
                sendJsonResponse(response, result);
                return;
            }
            
            boolean success = orderService.cancelOrder(order.getOrderId(), currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "订单取消成功");
            } else {
                result.put("success", false);
                result.put("message", "订单取消失败，请检查订单状态");
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", e.getMessage());
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 删除订单
     */
    private void deleteOrder(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String orderNumber = request.getParameter("orderNumber");
        
        try {
            // 首先根据订单号获取订单
            Order order = orderService.getOrderByOrderNo(orderNumber);
            if (order == null) {
                result.put("success", false);
                result.put("message", "订单不存在");
                sendJsonResponse(response, result);
                return;
            }
            
            boolean success = orderService.deleteOrder(order.getOrderId(), currentUser.getUserId());
            
            if (success) {
                result.put("success", true);
                result.put("message", "订单删除成功");
            } else {
                result.put("success", false);
                result.put("message", "订单删除失败");
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", e.getMessage());
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 更新订单地址
     */
    private void updateOrderAddress(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        String orderIdStr = request.getParameter("orderId");
        String shippingAddress = request.getParameter("shippingAddress");
        String contactPhone = request.getParameter("contactPhone");
        
        try {
            Integer orderId = Integer.parseInt(orderIdStr);
            
            boolean success = orderService.updateShippingAddress(orderId, currentUser.getUserId(), shippingAddress, contactPhone);
            
            if (success) {
                result.put("success", true);
                result.put("message", "地址更新成功");
            } else {
                result.put("success", false);
                result.put("message", "地址更新失败，请检查订单状态");
            }
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "订单ID格式错误");
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", e.getMessage());
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取订单列表（根据状态）
     */
    private void getOrderList(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String statusStr = request.getParameter("status");
        Map<String, Object> result = new HashMap<>();
        
        try {
            List<Order> orders;
            if (statusStr != null && !statusStr.isEmpty()) {
                Integer status = Integer.parseInt(statusStr);
                orders = orderService.getOrdersByStatus(status);
            } else {
                orders = orderService.getAllOrders();
            }
            
            result.put("success", true);
            result.put("orders", orders);
        } catch (NumberFormatException e) {
            result.put("success", false);
            result.put("message", "状态参数格式错误");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取订单详情
     */
    private void getOrderDetail(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String orderNumber = request.getParameter("orderNumber");
        Map<String, Object> result = new HashMap<>();
        
        Order order = orderService.getOrderByOrderNo(orderNumber);
        
        if (order != null) {
            result.put("success", true);
            result.put("order", order);
        } else {
            result.put("success", false);
            result.put("message", "订单不存在");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取我的订单
     */
    private void getMyOrders(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        List<Order> orders = orderService.getUserOrders(currentUser.getUserId());
        result.put("success", true);
        result.put("orders", orders);
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取卖家订单
     */
    private void getSellerOrders(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        if (currentUser.getUserType() != 2 && currentUser.getUserType() != 3) {
            result.put("success", false);
            result.put("message", "只有商家可以查看卖家订单");
            sendJsonResponse(response, result);
            return;
        }
        
        List<Order> orders = orderService.getSellerOrders(currentUser.getUserId());
        result.put("success", true);
        result.put("orders", orders);
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取所有订单（管理员）
     */
    private void getAllOrders(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        if (currentUser.getUserType() != 3) {
            result.put("success", false);
            result.put("message", "只有管理员可以查看所有订单");
            sendJsonResponse(response, result);
            return;
        }
        
        List<Order> orders = orderService.getAllOrders();
        result.put("success", true);
        result.put("orders", orders);
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取订单统计信息
     */
    private void getOrderStatistics(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        User currentUser = getCurrentUser(request);
        Map<String, Object> result = new HashMap<>();
        
        if (currentUser == null) {
            result.put("success", false);
            result.put("message", "请先登录");
            sendJsonResponse(response, result);
            return;
        }
        
        if (currentUser.getUserType() == 1) {
            // 普通用户统计
            // 获取用户订单统计
                List<Order> userOrders = orderService.getUserOrders(currentUser.getUserId());
                OrderService.OrderStatistics stats = calculateUserOrderStatistics(userOrders);
            result.put("success", true);
            result.put("statistics", stats);
        } else if (currentUser.getUserType() == 2) {
            // 商家统计
            // 获取卖家订单统计
                List<Order> sellerOrders = orderService.getSellerOrders(currentUser.getUserId());
                OrderService.OrderStatistics stats = calculateSellerOrderStatistics(sellerOrders);
            result.put("success", true);
            result.put("statistics", stats);
        } else if (currentUser.getUserType() == 3) {
            // 管理员统计
            // 获取整体订单统计
                OrderService.OrderStatistics stats = orderService.getOrderStatistics();
            result.put("success", true);
            result.put("statistics", stats);
        } else {
            result.put("success", false);
            result.put("message", "无权限查看统计信息");
        }
        
        sendJsonResponse(response, result);
    }
    
    /**
     * 获取当前登录用户
     */
    private User getCurrentUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            return (User) session.getAttribute("user");
        }
        return null;
    }
    
    /**
     * 发送JSON响应
     */
    private void sendJsonResponse(HttpServletResponse response, Object data) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(data));
        out.flush();
    }
    
    /**
     * 计算用户订单统计
     */
    private OrderService.OrderStatistics calculateUserOrderStatistics(List<Order> orders) {
        long totalOrders = orders.size();
        long pendingOrders = orders.stream().filter(o -> o.getStatus() == 1).count();
        long paidOrders = orders.stream().filter(o -> o.getStatus() == 2).count();
        long shippedOrders = orders.stream().filter(o -> o.getStatus() == 3).count();
        long completedOrders = orders.stream().filter(o -> o.getStatus() == 4).count();
        long cancelledOrders = orders.stream().filter(o -> o.getStatus() == 5).count();
        
        BigDecimal totalAmount = orders.stream()
                .filter(order -> order.getStatus() >= 2)
                .map(Order::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        return new OrderService.OrderStatistics(totalOrders, pendingOrders, paidOrders, 
                                               shippedOrders, completedOrders, cancelledOrders, totalAmount);
    }
    
    /**
     * 计算卖家订单统计
     */
    private OrderService.OrderStatistics calculateSellerOrderStatistics(List<Order> orders) {
        long totalOrders = orders.size();
        long pendingOrders = orders.stream().filter(o -> o.getStatus() == 1).count();
        long paidOrders = orders.stream().filter(o -> o.getStatus() == 2).count();
        long shippedOrders = orders.stream().filter(o -> o.getStatus() == 3).count();
        long completedOrders = orders.stream().filter(o -> o.getStatus() == 4).count();
        long cancelledOrders = orders.stream().filter(o -> o.getStatus() == 5).count();
        
        BigDecimal totalAmount = orders.stream()
                .filter(order -> order.getStatus() >= 2)
                .map(Order::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        return new OrderService.OrderStatistics(totalOrders, pendingOrders, paidOrders, 
                                               shippedOrders, completedOrders, cancelledOrders, totalAmount);
    }
}