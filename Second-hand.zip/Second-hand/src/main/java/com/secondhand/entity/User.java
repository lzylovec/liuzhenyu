package com.secondhand.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * 用户实体类
 */
public class User {
    private Integer userId;          // 对应数据库的user_id
    private String username;
    private String password;
    private String email;
    private String phone;
    private String realName;         // 对应数据库的real_name
    private String address;          // 对应数据库的address
    private Integer userType;        // 对应数据库的user_type: 1-普通用户，2-商家，3-管理员
    private BigDecimal balance;      // 对应数据库的balance
    private Integer creditScore;     // 对应数据库的credit_score
    private Integer status;          // 对应数据库的status: 1-正常，0-拉黑
    private Timestamp createTime;    // 对应数据库的created_at
    private Timestamp updateTime;    // 对应数据库的updated_at
    
    public User() {}
    
    public User(String username, String password, String email, String phone) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.phone = phone;
        this.userType = 1; // 默认普通用户
        this.balance = BigDecimal.ZERO; // 默认余额为0
        this.creditScore = 100; // 默认信用分100
        this.status = 1; // 默认正常状态
    }
    
    public User(String username, String password, String email, String phone, String realName, Integer userType) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.phone = phone;
        this.realName = realName;
        this.userType = userType != null ? userType : 1;
        this.balance = BigDecimal.ZERO;
        this.creditScore = 100;
        this.status = 1;
    }
    
    // Getters and Setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public String getRealName() { return realName; }
    public void setRealName(String realName) { this.realName = realName; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public Integer getUserType() { return userType; }
    public void setUserType(Integer userType) { this.userType = userType; }
    
    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }
    
    public Integer getCreditScore() { return creditScore; }
    public void setCreditScore(Integer creditScore) { this.creditScore = creditScore; }
    
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    
    public Timestamp getCreateTime() { return createTime; }
    public void setCreateTime(Timestamp createTime) { this.createTime = createTime; }
    
    public Timestamp getUpdateTime() { return updateTime; }
    public void setUpdateTime(Timestamp updateTime) { this.updateTime = updateTime; }
    
    // 便利方法
    /**
     * 获取用户类型描述
     */
    public String getUserTypeDesc() {
        switch (userType) {
            case 1: return "普通用户";
            case 2: return "商家";
            case 3: return "管理员";
            default: return "未知";
        }
    }
    
    /**
     * 获取用户状态描述
     */
    public String getStatusDesc() {
        return status == 1 ? "正常" : "禁用";
    }
    
    /**
     * 检查用户是否为管理员
     */
    public boolean isAdmin() {
        return userType != null && userType == 3;
    }
    
    /**
     * 检查用户是否为商家
     */
    public boolean isMerchant() {
        return userType != null && userType == 2;
    }
    
    /**
     * 检查用户状态是否正常
     */
    public boolean isActive() {
        return status != null && status == 1;
    }
    
    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", userType=" + userType +
                ", balance=" + balance +
                ", creditScore=" + creditScore +
                ", status=" + status +
                '}';
    }
} 