package com.secondhand.filter;

import com.google.gson.Gson;
import com.secondhand.entity.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * 登录验证过滤器
 * 验证用户是否已登录，未登录则返回错误信息
 */
@WebFilter({
    "/user/profile", "/user/updateProfile", "/user/recharge", "/user/withdraw", "/user/changePassword",
    "/product/add", "/product/update", "/product/delete", "/product/publish", "/product/unpublish", "/product/myProducts",
    "/order/*"
})
public class AuthFilter implements Filter {
    
    private Gson gson;
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        gson = new Gson();
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        // 获取当前用户会话
        HttpSession session = httpRequest.getSession(false);
        User currentUser = null;
        
        if (session != null) {
            currentUser = (User) session.getAttribute("user");
        }
        
        // 检查用户是否已登录
        if (currentUser == null) {
            // 用户未登录，返回错误信息
            sendUnauthorizedResponse(httpResponse, "请先登录");
            return;
        }
        
        // 检查用户状态是否正常
        if (currentUser.getStatus() != 1) {
            // 用户被拉黑，返回错误信息
            sendUnauthorizedResponse(httpResponse, "账户已被禁用，请联系管理员");
            return;
        }
        
        // 用户已登录且状态正常，继续执行
        chain.doFilter(request, response);
    }
    
    @Override
    public void destroy() {
        // 清理资源
    }
    
    /**
     * 发送未授权响应
     */
    private void sendUnauthorizedResponse(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        result.put("success", false);
        result.put("message", message);
        result.put("code", "UNAUTHORIZED");
        
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(result));
        out.flush();
    }
}