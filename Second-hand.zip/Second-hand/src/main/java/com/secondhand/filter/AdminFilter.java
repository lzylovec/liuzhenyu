package com.secondhand.filter;

import com.google.gson.Gson;
import com.secondhand.entity.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * 管理员权限过滤器
 * 验证用户是否具有管理员权限
 */
@WebFilter({
    "/user/list", "/user/updateCredit", "/user/ban", "/user/unban",
    "/order/allOrders"
})
public class AdminFilter implements Filter {
    
    private Gson gson;
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        gson = new Gson();
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        // 获取当前用户会话
        HttpSession session = httpRequest.getSession(false);
        User currentUser = null;
        
        if (session != null) {
            currentUser = (User) session.getAttribute("user");
        }
        
        // 检查用户是否已登录
        if (currentUser == null) {
            sendForbiddenResponse(httpResponse, "请先登录");
            return;
        }
        
        // 检查用户是否为管理员
        if (currentUser.getUserType() != 3) {
            sendForbiddenResponse(httpResponse, "权限不足，只有管理员可以访问");
            return;
        }
        
        // 检查用户状态是否正常
        if (currentUser.getStatus() != 1) {
            sendForbiddenResponse(httpResponse, "账户已被禁用");
            return;
        }
        
        // 用户具有管理员权限，继续执行
        chain.doFilter(request, response);
    }
    
    @Override
    public void destroy() {
        // 清理资源
    }
    
    /**
     * 发送权限不足响应
     */
    private void sendForbiddenResponse(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        Map<String, Object> result = new HashMap<>();
        result.put("success", false);
        result.put("message", message);
        result.put("code", "FORBIDDEN");
        
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(result));
        out.flush();
    }
}