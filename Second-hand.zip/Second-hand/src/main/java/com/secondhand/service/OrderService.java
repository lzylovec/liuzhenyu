package com.secondhand.service;

import com.secondhand.dao.OrderDAO;
import com.secondhand.dao.ProductDAO;
import com.secondhand.dao.UserDAO;
import com.secondhand.entity.Order;
import com.secondhand.entity.Product;
import com.secondhand.entity.User;

import java.math.BigDecimal;
import java.util.List;

/**
 * 订单服务类
 */
public class OrderService {
    private OrderDAO orderDAO;
    private ProductDAO productDAO;
    private UserDAO userDAO;
    private UserService userService;
    private ProductService productService;
    
    public OrderService() {
        this.orderDAO = new OrderDAO();
        this.productDAO = new ProductDAO();
        this.userDAO = new UserDAO();
        this.userService = new UserService();
        this.productService = new ProductService();
    }
    
    /**
     * 创建订单
     */
    public String createOrder(Integer userId, Integer productId, Integer quantity, String shippingAddress, String phone) {
        // 验证用户
        User user = userDAO.findById(userId);
        if (user == null || user.getStatus() == 0) {
            return null;
        }
        
        // 验证商品
        Product product = productDAO.findById(productId);
        if (product == null || product.getStatus() == 0) {
            return null;
        }
        
        // 检查库存
        if (product.getStock() < quantity || quantity <= 0) {
            return null;
        }
        
        // 不能购买自己的商品
        if (product.getSellerId().equals(userId)) {
            return null;
        }
        
        // 生成订单号
        String orderNo = orderDAO.generateOrderNo();
        
        // 获取用户和卖家信息
        User seller = userDAO.findById(product.getSellerId());
        if (seller == null) {
            return null;
        }
        
        // 创建订单
        Order order = new Order(orderNo, userId, productId, product.getSellerId(), 
                               quantity, product.getPrice(), shippingAddress, phone);
        
        // 设置关联信息
        order.setUserName(user.getUsername());
        order.setProductName(product.getProductName());
        order.setSellerName(seller.getUsername());
        
        if (orderDAO.createOrder(order)) {
            return orderNo;
        }
        return null;
    }
    
    /**
     * 支付订单
     */
    public boolean payOrder(String orderNo, Integer userId) {
        Order order = orderDAO.findByOrderNo(orderNo);
        if (order == null || !order.getUserId().equals(userId) || order.getStatus() != 1) {
            return false;
        }
        
        // 检查用户余额
        User user = userDAO.findById(userId);
        if (user == null || user.getBalance().compareTo(order.getTotalAmount()) < 0) {
            return false;
        }
        
        // 再次检查库存
        Product product = productDAO.findById(order.getProductId());
        if (product == null || product.getStock() < order.getQuantity()) {
            return false;
        }
        
        try {
            // 扣除买家余额
            if (!userService.deductBalance(userId, order.getTotalAmount())) {
                return false;
            }
            
            // 增加卖家余额
            if (!userService.addBalance(order.getSellerId(), order.getTotalAmount())) {
                // 回滚买家余额
                userService.addBalance(userId, order.getTotalAmount());
                return false;
            }
            
            // 减少商品库存
            if (!productService.reduceStock(order.getProductId(), order.getQuantity())) {
                // 回滚余额变动
                userService.addBalance(userId, order.getTotalAmount());
                userService.deductBalance(order.getSellerId(), order.getTotalAmount());
                return false;
            }
            
            // 更新订单状态为已支付
            return orderDAO.updateStatus(order.getOrderId(), 2);
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 发货
     */
    public boolean shipOrder(Integer orderId, Integer sellerId) {
        Order order = orderDAO.findById(orderId);
        if (order == null || !order.getSellerId().equals(sellerId) || order.getStatus() != 2) {
            return false;
        }
        
        return orderDAO.updateStatus(orderId, 3);
    }
    
    /**
     * 确认收货
     */
    public boolean confirmOrder(Integer orderId, Integer userId) {
        Order order = orderDAO.findById(orderId);
        if (order == null || !order.getUserId().equals(userId) || order.getStatus() != 3) {
            return false;
        }
        
        return orderDAO.updateStatus(orderId, 4);
    }
    
    /**
     * 取消订单
     */
    public boolean cancelOrder(Integer orderId, Integer userId) {
        Order order = orderDAO.findById(orderId);
        if (order == null || !order.getUserId().equals(userId)) {
            return false;
        }
        
        // 只有待支付状态的订单可以取消
        if (order.getStatus() != 1) {
            return false;
        }
        
        return orderDAO.updateStatus(orderId, 5);
    }
    
    /**
     * 删除订单（仅限待支付状态）
     */
    public boolean deleteOrder(Integer orderId, Integer userId) {
        return orderDAO.deleteOrder(orderId, userId);
    }
    
    /**
     * 更新收货地址
     */
    public boolean updateShippingAddress(Integer orderId, Integer userId, String address, String phone) {
        Order order = orderDAO.findById(orderId);
        if (order == null || !order.getUserId().equals(userId)) {
            return false;
        }
        
        // 只有待支付和已支付状态的订单可以修改地址
        if (order.getStatus() != 1 && order.getStatus() != 2) {
            return false;
        }
        
        return orderDAO.updateShippingAddress(orderId, address, phone);
    }
    
    /**
     * 根据订单号获取订单
     */
    public Order getOrderByOrderNo(String orderNo) {
        return orderDAO.findByOrderNo(orderNo);
    }
    
    /**
     * 根据订单ID获取订单
     */
    public Order getOrderById(Integer orderId) {
        return orderDAO.findById(orderId);
    }
    
    /**
     * 获取用户订单列表
     */
    public List<Order> getUserOrders(Integer userId) {
        return orderDAO.findByUserId(userId);
    }
    
    /**
     * 获取卖家订单列表
     */
    public List<Order> getSellerOrders(Integer sellerId) {
        return orderDAO.findBySellerId(sellerId);
    }
    
    /**
     * 获取所有订单（管理员功能）
     */
    public List<Order> getAllOrders() {
        return orderDAO.findAllOrders();
    }
    
    /**
     * 根据状态获取订单列表
     */
    public List<Order> getOrdersByStatus(Integer status) {
        return orderDAO.findByStatus(status);
    }
    
    /**
     * 获取用户特定状态的订单
     */
    public List<Order> getUserOrdersByStatus(Integer userId, Integer status) {
        List<Order> userOrders = orderDAO.findByUserId(userId);
        return userOrders.stream()
                .filter(order -> order.getStatus().equals(status))
                .collect(java.util.stream.Collectors.toList());
    }
    
    /**
     * 获取卖家特定状态的订单
     */
    public List<Order> getSellerOrdersByStatus(Integer sellerId, Integer status) {
        List<Order> sellerOrders = orderDAO.findBySellerId(sellerId);
        return sellerOrders.stream()
                .filter(order -> order.getStatus().equals(status))
                .collect(java.util.stream.Collectors.toList());
    }
    
    /**
     * 验证订单所有权
     */
    public boolean isOrderOwner(Integer orderId, Integer userId) {
        Order order = orderDAO.findById(orderId);
        return order != null && order.getUserId().equals(userId);
    }
    
    /**
     * 验证订单卖家
     */
    public boolean isOrderSeller(Integer orderId, Integer sellerId) {
        Order order = orderDAO.findById(orderId);
        return order != null && order.getSellerId().equals(sellerId);
    }
    
    /**
     * 计算用户总消费金额
     */
    public BigDecimal getUserTotalSpent(Integer userId) {
        List<Order> orders = orderDAO.findByUserId(userId);
        return orders.stream()
                .filter(order -> order.getStatus() >= 2) // 已支付及以上状态
                .map(Order::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    /**
     * 计算卖家总收入
     */
    public BigDecimal getSellerTotalIncome(Integer sellerId) {
        List<Order> orders = orderDAO.findBySellerId(sellerId);
        return orders.stream()
                .filter(order -> order.getStatus() >= 2) // 已支付及以上状态
                .map(Order::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    /**
     * 获取订单统计信息
     */
    public OrderStatistics getOrderStatistics() {
        List<Order> allOrders = orderDAO.findAllOrders();
        
        long totalOrders = allOrders.size();
        long pendingOrders = allOrders.stream().filter(o -> o.getStatus() == 1).count();
        long paidOrders = allOrders.stream().filter(o -> o.getStatus() == 2).count();
        long shippedOrders = allOrders.stream().filter(o -> o.getStatus() == 3).count();
        long completedOrders = allOrders.stream().filter(o -> o.getStatus() == 4).count();
        long cancelledOrders = allOrders.stream().filter(o -> o.getStatus() == 5).count();
        
        BigDecimal totalAmount = allOrders.stream()
                .filter(order -> order.getStatus() >= 2)
                .map(Order::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        return new OrderStatistics(totalOrders, pendingOrders, paidOrders, shippedOrders, 
                                 completedOrders, cancelledOrders, totalAmount);
    }
    
    /**
     * 订单统计信息内部类
     */
    public static class OrderStatistics {
        private long totalOrders;
        private long pendingOrders;
        private long paidOrders;
        private long shippedOrders;
        private long completedOrders;
        private long cancelledOrders;
        private BigDecimal totalAmount;
        
        public OrderStatistics(long totalOrders, long pendingOrders, long paidOrders, 
                             long shippedOrders, long completedOrders, long cancelledOrders, 
                             BigDecimal totalAmount) {
            this.totalOrders = totalOrders;
            this.pendingOrders = pendingOrders;
            this.paidOrders = paidOrders;
            this.shippedOrders = shippedOrders;
            this.completedOrders = completedOrders;
            this.cancelledOrders = cancelledOrders;
            this.totalAmount = totalAmount;
        }
        
        // Getters
        public long getTotalOrders() { return totalOrders; }
        public long getPendingOrders() { return pendingOrders; }
        public long getPaidOrders() { return paidOrders; }
        public long getShippedOrders() { return shippedOrders; }
        public long getCompletedOrders() { return completedOrders; }
        public long getCancelledOrders() { return cancelledOrders; }
        public BigDecimal getTotalAmount() { return totalAmount; }
    }
}