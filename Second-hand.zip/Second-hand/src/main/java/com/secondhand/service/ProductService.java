package com.secondhand.service;

import com.secondhand.dao.ProductDAO;
import com.secondhand.entity.Product;

import java.math.BigDecimal;
import java.util.List;

/**
 * 商品服务类
 */
public class ProductService {
    private ProductDAO productDAO;
    
    public ProductService() {
        this.productDAO = new ProductDAO();
    }
    
    /**
     * 添加商品
     */
    public boolean addProduct(String productName, String description, BigDecimal price, 
                             Integer stock, String category, String imageUrl, Integer sellerId) {
        if (productName == null || productName.trim().isEmpty() || 
            price == null || price.compareTo(BigDecimal.ZERO) <= 0 || 
            stock == null || stock < 0 || sellerId == null) {
            return false;
        }
        
        Product product = new Product(productName.trim(), description, price, stock, category, sellerId);
        product.setImageUrl(imageUrl);
        
        return productDAO.addProduct(product);
    }
    
    /**
     * 根据ID获取商品
     */
    public Product getProductById(Integer productId) {
        return productDAO.findById(productId);
    }
    
    /**
     * 更新商品信息
     */
    public boolean updateProduct(Integer productId, String productName, String description, 
                                BigDecimal price, Integer stock, String category, String imageUrl, Integer sellerId) {
        Product product = productDAO.findById(productId);
        if (product == null || !product.getSellerId().equals(sellerId)) {
            return false;
        }
        
        if (productName == null || productName.trim().isEmpty() || 
            price == null || price.compareTo(BigDecimal.ZERO) <= 0 || 
            stock == null || stock < 0) {
            return false;
        }
        
        product.setProductName(productName.trim());
        product.setDescription(description);
        product.setPrice(price);
        product.setStock(stock);
        product.setCategory(category);
        product.setImageUrl(imageUrl);
        
        return productDAO.updateProduct(product);
    }
    
    /**
     * 上架商品
     */
    public boolean publishProduct(Integer productId, Integer sellerId) {
        Product product = productDAO.findById(productId);
        if (product == null || !product.getSellerId().equals(sellerId)) {
            return false;
        }
        
        return productDAO.updateStatus(productId, 1);
    }
    
    /**
     * 下架商品
     */
    public boolean unpublishProduct(Integer productId, Integer sellerId) {
        Product product = productDAO.findById(productId);
        if (product == null || !product.getSellerId().equals(sellerId)) {
            return false;
        }
        
        return productDAO.updateStatus(productId, 0);
    }
    
    /**
     * 更新商品状态
     */
    public boolean updateProductStatus(Integer productId, Integer status, Integer sellerId) {
        Product product = productDAO.findById(productId);
        if (product == null || !product.getSellerId().equals(sellerId)) {
            return false;
        }
        
        return productDAO.updateStatus(productId, status);
    }
    
    /**
     * 删除商品
     */
    public boolean deleteProduct(Integer productId, Integer sellerId) {
        Product product = productDAO.findById(productId);
        if (product == null || !product.getSellerId().equals(sellerId)) {
            return false;
        }
        
        return productDAO.deleteProduct(productId);
    }
    
    /**
     * 减少库存
     */
    public boolean reduceStock(Integer productId, Integer quantity) {
        Product product = productDAO.findById(productId);
        if (product == null || product.getStock() < quantity || quantity <= 0) {
            return false;
        }
        
        int newStock = product.getStock() - quantity;
        return productDAO.updateStock(productId, newStock);
    }
    
    /**
     * 增加库存
     */
    public boolean addStock(Integer productId, Integer quantity, Integer sellerId) {
        Product product = productDAO.findById(productId);
        if (product == null || !product.getSellerId().equals(sellerId) || quantity <= 0) {
            return false;
        }
        
        int newStock = product.getStock() + quantity;
        return productDAO.updateStock(productId, newStock);
    }
    
    /**
     * 检查库存是否充足
     */
    public boolean checkStock(Integer productId, Integer quantity) {
        Product product = productDAO.findById(productId);
        return product != null && product.getStatus() == 1 && product.getStock() >= quantity;
    }
    
    /**
     * 获取所有商品列表
     */
    public List<Product> getAllProducts() {
        return productDAO.findAllProducts();
    }
    
    /**
     * 根据卖家ID获取商品列表
     */
    public List<Product> getProductsBySeller(Integer sellerId) {
        return productDAO.findBySellerId(sellerId);
    }
    
    /**
     * 根据分类获取商品列表
     */
    public List<Product> getProductsByCategory(String category) {
        return productDAO.findByCategory(category);
    }
    
    /**
     * 搜索商品
     */
    public List<Product> searchProducts(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllProducts();
        }
        return productDAO.searchProducts(keyword.trim());
    }
    
    /**
     * 获取商品分类列表
     */
    public List<String> getCategories() {
        return productDAO.getCategories();
    }
    
    /**
     * 验证商品所有权
     */
    public boolean isProductOwner(Integer productId, Integer sellerId) {
        Product product = productDAO.findById(productId);
        return product != null && product.getSellerId().equals(sellerId);
    }
    
    /**
     * 获取热门商品（按创建时间排序，取前N个）
     */
    public List<Product> getPopularProducts(int limit) {
        List<Product> allProducts = getAllProducts();
        if (allProducts.size() <= limit) {
            return allProducts;
        }
        return allProducts.subList(0, limit);
    }
    
    /**
     * 按价格范围筛选商品
     */
    public List<Product> getProductsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice) {
        List<Product> allProducts = getAllProducts();
        return allProducts.stream()
                .filter(product -> {
                    BigDecimal price = product.getPrice();
                    return (minPrice == null || price.compareTo(minPrice) >= 0) &&
                           (maxPrice == null || price.compareTo(maxPrice) <= 0);
                })
                .collect(java.util.stream.Collectors.toList());
    }
    
    /**
     * 验证商品信息
     */
    public String validateProduct(String productName, String description, BigDecimal price, Integer stock, String category) {
        if (productName == null || productName.trim().isEmpty()) {
            return "商品名称不能为空";
        }
        if (productName.length() > 100) {
            return "商品名称不能超过100个字符";
        }
        if (description != null && description.length() > 1000) {
            return "商品描述不能超过1000个字符";
        }
        if (price == null || price.compareTo(BigDecimal.ZERO) <= 0) {
            return "商品价格必须大于0";
        }
        if (price.compareTo(new BigDecimal("999999.99")) > 0) {
            return "商品价格不能超过999999.99";
        }
        if (stock == null || stock < 0) {
            return "商品库存不能为负数";
        }
        if (stock > 99999) {
            return "商品库存不能超过99999";
        }
        if (category == null || category.trim().isEmpty()) {
            return "商品分类不能为空";
        }
        return null; // 验证通过
    }
}