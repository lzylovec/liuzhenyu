package com.secondhand.service;

import com.secondhand.dao.UserDAO;
import com.secondhand.entity.User;
import org.mindrot.jbcrypt.BCrypt;

import java.math.BigDecimal;
import java.util.List;

/**
 * 用户服务类
 */
public class UserService {
    private UserDAO userDAO;
    
    public UserService() {
        this.userDAO = new UserDAO();
    }
    
    /**
     * 用户注册
     */
    public boolean register(String username, String password, String email, String phone, Integer userType) {
        // 检查用户名是否已存在
        if (userDAO.findByUsername(username) != null) {
            return false;
        }
        
        // 密码加密
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        
        // 创建用户对象
        User user = new User(username, hashedPassword, email, phone);
        if (userType != null) {
            user.setUserType(userType);
        }
        
        return userDAO.register(user);
    }
    
    /**
     * 用户登录
     */
    public User login(String username, String password) {
        User user = userDAO.findByUsername(username);
        if (user != null && BCrypt.checkpw(password, user.getPassword())) {
            // 检查用户状态
            if (user.getStatus() == 0) {
                return null; // 用户被拉黑
            }
            return user;
        }
        return null;
    }
    
    /**
     * 根据ID获取用户信息
     */
    public User getUserById(Integer userId) {
        return userDAO.findById(userId);
    }
    
    /**
     * 更新用户信息
     */
    public boolean updateUserInfo(Integer userId, String email, String phone, String realName, String address) {
        User user = userDAO.findById(userId);
        if (user == null) {
            return false;
        }
        
        user.setEmail(email);
        user.setPhone(phone);
        user.setRealName(realName);
        user.setAddress(address);
        
        return userDAO.updateUser(user);
    }
    
    /**
     * 充值余额
     */
    public boolean recharge(Integer userId, BigDecimal amount) {
        User user = userDAO.findById(userId);
        if (user == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        BigDecimal newBalance = user.getBalance().add(amount);
        return userDAO.updateBalance(userId, newBalance);
    }
    
    /**
     * 扣除余额
     */
    public boolean deductBalance(Integer userId, BigDecimal amount) {
        User user = userDAO.findById(userId);
        if (user == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        // 检查余额是否足够
        if (user.getBalance().compareTo(amount) < 0) {
            return false;
        }
        
        BigDecimal newBalance = user.getBalance().subtract(amount);
        return userDAO.updateBalance(userId, newBalance);
    }
    
    /**
     * 提取余额
     */
    public boolean withdrawBalance(Integer userId, BigDecimal amount) {
        User user = userDAO.findById(userId);
        if (user == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        // 检查余额是否足够
        if (user.getBalance().compareTo(amount) < 0) {
            return false;
        }
        
        BigDecimal newBalance = user.getBalance().subtract(amount);
        return userDAO.updateBalance(userId, newBalance);
    }
    
    /**
     * 增加余额（收款）
     */
    public boolean addBalance(Integer userId, BigDecimal amount) {
        User user = userDAO.findById(userId);
        if (user == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        BigDecimal newBalance = user.getBalance().add(amount);
        return userDAO.updateBalance(userId, newBalance);
    }
    
    /**
     * 更新信用分数（管理员功能）
     */
    public boolean updateCreditScore(Integer userId, Integer creditScore) {
        if (creditScore < 0 || creditScore > 100) {
            return false;
        }
        return userDAO.updateCreditScore(userId, creditScore);
    }
    
    /**
     * 拉黑用户（管理员功能）
     */
    public boolean blacklistUser(Integer userId) {
        return userDAO.updateStatus(userId, 0);
    }
    
    /**
     * 解封用户（管理员功能）
     */
    public boolean unblacklistUser(Integer userId) {
        return userDAO.updateStatus(userId, 1);
    }
    
    /**
     * 获取所有用户列表（管理员功能）
     */
    public List<User> getAllUsers() {
        return userDAO.findAllUsers();
    }
    
    /**
     * 根据用户类型获取用户列表
     */
    public List<User> getUsersByType(Integer userType) {
        return userDAO.findByUserType(userType);
    }
    
    /**
     * 验证用户权限
     */
    public boolean hasPermission(User user, String action) {
        if (user == null || user.getStatus() == 0) {
            return false;
        }
        
        switch (action) {
            case "ADMIN":
                return user.getUserType() == 3;
            case "SELLER":
                return user.getUserType() == 2 || user.getUserType() == 3;
            case "USER":
                return user.getUserType() >= 1;
            default:
                return false;
        }
    }
    
    /**
     * 检查用户名是否可用
     */
    public boolean isUsernameAvailable(String username) {
        return userDAO.findByUsername(username) == null;
    }
    
    /**
     * 修改密码
     */
    public boolean changePassword(Integer userId, String oldPassword, String newPassword) {
        User user = userDAO.findById(userId);
        if (user == null || !BCrypt.checkpw(oldPassword, user.getPassword())) {
            return false;
        }
        
        String hashedNewPassword = BCrypt.hashpw(newPassword, BCrypt.gensalt());
        user.setPassword(hashedNewPassword);
        
        return userDAO.updateUser(user);
    }
}