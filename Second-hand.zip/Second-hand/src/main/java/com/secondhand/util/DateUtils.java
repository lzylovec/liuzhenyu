package com.secondhand.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
    
    /**
     * 格式化日期
     * @param date 日期
     * @param pattern 格式模式
     * @return 格式化后的日期字符串
     */
    public static String formatDate(Date date, String pattern) {
        if (date == null) {
            return "";
        }
        if (pattern == null || pattern.trim().isEmpty()) {
            pattern = "yyyy-MM-dd HH:mm:ss";
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            return sdf.format(date);
        } catch (Exception e) {
            return "";
        }
    }
    
    /**
     * 使用默认格式（yyyy-MM-dd HH:mm:ss）格式化日期
     * @param date 日期
     * @return 格式化后的日期字符串
     */
    public static String formatDate(Date date) {
        return formatDate(date, "yyyy-MM-dd HH:mm:ss");
    }
} 