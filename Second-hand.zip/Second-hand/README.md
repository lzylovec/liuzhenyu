# 二手商城系统

基于 Java Servlet + JDBC + MySQL + JSP 的二手商城项目，支持用户、商家、管理员三种角色。

## 项目特性

### 用户角色
- **普通用户 (user_type=1)**：购买商品、管理订单、充值提现
- **商家 (user_type=2)**：发布商品、管理库存、处理订单、提取收益
- **管理员 (user_type=3)**：用户管理、订单监控、信用评分管理

### 核心功能

#### 用户管理
- 用户注册/登录（密码加密存储）
- 个人信息管理
- 余额充值/提现（虚拟支付）
- 信用分数系统
- 用户状态管理（正常/拉黑）

#### 商品管理
- 商品发布/编辑/删除
- 商品分类管理
- 库存管理
- 商品搜索/筛选
- 商品状态控制（上架/下架）

#### 订单管理
- 订单创建/支付/发货/确认收货
- 订单状态跟踪
- 收货地址修改
- 订单取消/删除
- 订单统计分析

#### 权限控制
- 基于角色的访问控制
- 登录状态验证
- 管理员权限验证
- 跨域请求支持

## 技术栈

- **后端框架**：Java Servlet 4.0
- **数据库**：MySQL 8.0
- **数据访问**：JDBC
- **前端技术**：JSP + JSTL
- **构建工具**：Maven
- **密码加密**：jBCrypt
- **JSON处理**：Gson
- **文件上传**：Commons FileUpload

## 项目结构

```
Second-hand/
├── src/main/java/com/secondhand/
│   ├── dao/                    # 数据访问层
│   │   ├── UserDAO.java
│   │   ├── ProductDAO.java
│   │   └── OrderDAO.java
│   ├── entity/                 # 实体类
│   │   ├── User.java
│   │   ├── Product.java
│   │   └── Order.java
│   ├── service/                # 业务逻辑层
│   │   ├── UserService.java
│   │   ├── ProductService.java
│   │   └── OrderService.java
│   ├── servlet/                # 控制层
│   │   ├── UserServlet.java
│   │   ├── ProductServlet.java
│   │   └── OrderServlet.java
│   ├── filter/                 # 过滤器
│   │   ├── CharacterEncodingFilter.java
│   │   ├── CorsFilter.java
│   │   ├── AuthFilter.java
│   │   └── AdminFilter.java
│   └── util/
│       └── DBUtil.java         # 数据库工具类
├── src/main/resources/
│   ├── db.properties           # 数据库配置
│   └── init.sql               # 数据库初始化脚本
├── src/main/webapp/
│   └── WEB-INF/
│       └── web.xml            # Web应用配置
├── pom.xml                    # Maven配置
└── README.md                  # 项目说明
```

## 数据库设计

### 用户表 (users)
- user_id: 用户ID（主键）
- username: 用户名（唯一）
- password: 密码（加密）
- email: 邮箱
- phone: 电话
- real_name: 真实姓名
- address: 地址
- user_type: 用户类型（1-普通用户，2-商家，3-管理员）
- balance: 余额
- credit_score: 信用分数
- status: 状态（1-正常，0-拉黑）
- created_at/updated_at: 时间戳

### 商品表 (products)
- product_id: 商品ID（主键）
- product_name: 商品名称
- description: 商品描述
- price: 价格
- stock: 库存
- category: 分类
- image_url: 图片URL
- seller_id: 卖家ID（外键）
- seller_name: 卖家名称
- status: 状态（1-上架，0-下架）
- created_at/updated_at: 时间戳

### 订单表 (orders)
- order_id: 订单ID（主键）
- order_number: 订单号（唯一）
- buyer_id: 买家ID（外键）
- buyer_name: 买家姓名
- product_id: 商品ID（外键）
- product_name: 商品名称
- seller_id: 卖家ID（外键）
- seller_name: 卖家姓名
- quantity: 购买数量
- unit_price: 单价
- total_amount: 总金额
- shipping_address: 收货地址
- contact_phone: 联系电话
- status: 订单状态（1-待支付，2-已支付，3-已发货，4-已完成，5-已取消）
- created_at/updated_at: 时间戳

## API接口

### 用户相关 (/user/*)
- POST /user/register - 用户注册
- POST /user/login - 用户登录
- POST /user/logout - 用户登出
- GET /user/profile - 获取个人信息
- POST /user/updateProfile - 更新个人信息
- POST /user/recharge - 余额充值
- POST /user/withdraw - 余额提现
- GET /user/list - 获取用户列表（管理员）
- POST /user/updateCredit - 更新信用分数（管理员）
- POST /user/ban - 拉黑用户（管理员）
- POST /user/unban - 解封用户（管理员）
- GET /user/checkUsername - 检查用户名可用性
- POST /user/changePassword - 修改密码

### 商品相关 (/product/*)
- GET /product/list - 获取商品列表
- GET /product/detail - 获取商品详情
- GET /product/myProducts - 获取我的商品
- GET /product/categories - 获取商品分类
- GET /product/search - 搜索商品
- GET /product/category - 根据分类获取商品
- POST /product/add - 添加商品
- POST /product/update - 更新商品
- POST /product/delete - 删除商品
- POST /product/publish - 上架商品
- POST /product/unpublish - 下架商品
- POST /product/addStock - 增加库存

### 订单相关 (/order/*)
- GET /order/list - 获取订单列表
- GET /order/detail - 获取订单详情
- GET /order/myOrders - 获取我的订单
- GET /order/sellerOrders - 获取卖家订单
- GET /order/allOrders - 获取所有订单（管理员）
- GET /order/statistics - 获取订单统计
- POST /order/create - 创建订单
- POST /order/pay - 支付订单
- POST /order/ship - 发货
- POST /order/confirm - 确认收货
- POST /order/cancel - 取消订单
- POST /order/delete - 删除订单
- POST /order/updateAddress - 更新收货地址

## 快速开始

### 环境要求
- JDK 8+
- Maven 3.6+
- MySQL 8.0+
- Tomcat 9.0+

### 安装步骤

1. **克隆项目**
   ```bash
   git clone <repository-url>
   cd Second-hand
   ```

2. **创建数据库**
   ```sql
   mysql -u root -p < src/main/resources/init.sql
   ```

3. **配置数据库连接**
   编辑 `src/main/resources/db.properties`：
   ```properties
   db.driver=com.mysql.cj.jdbc.Driver
   db.url=jdbc:mysql://localhost:3306/secondhand_mall?useSSL=false&serverTimezone=UTC
   db.username=your_username
   db.password=your_password
   ```

4. **编译项目**
   ```bash
   mvn clean compile
   ```

5. **打包部署**
   ```bash
   mvn clean package
   # 将生成的 war 包部署到 Tomcat
   ```

6. **启动应用**
   启动 Tomcat 服务器，访问 `http://localhost:8080/Second-hand`

### 默认账户

- **管理员**：admin / admin123
- **商家1**：seller1 / seller123
- **商家2**：seller2 / seller123
- **用户1**：user1 / user123
- **用户2**：user2 / user123

## 开发说明

### 代码规范
- 使用 UTF-8 编码
- 遵循 Java 命名规范
- 添加必要的注释
- 异常处理要完善

### 安全特性
- 密码使用 jBCrypt 加密
- SQL 注入防护
- XSS 攻击防护
- 会话管理
- 权限验证

### 性能优化
- 数据库连接池
- 索引优化
- 分页查询
- 缓存机制

## 扩展功能

- [ ] 商品图片上传
- [ ] 订单评价系统
- [ ] 消息通知
- [ ] 数据统计图表
- [ ] 移动端适配
- [ ] 第三方支付集成
- [ ] 物流跟踪
- [ ] 优惠券系统

## 许可证

MIT License

## 联系方式

如有问题，请联系开发者。